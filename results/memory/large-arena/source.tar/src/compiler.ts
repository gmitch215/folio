import binaryen from 'binaryen';
import type { NativePlan } from './guards.ts';
import { nativePlan } from './guards.ts';

export interface LoopPlan {
	countParameter: number;
	steps: { parameter: number; step: number }[];
}

export interface PreparedProgram {
	original: Uint8Array;
	transactional?: Uint8Array;
	loops: Record<string, LoopPlan>;
	reasons: string[];
	native?: Record<string, NativePlan>;
}

type Info = ReturnType<typeof binaryen.getExpressionInfo> & Record<string, any>;
const info = (expression: number): Info => {
	const id = binaryen.getExpressionId(expression);
	if (id === binaryen.UnreachableId || id === binaryen.NopId) {
		return { id, type: binaryen.getExpressionType(expression) } as Info;
	}
	return binaryen.getExpressionInfo(expression) as Info;
};

function walk(expression: number, visit: (value: Info) => void): void {
	const value = info(expression);
	visit(value);
	for (const key of ['children', 'operands']) {
		for (const child of value[key] ?? []) walk(child, visit);
	}
	for (const key of ['body', 'condition', 'ifTrue', 'ifFalse', 'ptr', 'value', 'left', 'right']) {
		if (key === 'value' && value.id === binaryen.ConstId) continue;
		if (typeof value[key] === 'number' && value[key]) walk(value[key], visit);
	}
}

function loopPlan(module: binaryen.Module, fn: binaryen.FunctionRef): LoopPlan | undefined {
	const f = binaryen.getFunctionInfo(fn);
	if (f.results !== binaryen.none || f.vars.length) return;
	if (binaryen.expandType(f.params).some((type) => type !== binaryen.i32)) return;
	const root = info(f.body);
	if (root.id !== binaryen.BlockId || root.children.length !== 2) return;
	const guard = info(root.children[0]);
	const loop = info(root.children[1]);
	if (
		guard.id !== binaryen.BreakId ||
		guard.name !== root.name ||
		guard.value ||
		!guard.condition
	)
		return;
	if (loop.id !== binaryen.LoopId) return;
	const zero = info(guard.condition);
	if (zero.id !== binaryen.UnaryId || zero.op !== binaryen.EqZInt32) return;
	const counter = info(zero.value);
	if (counter.id !== binaryen.LocalGetId) return;
	const body = info(loop.body);
	if (body.id !== binaryen.BlockId || body.children.length < 2) return;
	const last = info(body.children.at(-1));
	if (last.id !== binaryen.BreakId || last.name !== loop.name || last.value || !last.condition)
		return;
	const decrement = info(last.condition);
	if (decrement.id !== binaryen.LocalSetId || !decrement.isTee) return;
	if (decrement.index !== counter.index) return;
	const add = info(decrement.value);
	if (add.id !== binaryen.BinaryId || add.op !== binaryen.AddInt32) return;
	const left = info(add.left),
		right = info(add.right);
	if (left.id !== binaryen.LocalGetId || left.index !== counter.index) return;
	if (right.id !== binaryen.ConstId || right.value !== -1) return;
	const steps: LoopPlan['steps'] = [];
	const updates = new Set<number>();
	let end = body.children.length - 1;
	while (end > 0) {
		const set = info(body.children[end - 1]);
		if (set.id !== binaryen.LocalSetId || set.isTee || set.index === counter.index) break;
		const update = info(set.value);
		if (update.id !== binaryen.BinaryId || update.op !== binaryen.AddInt32) break;
		const source = info(update.left),
			delta = info(update.right);
		if (source.id !== binaryen.LocalGetId || source.index !== set.index) break;
		if (delta.id !== binaryen.ConstId || updates.has(set.index)) break;
		updates.add(set.index);
		steps.push({ parameter: set.index, step: delta.value });
		end--;
	}
	if (!steps.length || end === 0) return;
	let safe = true;
	for (const expression of body.children.slice(0, end)) {
		walk(expression, (value) => {
			if (value.id === binaryen.LocalSetId) safe = false;
			if (value.id === binaryen.CallId && value.isReturn) safe = false;
			if (value.id === binaryen.LocalGetId && value.index === counter.index) safe = false;
			if ([binaryen.BreakId, binaryen.SwitchId, binaryen.ReturnId].includes(value.id))
				safe = false;
		});
	}
	return safe ? { countParameter: counter.index, steps } : undefined;
}

/** Prepares guarded parallel paths; unsupported features retain the original module. */
export function prepare(
	bytes: Uint8Array,
	options: { parallel?: 'auto' | 'off' } = {}
): PreparedProgram {
	const original = Uint8Array.from(bytes);
	const native = new WebAssembly.Module(original);
	if (options.parallel === 'off')
		return { original, loops: {}, reasons: ['parallel preparation disabled'] };
	const reasons: string[] = [];
	const imports = WebAssembly.Module.imports(native);
	if (imports.some((item) => item.kind !== 'memory')) reasons.push('host or non-memory imports');
	if (imports.some((item) => item.module === 'folio')) reasons.push('reserved import namespace');
	if (imports.filter((item) => item.kind === 'memory').length !== 1)
		reasons.push('one imported memory required');
	if (reasons.length) return { original, loops: {}, reasons };
	const module = binaryen.readBinary(original);
	const loops: PreparedProgram['loops'] = {};
	const nativePlans: Record<string, NativePlan> = {};
	try {
		if (module.getStart()) reasons.push('start function');
		const raw = module as binaryen.Module & { getNumDataSegments(): number };
		if (raw.getNumDataSegments())
			reasons.push('data segments require initialization isolation');
		const memory = module.hasMemory() ? module.getMemoryInfo() : undefined;
		if (!memory?.shared || memory.is64) reasons.push('shared wasm32 memory required');
		if (memory?.shared) module.setFeatures(module.getFeatures() | binaryen.Features.Atomics);
		const allowed = new Set([
			binaryen.BlockId,
			binaryen.IfId,
			binaryen.LoopId,
			binaryen.BreakId,
			binaryen.CallId,
			binaryen.LocalGetId,
			binaryen.LocalSetId,
			binaryen.GlobalGetId,
			binaryen.LoadId,
			binaryen.StoreId,
			binaryen.ConstId,
			binaryen.UnaryId,
			binaryen.BinaryId,
			binaryen.SelectId,
			binaryen.DropId,
			binaryen.ReturnId,
			binaryen.NopId,
			binaryen.UnreachableId
		]);
		for (let index = 0; index < module.getNumFunctions(); index++) {
			const fn = module.getFunctionByIndex(index);
			const f = binaryen.getFunctionInfo(fn);
			if (!f.body) continue;
			walk(f.body, (value) => {
				if (!allowed.has(value.id)) reasons.push(`unsupported expression ${value.id}`);
				if (value.id === binaryen.GlobalGetId) reasons.push('global state');
				if (value.isAtomic) reasons.push('atomic access');
				if ([binaryen.LoadId, binaryen.StoreId].includes(value.id)) {
					const type = value.id === binaryen.LoadId ? value.type : info(value.value).type;
					if (type !== binaryen.i32) reasons.push('non-i32 memory access');
				}
			});
			const plan = loopPlan(module, fn);
			if (plan) {
				for (let e = 0; e < module.getNumExports(); e++) {
					const exported = binaryen.getExportInfo(module.getExportByIndex(e));
					if (exported.kind === binaryen.ExternalFunction && exported.value === f.name) {
						loops[exported.name] = plan;
						const proved = nativePlan(module, fn);
						if (proved) nativePlans[exported.name] = proved;
					}
				}
			}
		}
		if (reasons.length) return { original, loops: {}, reasons: [...new Set(reasons)] };
		const reserved = ['__folio_load', '__folio_store', '__folio_exhausted', '__folio_set_fuel'];
		if (
			reserved.some((name) => module.getFunction(name) || module.getExport(name)) ||
			module.getGlobal('__folio_fuel')
		) {
			return { original, loops: {}, reasons: ['reserved function name'] };
		}
		module.addGlobal('__folio_fuel', binaryen.i32, true, module.i32.const(0));
		function tick(): number {
			return module.block(null, [
				module.global.set(
					'__folio_fuel',
					module.i32.sub(
						module.global.get('__folio_fuel', binaryen.i32),
						module.i32.const(1)
					)
				),
				module.if(
					module.i32.le_s(
						module.global.get('__folio_fuel', binaryen.i32),
						module.i32.const(0)
					),
					module.call(reserved[2]!, [], binaryen.none)
				)
			]);
		}
		function lower(expression: number): number {
			const v = info(expression);
			switch (v.id) {
				case binaryen.BlockId:
					return module.block(v.name, v.children.map(lower), v.type);
				case binaryen.IfId:
					return module.if(
						lower(v.condition),
						lower(v.ifTrue),
						v.ifFalse ? lower(v.ifFalse) : undefined
					);
				case binaryen.LoopId:
					return module.loop(v.name, module.block(null, [tick(), lower(v.body)], v.type));
				case binaryen.BreakId:
					return module.br(
						v.name,
						v.condition ? lower(v.condition) : undefined,
						v.value ? lower(v.value) : undefined
					);
				case binaryen.CallId:
					return v.isReturn
						? module.return_call(v.target, v.operands.map(lower), v.type)
						: module.call(v.target, v.operands.map(lower), v.type);
				case binaryen.LocalSetId:
					return v.isTee
						? module.local.tee(v.index, lower(v.value), v.type)
						: module.local.set(v.index, lower(v.value));
				case binaryen.LoadId:
					return module.call(
						reserved[0]!,
						[
							lower(v.ptr),
							module.i32.const(v.offset),
							module.i32.const(v.bytes),
							module.i32.const(Number(v.isSigned))
						],
						binaryen.i32
					);
				case binaryen.StoreId:
					return module.call(
						reserved[1]!,
						[
							lower(v.ptr),
							lower(v.value),
							module.i32.const(v.offset),
							module.i32.const(v.bytes)
						],
						binaryen.none
					);
				case binaryen.UnaryId:
					return (binaryen as any)._BinaryenUnary(module.ptr, v.op, lower(v.value));
				case binaryen.BinaryId:
					return (binaryen as any)._BinaryenBinary(
						module.ptr,
						v.op,
						lower(v.left),
						lower(v.right)
					);
				case binaryen.SelectId:
					return module.select(lower(v.condition), lower(v.ifTrue), lower(v.ifFalse));
				case binaryen.DropId:
					return module.drop(lower(v.value));
				case binaryen.ReturnId:
					return module.return(v.value ? lower(v.value) : undefined);
				default:
					return expression;
			}
		}
		const count = module.getNumFunctions();
		for (let index = 0; index < count; index++) {
			const fn = module.getFunctionByIndex(index);
			const body = binaryen.getFunctionInfo(fn).body;
			if (body)
				(binaryen as any)._BinaryenFunctionSetBody(
					fn,
					module.block(null, [tick(), lower(body)], info(body).type)
				);
		}
		const fourI32 = binaryen.createType(Array(4).fill(binaryen.i32));
		module.addFunctionImport(reserved[0]!, 'folio', 'load', fourI32, binaryen.i32);
		module.addFunctionImport(reserved[1]!, 'folio', 'store', fourI32, binaryen.none);
		module.addFunctionImport(reserved[2]!, 'folio', 'exhausted', binaryen.none, binaryen.none);
		module.addFunction(
			reserved[3]!,
			binaryen.i32,
			binaryen.none,
			[],
			module.global.set('__folio_fuel', module.local.get(0, binaryen.i32))
		);
		module.addFunctionExport(reserved[3]!, reserved[3]!);
		if (!module.validate()) throw new Error('invalid transactional lowering');
		return {
			original,
			transactional: module.emitBinary(),
			loops,
			native: nativePlans,
			reasons: []
		};
	} catch (error) {
		return {
			original,
			loops: {},
			reasons: [
				`parallel preparation unavailable: ${error instanceof Error ? error.message : String(error)}`
			]
		};
	} finally {
		module.dispose();
	}
}
