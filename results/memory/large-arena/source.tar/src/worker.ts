import { parentPort, threadId, workerData } from 'node:worker_threads';
import { SpeculationLimit, transaction } from './transaction.ts';

const { module, nativeModule, memory, importModule, importName } = workerData;
const nativeInstance = new WebAssembly.Instance(nativeModule, {
	[importModule]: { [importName]: memory }
});
let active: ReturnType<typeof transaction>;
const instance = new WebAssembly.Instance(module, {
	[importModule]: { [importName]: memory },
	folio: {
		...(importModule === 'folio' ? { [importName]: memory } : {}),
		load: (...args: [number, number, number, number]) => active.load(...args),
		store: (...args: [number, number, number, number]) => active.store(...args),
		exhausted: () => {
			throw new SpeculationLimit('speculative instruction budget');
		}
	}
});
parentPort!.on('message', ({ id, call, fuel, maxBytes, native }) => {
	active = transaction(memory, maxBytes);
	let value: unknown;
	let error: unknown;
	try {
		if (native) {
			value = (nativeInstance.exports[call.export] as CallableFunction)(...call.args);
		} else {
			(instance.exports.__folio_set_fuel as CallableFunction)(fuel);
			value = (instance.exports[call.export] as CallableFunction)(...call.args);
		}
	} catch (caught) {
		error = caught;
	}
	parentPort!.postMessage({ id, ...active.result(value, error) });
});
parentPort!.postMessage({
	ready: true,
	threadId,
	shared: memory.buffer instanceof SharedArrayBuffer
});
