import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { prepare } from '../src/compiler.ts';

const source = readFileSync(new URL('../build/fixture.wasm', import.meta.url));
const prepared = prepare(source);
if (!prepared.transactional || !prepared.loops.program) throw new Error('missing compiler path');
writeFileSync(
	new URL('../build/probe.json', import.meta.url),
	JSON.stringify({
		...prepared,
		original: Buffer.from(prepared.original).toString('base64'),
		transactional: Buffer.from(prepared.transactional).toString('base64'),
		sha256: createHash('sha256').update(source).digest('hex')
	})
);
