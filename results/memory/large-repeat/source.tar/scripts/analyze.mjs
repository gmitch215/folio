import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';

const root = new URL(`../results/${process.argv[2] ?? '20261019'}/`, import.meta.url);
const files = readdirSync(root).filter((name) => name.endsWith('.jsonl'));
const read = (name) => readFileSync(new URL(name, root));
const rows = files.flatMap((file) =>
	read(file)
		.toString()
		.trim()
		.split('\n')
		.map((line) => ({ file, ...JSON.parse(line) }))
);
const samples = rows.filter((row) => row.kind === 'sample');
const environment = rows.find((row) => row.kind === 'environment');
const arms = environment.arms ?? ['native', 'serial-api', 'two', 'four'];
assert.equal(samples.length, 3 * arms.length * 7);
assert.ok(samples.every((row) => row.passed));
const stats = (values) => {
	const sorted = [...values].sort((a, b) => a - b);
	return {
		n: sorted.length,
		median: sorted[Math.floor(sorted.length / 2)],
		min: sorted[0],
		max: sorted.at(-1)
	};
};
const cpu = {};
for (const name of ['tiny', 'stream', 'compute']) {
	const group = samples.filter((row) => row.name === name);
	cpu[name] = {};
	for (const arm of arms) {
		const matches = group.filter((row) => row.arm === arm);
		assert.equal(matches.length, 7);
		const native = (row) =>
			group.find((other) => other.round === row.round && other.arm === 'native');
		cpu[name][arm] = {
			wallMs: stats(matches.map((row) => row.wallMs)),
			cpuMs: stats(matches.map((row) => row.cpuMs)),
			pairedSpeedup: stats(matches.map((row) => native(row).wallMs / row.wallMs)),
			pairedCpuRatio: stats(matches.map((row) => row.cpuMs / native(row).cpuMs)),
			cpuPerWall: stats(matches.map((row) => row.cpuMs / row.wallMs))
		};
	}
}
const sharing = {};
for (const mode of rows.some((row) => row.kind === 'sharing') ? ['shared', 'copied'] : []) {
	const matches = rows.filter(
		(row) => row.kind === 'sharing' && row.mode === mode && row.mib === 64
	);
	assert.equal(matches.length, 3);
	assert.ok(matches.every((row) => row.passed && new Set(row.isolates).size === 4));
	sharing[mode] = {
		attachDeltaMiB: stats(matches.map((row) => row.attachDelta / 1048576)),
		rssAttachedMiB: stats(matches.map((row) => row.rssAttached / 1048576))
	};
}
const large = rows.find((row) => row.kind === 'sharing' && row.mib === 256);
if (large) assert.ok(large.passed);
const summary = {
	environment,
	measuredSamples: samples.length,
	cpu,
	sharing,
	large,
	growth: rows.filter((row) => row.kind === 'growth'),
	creatorExit: rows.filter((row) => row.kind === 'creator-exit'),
	hashes: Object.fromEntries(
		[...files, 'source.tar'].map((file) => [
			file,
			createHash('sha256').update(read(file)).digest('hex')
		])
	)
};
writeFileSync(new URL('summary.json', root), `${JSON.stringify(summary, null, 2)}\n`);
console.log(JSON.stringify({ cpu: summary.cpu.compute, sharing, large }, null, 2));
