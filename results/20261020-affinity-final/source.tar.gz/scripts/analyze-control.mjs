import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const set = process.argv[2] ?? '20261020-control-b';
if (!/^[a-zA-Z0-9-]+$/.test(set)) throw new Error('invalid measurement set');
const root = new URL(`../results/${set}/`, import.meta.url);
const raw = readFileSync(new URL('control.jsonl', root));
const rows = raw.toString().trim().split('\n').map(line => JSON.parse(line));
const metadata = rows.shift().metadata;
const samples = rows.filter(row => row.iteration >= 0);
const median = values => [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)];
const stats = values => ({ median: median(values), minimum: Math.min(...values), maximum: Math.max(...values) });
assert.equal(rows.length, (metadata.repeats + metadata.warmups) * 5);
assert.ok(rows.every(row => row.exact));
const summary = { metadata, rawSha256: createHash('sha256').update(raw).digest('hex'),
	sourceArchiveSha256: createHash('sha256').update(readFileSync(new URL('source.tar.gz', root))).digest('hex'),
	samples: samples.length, warmupSamples: rows.length - samples.length,
	allWholeMemoryAndReturnsExact: true, discardedSamples: 0,
	maximumRssMiB: Math.max(...rows.map(row => row.rssMiB)),
	minimumFreeMiB: Math.min(...rows.map(row => row.freeMiB)),
	load1: stats(samples.map(row => row.load[0])), arms: {} };
for (const arm of ['raw', 'auto-1', 'auto-2', 'auto-4', 'auto-8']) {
	const group = samples.filter(row => row.arm === arm);
	assert.equal(group.length, metadata.repeats);
	const reference = group.map(row => samples.find(other => other.iteration === row.iteration && other.arm === 'raw'));
	summary.arms[arm] = { samples: group.length, wallMs: stats(group.map(row => row.wallMs)),
		cpuMs: stats(group.map(row => row.cpuMs)),
		pairedSpeedup: stats(group.map((row, i) => reference[i].wallMs / row.wallMs)),
		pairedCpuRatio: stats(group.map((row, i) => row.cpuMs / reference[i].cpuMs)),
		cpuPerWall: stats(group.map(row => row.cpuMs / row.wallMs)) };
	if (arm !== 'raw') {
		const reports = group.map(row => row.report);
		summary.arms[arm].execution = { modes: [...new Set(reports.map(report => report.mode))],
			workers: [...new Set(reports.map(report => report.workers))],
			regions: [...new Set(reports.map(report => report.regions))],
			replayed: reports.reduce((sum, report) => sum + report.replayed, 0),
			fallbacks: reports.reduce((sum, report) => sum + report.fallbacks, 0),
			validationMs: stats(reports.map(report => report.profile.validationMs)),
			commitMs: stats(reports.map(report => report.profile.commitMs)) };
	}
}
writeFileSync(new URL('summary.json', root), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
