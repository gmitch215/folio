#!/usr/bin/env bash
set -euC
cd "$(dirname "$0")/.."
held=0
scope=${1:-all}
label=${2:-folio-proof-20261019}
finish() {
	code=$?
	if [ "$held" = 1 ]; then
		rmdir /tmp/paisley-timing.lock
		bash "$HOME/gmux-rig/bin/sweep.sh" end "$label"
	fi
	printf '%s\n' "$code" > results/exit-code
	touch results/finished
}
trap finish EXIT
mkdir /tmp/paisley-timing.lock
held=1
bash "$HOME/gmux-rig/bin/sweep.sh" start "$label"
node_bin="$HOME/.nvm/versions/node/v26.10.0/bin/node"
if [ "$scope" = all ]; then
	for round in 0 1 2; do
		for mode in shared copied; do
			nice -n 19 taskset -c 4,6,8,10 "$node_bin" --max-old-space-size=128 --expose-gc scripts/sharing-probe.mjs "$mode" 64 > "results/sharing-$mode-$round.jsonl"
		done
	done
	nice -n 19 taskset -c 4,6,8,10 "$node_bin" --max-old-space-size=128 --expose-gc scripts/sharing-probe.mjs shared 256 > results/sharing-large.jsonl
fi
if [ "$scope" = large ]; then
	nice -n 19 taskset -c 4,6,8,10 "$node_bin" --max-old-space-size=128 --experimental-strip-types scripts/large-probe.ts > results/large.jsonl
else
	nice -n 19 taskset -c 4,6,8,10 "$node_bin" --max-old-space-size=128 --experimental-strip-types scripts/cpu-probe.ts > results/cpu.jsonl
fi
free -h
df -h /
du -sh .
