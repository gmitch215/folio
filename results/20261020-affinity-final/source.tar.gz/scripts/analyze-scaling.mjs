import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const root = new URL('../results/20261019-d/', import.meta.url);
const raw = readFileSync(new URL('scaling.jsonl', root));
const rows = raw
	.toString()
	.trim()
	.split('\n')
	.map((line) => JSON.parse(line));
const environment = rows.find((row) => row.kind === 'environment');
const samples = rows.filter((row) => row.kind === 'sample');
assert.equal(samples.length, 207);
assert.ok(samples.every((row) => row.passed && row.verifiedBytes === environment.physicalBytes));
const stats = (values) => {
	const sorted = [...values].sort((a, b) => a - b);
	return {
		n: sorted.length,
		median: sorted[Math.floor(sorted.length / 2)],
		min: sorted[0],
		max: sorted.at(-1)
	};
};
const workloads = {};
for (const name of new Set(samples.map((row) => row.name))) {
	const group = samples.filter((row) => row.name === name);
	workloads[name] = {};
	for (const arm of new Set(group.map((row) => row.arm))) {
		const matches = group.filter((row) => row.arm === arm);
		assert.equal(matches.length, 9);
		const paired = (row) =>
			group.find((other) => other.arm === 'raw' && other.round === row.round);
		const profiled = matches.filter((row) => row.report?.profile?.workerWallMs.length);
		workloads[name][arm] = {
			wallMs: stats(matches.map((row) => row.wallMs)),
			pairedSpeedup: stats(matches.map((row) => paired(row).wallMs / row.wallMs)),
			cpuRatio: stats(matches.map((row) => row.cpuMs / paired(row).cpuMs)),
			processCpuPerWall: stats(matches.map((row) => row.cpuMs / row.wallMs)),
			...(profiled.length
				? {
						workerCpuMs: stats(
							profiled.map((row) =>
								row.report.profile.workerCpuMs.reduce(
									(sum, value) => sum + value,
									0
								)
							)
						),
						longestWorkerMs: stats(
							profiled.map((row) => Math.max(...row.report.profile.workerWallMs))
						),
						// Includes message dispatch/receipt, scheduling and orchestration; not a pure transport timer.
						orchestrationResidualMs: stats(
							profiled.map(
								(row) =>
									row.report.profile.wallMs -
									Math.max(...row.report.profile.workerWallMs)
							)
						),
						validationMs: stats(profiled.map((row) => row.report.profile.validationMs)),
						commitMs: stats(profiled.map((row) => row.report.profile.commitMs)),
						trackedReadBytes: stats(
							profiled.map((row) => row.report.profile.readBytes)
						),
						trackedWriteBytes: stats(
							profiled.map((row) => row.report.profile.writeBytes)
						)
					}
				: {})
		};
	}
}
const summary = {
	environment,
	measuredSamples: samples.length,
	workloads,
	rssMiB: stats(samples.map((row) => row.rss / 1048576)),
	load: stats(samples.map((row) => row.load[0])),
	hash: createHash('sha256').update(raw).digest('hex')
};
writeFileSync(new URL('summary.json', root), `${JSON.stringify(summary, null, 2)}\n`);
for (const [name, arms] of Object.entries(workloads))
	console.log(
		JSON.stringify({
			name,
			arms: Object.fromEntries(
				Object.entries(arms).map(([arm, value]) => [
					arm,
					{
						wallMs: value.wallMs.median,
						speed: value.pairedSpeedup.median,
						cpuRatio: value.cpuRatio.median,
						cpuPerWall: value.processCpuPerWall.median,
						residualMs: value.orchestrationResidualMs?.median,
						validationMs: value.validationMs?.median,
						commitMs: value.commitMs?.median
					}
				])
			)
		})
	);
