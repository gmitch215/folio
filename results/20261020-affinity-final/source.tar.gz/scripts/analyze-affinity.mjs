import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';

const set = process.argv[2] ?? '20261020-affinity';
assert.match(set, /^[a-zA-Z0-9-]+$/);
const root = new URL(`../results/${set}/`, import.meta.url);
const raw = readFileSync(new URL('affinity.jsonl', root));
const rows = raw.toString().trim().split('\n').map(line => JSON.parse(line));
const { metadata } = rows.shift();
const samples = rows.filter(row => row.iteration >= 0);
const median = values => [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)];
const stats = values => ({ median: median(values), minimum: Math.min(...values), maximum: Math.max(...values) });
assert.equal(metadata.arms.length, 8);
assert.equal(rows.length, (metadata.repeats + metadata.warmups) * metadata.arms.length);
assert.ok(rows.every(row => row.exact));
const summary = { metadata,
	rawSha256: createHash('sha256').update(raw).digest('hex'),
	sourceArchiveSha256: createHash('sha256').update(readFileSync(new URL('source.tar.gz', root))).digest('hex'),
	samples: samples.length, warmupSamples: rows.length - samples.length,
	allWholeMemoryAndReturnsExact: true, discardedSamples: 0,
	maximumRssMiB: Math.max(...rows.map(row => row.rssMiB)),
	minimumFreeMiB: Math.min(...rows.map(row => row.freeMiB)),
	load1: stats(samples.map(row => row.load[0])), arms: {} };
for (const arm of metadata.arms) {
	const group = samples.filter(row => row.arm === arm);
	assert.equal(group.length, metadata.repeats);
	assert.equal(new Set(group.map(row => row.iteration)).size, metadata.repeats);
	const reference = group.map(row => samples.find(other =>
		other.iteration === row.iteration && other.arm === 'raw'));
	assert.ok(reference.every(Boolean));
	const entry = summary.arms[arm] = {
		samples: group.length, wallMs: stats(group.map(row => row.wallMs)),
		cpuMs: stats(group.map(row => row.cpuMs)),
		pairedSpeedup: stats(group.map((row, i) => reference[i].wallMs / row.wallMs)),
		pairedCpuRatio: stats(group.map((row, i) => row.cpuMs / reference[i].cpuMs)),
		cpuPerWall: stats(group.map(row => row.cpuMs / row.wallMs)),
		affinities: group.map(row => ({ iteration: row.iteration, threads: row.affinity }))
	};
	if (arm.endsWith('-pinned')) {
		const unpinned = arm.replace(/-pinned$/, '-unpinned');
		entry.pairedPinningSpeedup = stats(group.map(row => samples.find(other =>
			other.iteration === row.iteration && other.arm === unpinned).wallMs / row.wallMs));
	}
	if (arm !== 'raw') {
		const reports = group.map(row => row.report);
		entry.execution = { modes: [...new Set(reports.map(report => report.mode))],
			workers: [...new Set(reports.map(report => report.workers))],
			regions: [...new Set(reports.map(report => report.regions))],
			replayed: reports.reduce((sum, report) => sum + report.replayed, 0),
			fallbacks: reports.reduce((sum, report) => sum + report.fallbacks, 0),
			validationMs: stats(reports.map(report => report.profile.validationMs)),
			commitMs: stats(reports.map(report => report.profile.commitMs)) };
		const width = reports[0].workers;
		if (width > 1) {
			const lanes = reports.map(report => {
				assert.equal(report.profile.workerWallMs.length, report.regions);
				assert.equal(report.profile.workerCpuMs.length, report.regions);
				const wall = Array(width).fill(0), cpu = Array(width).fill(0);
				report.profile.workerWallMs.forEach((value, i) => { wall[i % width] += value; });
				report.profile.workerCpuMs.forEach((value, i) => { cpu[i % width] += value; });
				return { wall, cpu };
			});
			entry.execution.maximumLaneWallMs = stats(lanes.map(lane => Math.max(...lane.wall)));
			entry.execution.maximumLaneCpuMs = stats(lanes.map(lane => Math.max(...lane.cpu)));
			entry.execution.maximumLaneWallMinusCpuMs = stats(lanes.map(lane =>
				Math.max(...lane.wall.map((wall, i) => wall - lane.cpu[i]))));
		}
	}
}
writeFileSync(new URL('summary.json', root), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
