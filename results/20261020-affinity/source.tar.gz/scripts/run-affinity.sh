#!/usr/bin/env bash
set -euo pipefail
label=folio-affinity-20261020
locked=0
finish() {
	status=$?
	trap - EXIT
	if [ "$locked" = 1 ]; then
		bash "$HOME/gmux-rig/bin/sweep.sh" end "$label" || true
		rmdir /tmp/paisley-timing.lock || true
	fi
	printf '%s\n' "$status" > results/exit-code
	exit "$status"
}
trap finish EXIT
mkdir /tmp/paisley-timing.lock
locked=1
bash "$HOME/gmux-rig/bin/sweep.sh" start "$label"
nice -n 19 taskset -c 4-11 "$HOME/.nvm/versions/node/v26.10.0/bin/node" \
	--max-old-space-size=128 scripts/control-affinity.mjs > results/affinity.jsonl
