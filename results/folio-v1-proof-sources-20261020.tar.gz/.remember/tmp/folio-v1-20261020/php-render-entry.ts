import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { deserialize } from 'node:v8';
import { DatabaseSync } from 'node:sqlite';
import { PhpBase } from '/Users/gamer/gmitch215/drupflare/worker/node_modules/php-wasm/PhpBase.mjs';
import '/Users/gamer/gmitch215/drupflare/worker/node_modules/@drupflare/cartridge/src/worker-shim.ts';
import { mountDrupalLazy, mountDriver, mkdirp } from '/Users/gamer/gmitch215/drupflare/worker/node_modules/@drupflare/cartridge/src/fs.ts';
import { SiteDurableObject } from '/Users/gamer/gmitch215/drupflare/worker/node_modules/@drupflare/durabledb/src/do-sqlite.ts';
import { PHP_CODEC } from '/Users/gamer/gmitch215/drupflare/worker/node_modules/@drupflare/durabledb/src/codec.ts';
import { decodeParam } from '/Users/gamer/gmitch215/drupflare/worker/src/db/migrate-sql.ts';
import { withMask } from '/Users/gamer/gmitch215/drupflare/worker/node_modules/@drupflare/cartridge/src/mask.ts';
import { settingsOverride, SERVICES_YAML } from '/Users/gamer/gmitch215/drupflare/worker/src/do/settings.ts';
import { INTERPRETER_MEMORY } from '/Users/gamer/gmitch215/drupflare/worker/src/do/isolate.ts';
import { BOOT_KERNEL, renderPage } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/site-php.ts';
import { MB_FIX } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/mb-fix.ts';
import { ICONV_FIX } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/iconv-fix.ts';
import { ZLIB_FIX, installZlib } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/zlib-fix.ts';
import { CURL_FIX } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/curl-fix.ts';
import { OPENSSL_FIX } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/openssl-fix.ts';
import { ARGON2_FIX } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/argon2-fix.ts';
import { SODIUM_FIX } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/sodium-fix.ts';
import { XMLWRITER_FIX } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/xmlwriter-fix.ts';
import { STANDIN_FIX, DISABLED } from '/Users/gamer/gmitch215/drupflare/worker/src/drupal/standin-fix.ts';
import { Folio } from '../../../src/node.ts';

const consumer = '/Users/gamer/gmitch215/drupflare/worker';
const scratch = new URL('.', import.meta.url).pathname;
const mode = process.argv[2] ?? 'native';
const outPath = process.argv[3] ?? join(scratch, `php-render-${mode}.json`);
const result: any = { mode, node:process.version, stages:[], reports:[] };
const hash = (data: Uint8Array|string) => createHash('sha256').update(data).digest('hex');
const started = performance.now();
function stage(name:string, data:object={}) {
	const value={name, wallMs:performance.now()-started,...data};
	result.stages.push(value);
	writeFileSync(outPath, JSON.stringify(result,null,2)+'\n');
	console.log(JSON.stringify(value));
}
const db = new DatabaseSync(':memory:');
const sqlTrace:string[]=[];
const sql = {
	exec(text:string,...params:any[]) {
		sqlTrace.push(text);
		const st = db.prepare(text);
		const changesBefore = db.prepare('SELECT total_changes() AS n').get()!.n as number;
		const rows = st.all(...params.map(p=>p instanceof ArrayBuffer?new Uint8Array(p):p));
		const changesAfter = db.prepare('SELECT total_changes() AS n').get()!.n as number;
		return {toArray:()=>rows, rowsRead:rows.length, rowsWritten:changesAfter-changesBefore};
	}
};
const bridge = new SiteDurableObject({ storage: {
	sql,
	transactionSync(fn:()=>unknown) {
		db.exec('SAVEPOINT folio_request');
		try { const result=fn();db.exec('RELEASE folio_request');return result; }
		catch(error) {db.exec('ROLLBACK TO folio_request');db.exec('RELEASE folio_request');throw error;}
	}
}} as any, {} as any);
const assetManifest = JSON.parse(readFileSync(join(consumer,'assets/drupal-sql/manifest.json'),'utf8'));
for(let i=0;i<assetManifest.totals.chunks;i++) {
	const chunk=JSON.parse(readFileSync(join(consumer,`assets/drupal-sql/${String(i).padStart(4,'0')}.json`),'utf8'));
	for(const item of chunk.statements) sql.exec(item.s,...item.p.map(decodeParam));
}
stage('seed-loaded',{chunks:assetManifest.totals.chunks,statements:assetManifest.totals.statements});
sqlTrace.length=0;
const env = { ASSETS: { async fetch(input:Request|string|URL) {
	const url=new URL(input instanceof Request?input.url:String(input));
	const path=resolve(consumer,'assets','.'+decodeURIComponent(url.pathname));
	if(!path.startsWith(join(consumer,'assets')+'/'))return new Response('',{status:400});
	try{return new Response(readFileSync(path));}catch{return new Response('',{status:404});}
}}};
const g=globalThis as any;
g.self??=g;
g.location??=new URL('https://folio.invalid/worker.mjs');
const {default:Factory}=await import(pathToFileURL(join(consumer,'.interp/php8.5-worker.tuned.mjs')).href);
const original=readFileSync(join(consumer,'.interp/php8.5.tuned.wasm'));
result.original={bytes:original.length,sha256:hash(original)};
const nativeModule=new WebAssembly.Module(original);
let pool: Folio|undefined;
let instantiationError:unknown;
const output:string[]=[];
const errors:string[]=[];
const php=new PhpBase(Promise.resolve({default:Factory}) as any, {
	ini:['opcache.enable=0','opcache.enable_cli=0','memory_limit=96M',`disable_functions=${DISABLED.join(',')}`].join('\n'),
	printErr:(text:string)=>errors.push(text),
	onAbort:(text:unknown)=>errors.push('abort: '+String(text)),
	instantiateWasm(imports:WebAssembly.Imports, receive:(instance:any,module:WebAssembly.Module)=>void) {
		(async()=>{
			await Promise.resolve();
			(imports.env as any).memory=new WebAssembly.Memory(INTERPRETER_MEMORY);
			if(mode==='native')receive(new WebAssembly.Instance(nativeModule,imports),nativeModule);
			else {
				const plan=deserialize(readFileSync(process.argv[4]??join(scratch,'php-prepared-ordered.bin')));
				pool=await Folio.open(plan,{imports,workers:2,profile:true});
				result.capabilities=pool.capabilities;
				result.threadIds=pool.threadIds;
				result.inspect=pool.inspect('pib_run');
				receive({exports:pool.exports},nativeModule);
			}
		})().catch(error=>{instantiationError=error;console.error(error);process.exitCode=1;});
		return {};
	}
} as any) as any;
php.addEventListener('output',(event:any)=>output.push(...[].concat(event.detail??[])));
php.addEventListener('error',(event:any)=>errors.push(...[].concat(event.detail??[])));
async function run(code:string, parallel=false) {
	output.length=0;
	if(parallel&&pool) {
		const encoded=new TextEncoder().encode('?>'+code+'\0');
		const pointer=Number((pool.exports.malloc as CallableFunction)(encoded.length));
		try {
			new Uint8Array(pool.memory.buffer,pointer,encoded.length).set(encoded);
			const report=await pool.run('pib_run',[pointer]);
			result.reports.push(report);
			php.flush();
		} finally { (pool.exports.free as CallableFunction)(pointer); }
	} else await php._run(code);
	return output.join('');
}
try {
	const binary=await Promise.race([php.binary,new Promise((_,reject)=>setTimeout(()=>reject(instantiationError??new Error('interpreter bootstrap timeout')),120000).unref())]) as any;
	stage('php-booted',{memoryBytes:binary.HEAPU8.buffer.byteLength});
	bridge.installBridge(binary);
	installZlib(binary,withMask);
	binary.cfwCanSuspend=false;
	binary.cfwStats=()=>JSON.stringify({queryCount:bridge.queryCount,databaseSize:0,oversized:false});
	binary.cfwServeStats=()=>JSON.stringify({});
	const mount=await mountDrupalLazy(binary,env as any,{database:false});
	const driver=await mountDriver(binary,env as any);
	mkdirp(binary.FS,'/drupal/sites/default/files/config/sync');
	const settingsPath='/drupal/sites/default/settings.php';
	const settings=new TextDecoder().decode(binary.FS.readFile(settingsPath));
	binary.FS.writeFile(settingsPath,settings+settingsOverride({origin:JSON.stringify('https://folio.invalid'),argon2:false,memoryBins:"['dynamic_page_cache','menu']",memoryItems:64,lane:0,lanes:1,packageAutoload:'',deploymentEnv:''})+"\n$settings['hash_salt']='folio-render-proof-fixed-salt';\n");
	binary.FS.writeFile('/drupal/sites/default/services.yml',SERVICES_YAML);
	stage('mounted',{mount,driver});
	for(const shim of [PHP_CODEC,MB_FIX,ICONV_FIX,ZLIB_FIX,CURL_FIX,OPENSSL_FIX,ARGON2_FIX,SODIUM_FIX,XMLWRITER_FIX,STANDIN_FIX])await run('<?php '+shim);
	const version=await run('<?php echo json_encode(["version"=>PHP_VERSION,"intSize"=>PHP_INT_SIZE,"extensions"=>get_loaded_extensions()]);');
	result.version=JSON.parse(version.slice(version.indexOf('{')));
	stage('shims-ready');
	const exceptionRaw=await run('<?php try { (function() { throw new \\RuntimeException("folio-caught-unwind"); })(); } catch (\\Throwable $e) { echo json_encode(["caught"=>$e->getMessage()]); }',mode==='folio');
	result.exception=JSON.parse(exceptionRaw.slice(exceptionRaw.indexOf('{')));
	if(result.exception.caught!=='folio-caught-unwind')throw new Error('PHP exception continuation failed: '+exceptionRaw);
	const kernelRaw=await run(BOOT_KERNEL,mode==='folio');
	result.kernelRaw=kernelRaw;
	const kernel=JSON.parse(kernelRaw.slice(kernelRaw.indexOf('{')));
	if(!kernel.ok||!kernel.hasDb)throw new Error('Drupal kernel failed: '+kernelRaw);
	stage('drupal-booted',{kernel,queries:bridge.queryCount,memoryBytes:binary.HEAPU8.buffer.byteLength});
	const code=renderPage('/',['page','dynamic_page_cache','render'],false,{origin:'https://folio.invalid'});
	const renderedRaw=await run(code,mode==='folio');
	result.renderedRaw=renderedRaw;
	const rendered=JSON.parse(renderedRaw.slice(renderedRaw.indexOf('{')));
	if(rendered.status!==200||!rendered.html?.includes('<html')||rendered.bytes<1000||rendered.error)throw new Error('Drupal render failed: '+renderedRaw.slice(0,2500));
	if(rendered.pageCache==='HIT'||rendered.dynamicCache==='HIT')throw new Error('render answered from Drupal cache');
	writeFileSync(outPath+'.html',rendered.html);
	result.render={...rendered,html:undefined,sha256:hash(rendered.html)};
	delete result.renderedRaw;
	result.sql={queries:bridge.queryCount,rowsRead:bridge.rowsRead,rowsWritten:bridge.rowsWritten};
	result.sql.statementShapeSha256=hash(JSON.stringify(sqlTrace));
	result.sql.callsIncludingCounters=sqlTrace.length;
	result.lazyInflation=mount.inflateStats;
	stage('drupal-rendered',{render:result.render,memoryBytes:binary.HEAPU8.buffer.byteLength,lazyInflation:mount.inflateStats});
	result.ok=true;
} catch(error) {
	result.error=String((error as Error)?.stack??error);
	console.error(error);
	process.exitCode=1;
} finally {
	if(pool)await pool.close();
	db.close();
	result.errors=errors;
	stage('closed');
	writeFileSync(outPath,JSON.stringify(result,null,2)+'\n');
}
