#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
llvm=${LLVM:-}
if [ -z "$llvm" ] && [ -x /opt/homebrew/opt/llvm/bin/clang ]; then
	llvm=/opt/homebrew/opt/llvm/bin
fi
clang=${llvm:+$llvm/}clang
mkdir -p "$root/build"
"$clang" --target=wasm32 -O2 -g0 -ffreestanding -fno-builtin -nostdlib \
	-fno-unroll-loops -fno-vectorize -matomics -mbulk-memory \
	-Wall -Wextra -Werror "$root/tests/generalized.c" -o "$root/build/generalized.wasm" \
	-Wl,--no-entry,--import-memory,--shared-memory,--initial-memory=131072 \
	-Wl,--max-memory=536870912
