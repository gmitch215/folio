import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { prepare } from '../src/compiler.ts';

const source = readFileSync(new URL('../build/generalized.wasm', import.meta.url));
const prepared = prepare(source);
const control = prepared.control;
assert.ok(control);
assert.ok(control.entries.includes('main'));
assert.equal(prepared.loops.main, undefined);
const encoded = JSON.stringify(prepared, (_, value) => value instanceof Uint8Array
	? { folioBytes: Buffer.from(value).toString('base64') } : value);
writeFileSync(new URL('../build/control-prepared.json', import.meta.url), encoded);
console.log(JSON.stringify({ originalBytes: source.length,
	controlRegions: control.regions.length, entries: control.entries }));
