#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
llvm=${LLVM:-}
if [ -z "$llvm" ] && [ -x /opt/homebrew/opt/llvm/bin/clang ]; then
	llvm=/opt/homebrew/opt/llvm/bin
fi
clang=${llvm:+$llvm/}clang
mkdir -p "$root/build"
"$clang" --target=wasm32 -O2 -g0 -ffreestanding -fno-builtin -nostdlib \
	-fno-inline -fno-unroll-loops -fno-vectorize -matomics -mbulk-memory \
	-Wall -Wextra -Werror "$root/tests/fixture.c" -o "$root/build/fixture.wasm" \
	-Wl,--no-entry,--import-memory,--shared-memory,--initial-memory=131072 \
	-Wl,--max-memory=536870912
"$clang" --target=wasm32 -O2 -g0 -ffreestanding -fno-builtin -nostdlib \
	-matomics -mbulk-memory -Wall -Wextra -Werror "$root/tests/sharing.c" \
	-o "$root/build/sharing.wasm" \
	-Wl,--no-entry,--import-memory,--shared-memory,--initial-memory=131072 \
	-Wl,--max-memory=536870912
