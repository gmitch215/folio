export class SpeculationLimit extends Error {}

export interface TransactionResult {
	value?: unknown;
	reads: number[];
	writes: [number, number][];
	trap?: string;
	errorKind?: string;
	exhausted?: boolean;
}

export function transaction(memory: WebAssembly.Memory, maxBytes: number) {
	const bytes = new Uint8Array(memory.buffer);
	const reads = new Set<number>();
	const writes = new Map<number, number>();
	function bounds(address: number, offset: number, width: number): number {
		const start = (address >>> 0) + (offset >>> 0);
		if (start + width > bytes.length) throw new WebAssembly.RuntimeError('memory access out of bounds');
		return start;
	}
	function limit() {
		if (reads.size + writes.size > maxBytes) throw new SpeculationLimit('transaction byte budget');
	}
	return {
		load(address: number, offset: number, width: number, signed: number): number {
			const start = bounds(address, offset, width);
			let value = 0;
			for (let i = 0; i < width; i++) {
				const at = start + i;
				const own = writes.get(at);
				if (own === undefined) reads.add(at);
				value |= (own ?? bytes[at]!) << (i * 8);
			}
			limit();
			return signed && width < 4 ? (value << (32 - width * 8)) >> (32 - width * 8) : value;
		},
		store(address: number, value: number, offset: number, width: number): void {
			const start = bounds(address, offset, width);
			for (let i = 0; i < width; i++) writes.set(start + i, (value >>> (i * 8)) & 255);
			limit();
		},
		result(value?: unknown, error?: unknown): TransactionResult {
			return {
				value,
				reads: [...reads],
				writes: [...writes],
				...(error instanceof SpeculationLimit ? { exhausted: true }
					: error ? { trap: error instanceof Error ? error.message : String(error), errorKind: error instanceof Error ? error.name : 'Error' } : {})
			};
		}
	};
}
