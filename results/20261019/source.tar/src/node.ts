import { availableParallelism } from 'node:os';
import { Worker } from 'node:worker_threads';
import type { PreparedProgram } from './compiler.ts';
import type { TransactionResult } from './transaction.ts';

export interface Call {
	export: string;
	args: (number | bigint)[];
}

export interface RunOptions {
	parallel?: 'auto' | 'off';
}

export interface ExecutionReport {
	values: unknown[];
	workers: number;
	regions: number;
	replayed: number;
	fallbacks: number;
	mode: 'serial' | 'speculative';
}

export interface FolioOptions {
	memory: WebAssembly.Memory;
	workers?: number;
	imports?: WebAssembly.Imports;
	fuel?: number;
	maxTransactionBytes?: number;
}

interface Pending {
	resolve(value: TransactionResult): void;
	reject(error: Error): void;
}

function throwTrap(result: TransactionResult): void {
	if (!result.trap) return;
	if (result.errorKind === 'TypeError') throw new TypeError(result.trap);
	if (result.errorKind === 'RangeError') throw new RangeError(result.trap);
	throw new WebAssembly.RuntimeError(result.trap);
}

/** A same-process isolate group; callers give it exclusive memory access during each run. */
export class Folio {
	get capabilities() {
		return Object.freeze({
			physicalSharing: this.#workers.length ? 'same-process' as const : 'none' as const,
			automaticRegions: this.#workers.length ? 'counted-loops' as const : 'none' as const,
			dependence: this.#workers.length ? 'ordered-validation' as const : 'serial' as const
		});
	}
	get exports(): WebAssembly.Exports { return this.#instance.exports; }
	readonly memory: WebAssembly.Memory;
	readonly threadIds: number[] = [];
	readonly #program: PreparedProgram;
	readonly #instance: WebAssembly.Instance;
	readonly #workers: Worker[] = [];
	readonly #pending = new Map<number, Pending>();
	readonly #fuel: number;
	readonly #maxBytes: number;
	#nextId = 0;
	#busy = false;
	#closed = false;
	#failure?: Error;

	private constructor(program: PreparedProgram, options: FolioOptions) {
		this.memory = options.memory;
		this.#program = program;
		this.#fuel = options.fuel ?? 100_000_000;
		this.#maxBytes = options.maxTransactionBytes ?? 262_144;
		if (!Number.isInteger(this.#fuel) || this.#fuel < 2 || this.#fuel > 2_147_483_647) throw new RangeError('invalid fuel');
		if (!Number.isInteger(this.#maxBytes) || this.#maxBytes < 1) throw new RangeError('invalid transaction budget');
		const native = new WebAssembly.Module(Uint8Array.from(program.original));
		const imports = { ...options.imports };
		for (const item of WebAssembly.Module.imports(native)) {
			if (item.kind !== 'memory') continue;
			imports[item.module] = { ...imports[item.module], [item.name]: this.memory };
		}
		this.#instance = new WebAssembly.Instance(native, imports);
		if (!WebAssembly.Module.imports(native).some((item) => item.kind === 'memory')) {
			const own = Object.values(this.#instance.exports).find((value) => value instanceof WebAssembly.Memory);
			if (own instanceof WebAssembly.Memory) this.memory = own;
		}
	}

	static async open(program: PreparedProgram, options: FolioOptions): Promise<Folio> {
		const size = options.workers ?? Math.min(4, availableParallelism());
		if (!Number.isInteger(size) || size < 1 || size > 64) throw new RangeError('invalid worker count');
		const pool = new Folio(program, options);
		if (!program.transactional) return pool;
		if (!(options.memory.buffer instanceof SharedArrayBuffer)) throw new TypeError('physical sharing requires shared memory');
		const module = new WebAssembly.Module(Uint8Array.from(program.transactional));
		const memoryImport = WebAssembly.Module.imports(module).find((item) => item.kind === 'memory')!;
		try {
			await Promise.all(Array.from({ length: size }, () => new Promise<void>((resolve, reject) => {
				const worker = new Worker(new URL('./worker.ts', import.meta.url), {
					workerData: { module, memory: pool.memory, importModule: memoryImport.module, importName: memoryImport.name }
				});
				pool.#workers.push(worker);
				worker.on('message', (message) => {
					if (message.ready) {
						pool.threadIds.push(message.threadId);
						resolve();
					} else {
						const pending = pool.#pending.get(message.id);
						pool.#pending.delete(message.id);
						pending?.resolve(message);
					}
				});
				const fail = (error: Error) => {
					pool.#failure = error;
					reject(error);
					for (const pending of pool.#pending.values()) pending.reject(error);
					pool.#pending.clear();
				};
				worker.on('error', fail);
				worker.on('exit', (code) => {
					if (!pool.#closed) fail(new Error(`isolate exited with code ${code}`));
				});
			})));
			return pool;
		} catch (error) {
			await pool.close();
			throw error;
		}
	}

	#native(call: Call): unknown {
		const entry = this.#instance.exports[call.export];
		if (typeof entry !== 'function') throw new TypeError(`unknown function export: ${call.export}`);
		return entry(...call.args);
	}

	#dispatch(worker: Worker, call: Call): Promise<TransactionResult> {
		return new Promise((resolve, reject) => {
			const id = this.#nextId++;
			this.#pending.set(id, { resolve, reject });
			worker.postMessage({ id, call, fuel: this.#fuel, maxBytes: this.#maxBytes });
		});
	}

	/** Splits compiler-recognized loops automatically; otherwise runs the original entry. */
	async run(entry: string, args: Call['args'] = [], options: RunOptions = {}): Promise<ExecutionReport> {
		const plan = this.#program.loops[entry];
		const count = plan && typeof args[plan.countParameter] === 'number' ? Number(args[plan.countParameter]) >>> 0 : 0;
		if (!plan || count < 2 || !args.every((arg) => typeof arg === 'number') || this.#workers.length < 2 || options.parallel === 'off') {
			return this.runAll([{ export: entry, args }], { parallel: 'off' });
		}
		const regions = Math.min(count, this.#workers.length);
		const calls: Call[] = [];
		let begin = 0;
		for (let index = 0; index < regions; index++) {
			const end = Math.floor(((index + 1) * count) / regions);
			const parameters = [...args];
			parameters[plan.countParameter] = end - begin;
			for (const { parameter, step } of plan.steps) {
				parameters[parameter] = ((Number(args[parameter]) | 0) + Math.imul(begin, step)) | 0;
			}
			calls.push({ export: entry, args: parameters });
			begin = end;
		}
		const report = await this.runAll(calls, options);
		return { ...report, values: [undefined] };
	}

	/** Preserves call order while discovering memory dependencies at runtime. */
	async runAll(calls: readonly Call[], options: RunOptions = {}): Promise<ExecutionReport> {
		if (this.#closed) throw new Error('folio is closed');
		if (this.#failure) throw this.#failure;
		if (this.#busy) throw new Error('memory already has an active run');
		for (const call of calls) {
			if (typeof this.#instance.exports[call.export] !== 'function') throw new TypeError(`unknown function export: ${call.export}`);
		}
		this.#busy = true;
		const report: ExecutionReport = { values: [], workers: this.#workers.length, regions: calls.length, replayed: 0, fallbacks: 0, mode: 'serial' };
		try {
			if (!this.#workers.length || calls.length < 2 || options.parallel === 'off') {
				for (const call of calls) report.values.push(this.#native(call));
				return report;
			}
			report.mode = 'speculative';
			for (let start = 0; start < calls.length; start += this.#workers.length) {
				const batch = calls.slice(start, start + this.#workers.length);
				const outcomes = await Promise.allSettled(batch.map((call, index) => this.#dispatch(this.#workers[index]!, call)));
				const failure = outcomes.find((outcome) => outcome.status === 'rejected');
				if (failure?.status === 'rejected') {
					await this.close();
					throw failure.reason;
				}
				const dirty = new Set<number>();
				const bytes = new Uint8Array(this.memory.buffer);
				for (let index = 0; index < batch.length; index++) {
					const outcome = outcomes[index]!;
					if (outcome.status !== 'fulfilled') throw new Error('unreachable outcome');
					const result = outcome.value;
					if (result.exhausted || result.reads.some((address) => dirty.has(address))) {
						if (result.exhausted) report.fallbacks++; else report.replayed++;
						// replay uses tracking so later validations include its actual writes
						const replay = await this.#dispatch(this.#workers[0]!, batch[index]!);
						if (replay.exhausted) {
							report.values.push(this.#native(batch[index]!));
							for (let rest = index + 1; rest < batch.length; rest++) report.values.push(this.#native(batch[rest]!));
							break;
						}
						for (const [address, value] of replay.writes) { bytes[address] = value; dirty.add(address); }
						throwTrap(replay);
						report.values.push(replay.value);
					} else {
						for (const [address, value] of result.writes) { bytes[address] = value; dirty.add(address); }
						throwTrap(result);
						report.values.push(result.value);
					}
				}
			}
			return report;
		} finally {
			this.#busy = false;
		}
	}

	async close(): Promise<void> {
		if (this.#closed) return;
		this.#closed = true;
		for (const pending of this.#pending.values()) pending.reject(new Error('folio is closed'));
		this.#pending.clear();
		await Promise.all(this.#workers.map((worker) => worker.terminate()));
	}
}
