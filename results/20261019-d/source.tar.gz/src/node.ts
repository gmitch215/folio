import { availableParallelism } from 'node:os';
import { Worker } from 'node:worker_threads';
import type { PreparedProgram } from './compiler.ts';
import type { NativePlan } from './guards.ts';
import type { TransactionResult } from './transaction.ts';
import { memoryImports } from './memory.ts';

interface Jspi {
	Suspending?: new (fn: (...args: any[]) => Promise<any>) => WebAssembly.ImportValue;
	promising?: (fn: CallableFunction) => (...args: any[]) => Promise<unknown>;
}

/** Wraps an asynchronous host import for Wasm stack suspension. */
export function suspending<Args extends unknown[], Value>(
	fn: (...args: Args) => Promise<Value>
): WebAssembly.ImportValue {
	const runtime = WebAssembly as typeof WebAssembly & Jspi;
	if (!runtime.Suspending) throw new Error('this runtime does not support JSPI');
	return new runtime.Suspending(fn);
}

export type ProgramInput = PreparedProgram | Uint8Array | ArrayBuffer | WebAssembly.Module;

export interface Call {
	export: string;
	args: unknown[];
}

export interface RunOptions {
	parallel?: 'auto' | 'off' | 'speculate';
}

export interface ExecutionReport {
	values: unknown[];
	workers: number;
	regions: number;
	replayed: number;
	fallbacks: number;
	mode: 'serial' | 'speculative' | 'native-shared';
	reason?: 'requested' | 'small-workload' | 'no-parallel-plan' | 'single-region' | 'unsupported-module' | 'dependency' | 'guard-failed' | 'opaque-input';
	profile?: ExecutionProfile;
}

export interface ExecutionProfile {
	wallMs: number;
	workerWallMs: number[];
	workerCpuMs: number[];
	validationMs: number;
	commitMs: number;
	replayMs: number;
	readBytes: number;
	writeBytes: number;
}

export interface FolioOptions {
	memory?: WebAssembly.Memory;
	workers?: number;
	imports?: WebAssembly.Imports;
	fuel?: number;
	maxTransactionBytes?: number;
	minimumParallelWork?: number;
	promising?: readonly string[];
	/** Collect execution timings; disabled by default to keep the hot path small. */
	profile?: boolean;
}

interface Pending {
	resolve(value: TransactionResult): void;
	reject(error: Error): void;
}

function throwTrap(result: TransactionResult): void {
	if (!result.trap) return;
	if (result.errorKind === 'TypeError') throw new TypeError(result.trap);
	if (result.errorKind === 'RangeError') throw new RangeError(result.trap);
	throw new WebAssembly.RuntimeError(result.trap);
}

/** A same-process isolate group; callers give it exclusive memory access during each run. */
export class Folio {
	get capabilities() {
		return Object.freeze({
			physicalSharing: this.#workers.length ? ('same-process' as const) : ('none' as const),
			automaticRegions: this.#workers.length ? ('counted-loops' as const) : ('none' as const),
			dependence: this.#workers.length ? ('ordered-validation' as const) : ('serial' as const)
		});
	}
	get exports(): WebAssembly.Exports {
		return this.#instance.exports;
	}
	get memory(): WebAssembly.Memory {
		if (!this.#memory) throw new Error('program has no single bound or exported memory; use memories');
		return this.#memory;
	}
	get memories(): Readonly<Record<string, WebAssembly.Memory>> { return this.#memories; }
	get diagnostics(): readonly string[] { return this.#program.reasons; }
	#memory?: WebAssembly.Memory;
	readonly #memories: Record<string, WebAssembly.Memory> = {};
	readonly #promising = new Map<string, (...args: any[]) => Promise<unknown>>();
	readonly #nativePending = new Set<Promise<unknown>>();
	readonly threadIds: number[] = [];
	readonly #program: PreparedProgram;
	readonly #instance: WebAssembly.Instance;
	readonly #workers: Worker[] = [];
	readonly #pending = new Map<number, Pending>();
	readonly #fuel: number;
	readonly #maxBytes: number;
	readonly #minimumWork: number;
	readonly #profile: boolean;
	#nextId = 0;
	#busy = false;
	#closed = false;
	#closing?: Promise<void>;
	#failure?: Error;

	private constructor(program: PreparedProgram, options: FolioOptions) {
		this.#memory = options.memory;
		this.#program = program;
		this.#fuel = options.fuel ?? 100_000_000;
		this.#maxBytes = options.maxTransactionBytes ?? 262_144;
		this.#minimumWork = options.minimumParallelWork ?? 100_000;
		this.#profile = options.profile ?? false;
		if (!Number.isInteger(this.#fuel) || this.#fuel < 2 || this.#fuel > 2_147_483_647)
			throw new RangeError('invalid fuel');
		if (!Number.isInteger(this.#maxBytes) || this.#maxBytes < 1)
			throw new RangeError('invalid transaction budget');
		if (!Number.isFinite(this.#minimumWork) || this.#minimumWork < 0)
			throw new RangeError('invalid work threshold');
		const native = program.compiled ?? new WebAssembly.Module(Uint8Array.from(program.original));
		const imports = { ...options.imports };
		const imported = WebAssembly.Module.imports(native).filter((item) => item.kind === 'memory');
		if (imported.length > 1 && options.memory) throw new TypeError('bind multiple memories by name in imports');
		let descriptors: ReturnType<typeof memoryImports> = [];
		if (imported.some((item) => !options.memory && !imports[item.module]?.[item.name])) {
			try { descriptors = memoryImports(program.original); } catch {}
		}
		for (const item of imported) {
			let bound = options.memory ?? imports[item.module]?.[item.name];
			if (!bound) {
				const descriptor = descriptors.find((value) => value.module === item.module && value.name === item.name);
				if (!descriptor || descriptor.memory64) throw new TypeError(`provide imported memory ${item.module}.${item.name}`);
				bound = new WebAssembly.Memory({ initial: descriptor.initial, ...(descriptor.maximum === undefined ? {} : { maximum: descriptor.maximum }), shared: descriptor.shared });
			}
			if (!(bound instanceof WebAssembly.Memory)) throw new TypeError(`invalid imported memory ${item.module}.${item.name}`);
			imports[item.module] = { ...imports[item.module], [item.name]: bound };
			this.#memories[`${item.module}.${item.name}`] = bound;
			if (imported.length === 1) this.#memory = bound;
		}
		const runtime = WebAssembly as typeof WebAssembly & Jspi;
		const suspends = runtime.Suspending && Object.values(imports).some((namespace) => Object.values(namespace).some((value) => value instanceof runtime.Suspending!));
		const promising = options.promising ?? (suspends ? WebAssembly.Module.exports(native).filter((value) => value.kind === 'function').map(({ name }) => name) : []);
		for (const name of promising) {
			if (!WebAssembly.Module.exports(native).some((value) => value.name === name && value.kind === 'function')) throw new TypeError(`unknown promising export: ${name}`);
			if (!runtime.promising) throw new Error('this runtime does not support JSPI');
		}
		this.#instance = new WebAssembly.Instance(native, imports);
		for (const [name, value] of Object.entries(this.#instance.exports)) {
			if (value instanceof WebAssembly.Memory) this.#memories[`exports.${name}`] = value;
		}
		if (!imported.length) {
			const own = Object.values(this.#instance.exports).filter((value) => value instanceof WebAssembly.Memory);
			if (own.length === 1) this.#memory = own[0] as WebAssembly.Memory;
		}
		Object.freeze(this.#memories);
		for (const name of promising) {
			const entry = this.#instance.exports[name];
			this.#promising.set(name, runtime.promising!(entry as CallableFunction));
		}
	}

	static async open(input: ProgramInput, options: FolioOptions = {}): Promise<Folio> {
		const program: PreparedProgram = input instanceof WebAssembly.Module
			? { original: new Uint8Array(), compiled: input, loops: {}, reasons: ['compiled module has no inspectable source bytes'] }
			: input instanceof Uint8Array || input instanceof ArrayBuffer
				? (await import('./compiler.ts')).prepare(input instanceof Uint8Array ? input : new Uint8Array(input))
				: input;
		const size = options.workers ?? Math.min(4, availableParallelism());
		if (!Number.isInteger(size) || size < 1 || size > 64)
			throw new RangeError('invalid worker count');
		const pool = new Folio(program, options);
		if (!program.transactional) return pool;
		if (!(pool.memory.buffer instanceof SharedArrayBuffer))
			throw new TypeError('physical sharing requires shared memory');
		const module = new WebAssembly.Module(Uint8Array.from(program.transactional));
		const nativeModule = new WebAssembly.Module(Uint8Array.from(program.original));
		const memoryImport = WebAssembly.Module.imports(module).find(
			(item) => item.kind === 'memory'
		)!;
		try {
			await Promise.all(
				Array.from(
					{ length: size },
					() =>
						new Promise<void>((resolve, reject) => {
							const extension = import.meta.url.endsWith('.ts') ? 'ts' : 'js';
							const worker = new Worker(
								new URL(`./worker.${extension}`, import.meta.url),
								{
									workerData: {
										module,
										nativeModule,
										memory: pool.memory,
										importModule: memoryImport.module,
										importName: memoryImport.name
									}
								}
							);
							pool.#workers.push(worker);
							worker.on('message', (message) => {
								if (message.ready) {
									pool.threadIds.push(message.threadId);
									resolve();
								} else {
									const pending = pool.#pending.get(message.id);
									pool.#pending.delete(message.id);
									pending?.resolve(message);
								}
							});
							const fail = (error: Error) => {
								pool.#failure = error;
								reject(error);
								for (const pending of pool.#pending.values()) pending.reject(error);
								pool.#pending.clear();
							};
							worker.on('error', fail);
							worker.on('exit', (code) => {
								if (!pool.#closed)
									fail(new Error(`isolate exited with code ${code}`));
							});
						})
				)
			);
			return pool;
		} catch (error) {
			await pool.close();
			throw error;
		}
	}

	async #native(call: Call): Promise<{ value: unknown }> {
		if (this.#closed) throw new Error('folio is closed');
		const entry = this.#instance.exports[call.export];
		if (typeof entry !== 'function')
			throw new TypeError(`unknown function export: ${call.export}`);
		const wrapped = this.#promising.get(call.export);
		if (!wrapped) return { value: entry(...call.args) };
		const pending = wrapped(...call.args);
		this.#nativePending.add(pending);
		try { return { value: await pending }; }
		finally { this.#nativePending.delete(pending); }
	}

	#dispatch(worker: Worker, call: Call, native = false): Promise<TransactionResult> {
		return new Promise((resolve, reject) => {
			const id = this.#nextId++;
			this.#pending.set(id, { resolve, reject });
			try {
				worker.postMessage({ id, call, native, profile: this.#profile, fuel: this.#fuel, maxBytes: this.#maxBytes });
			} catch (error) {
				this.#pending.delete(id);
				reject(error);
			}
		});
	}

	/** Splits compiler-recognized loops automatically; otherwise runs the original entry. */
	async run(
		entry: string,
		args: Call['args'] = [],
		options: RunOptions = {}
	): Promise<ExecutionReport> {
		const plan = this.#program.loops[entry];
		const proved = this.#program.native?.[entry];
		const numeric = args.every((arg) => typeof arg === 'number');
		const count =
			numeric && plan && typeof args[plan.countParameter] === 'number'
				? Number(args[plan.countParameter]) >>> 0
				: 0;
		const work = numeric ? proved?.workParameters.reduce(
			(value, parameter) => value * (Number(args[parameter]) >>> 0),
			count
		) : undefined;
		if (
			!plan ||
			count < 2 ||
			!numeric ||
			this.#workers.length < 2 ||
			options.parallel === 'off'
		) {
			const report = await this.runAll([{ export: entry, args }], { parallel: 'off' });
			report.reason = options.parallel === 'off' ? 'requested' : !numeric ? 'opaque-input' : !this.#workers.length ? 'unsupported-module' : !plan ? 'no-parallel-plan' : 'single-region';
			return report;
		}
		if (options.parallel !== 'speculate' && work !== undefined && work < this.#minimumWork) {
			const report = await this.runAll([{ export: entry, args }], { parallel: 'off' });
			report.reason = 'small-workload';
			return report;
		}
		const regions = Math.min(count, this.#workers.length);
		const calls: Call[] = [];
		let begin = 0;
		for (let index = 0; index < regions; index++) {
			const end = Math.floor(((index + 1) * count) / regions);
			const parameters = [...args];
			parameters[plan.countParameter] = end - begin;
			for (const { parameter, step } of plan.steps) {
				parameters[parameter] =
					((Number(args[parameter]) | 0) + Math.imul(begin, step)) | 0;
			}
			calls.push({ export: entry, args: parameters });
			begin = end;
		}
		const disjoint = proved && options.parallel !== 'speculate' && this.#disjoint(calls, proved, plan);
		const report =
			disjoint
				? await this.#nativeRegions(calls)
				: await this.runAll(calls, options);
		if (proved && !disjoint && options.parallel !== 'speculate' && !report.reason) report.reason = 'guard-failed';
		return { ...report, values: [undefined] };
	}

	#disjoint(
		calls: Call[],
		proved: NativePlan,
		plan: NonNullable<PreparedProgram['loops'][string]>
	): boolean {
		const footprints = calls.map((call) =>
			proved.accesses.map((access) => {
				const first = Number(call.args[access.parameter]) >>> 0;
				const count = Number(call.args[plan.countParameter]) >>> 0;
				const step =
					plan.steps.find((item) => item.parameter === access.parameter)?.step ?? 0;
				const last = first + (count - 1) * step;
				return {
					start: Math.min(first, last) + access.offset,
					end: Math.max(first, last) + access.offset + access.bytes,
					write: access.write,
					wrap: last < 0 || last > 0xffffffff
				};
			})
		);
		for (let i = 0; i < footprints.length; i++) {
			for (const range of footprints[i]!) {
				if (range.wrap || range.start < 0 || range.end > this.memory.buffer.byteLength)
					return false;
				for (const other of footprints.slice(0, i).flat()) {
					if (
						(range.write || other.write) &&
						range.start < other.end &&
						other.start < range.end
					)
						return false;
				}
			}
		}
		return true;
	}

	async #nativeRegions(calls: Call[]): Promise<ExecutionReport> {
		if (this.#closed) throw new Error('folio is closed');
		if (this.#failure) throw this.#failure;
		if (this.#busy) throw new Error('memory already has an active run');
		this.#busy = true;
		const started = this.#profile ? performance.now() : 0;
		try {
			const outcomes = await Promise.allSettled(
				calls.map((call, index) => this.#dispatch(this.#workers[index]!, call, true))
			);
			for (const outcome of outcomes) {
				if (outcome.status === 'rejected' || outcome.value.trap) {
					this.#failure = new Error(
						'native region failed; arena may contain partial writes'
					);
					await this.close();
					throw this.#failure;
				}
			}
			const results = outcomes.map((outcome) => (outcome as PromiseFulfilledResult<TransactionResult>).value);
			return {
				values: [],
				workers: this.#workers.length,
				regions: calls.length,
				replayed: 0,
				fallbacks: 0,
				mode: 'native-shared',
				...(this.#profile ? { profile: { wallMs: performance.now() - started, workerWallMs: results.map((r) => r.timing!.wallMs), workerCpuMs: results.map((r) => r.timing!.cpuMs), validationMs: 0, commitMs: 0, replayMs: 0, readBytes: 0, writeBytes: 0 } } : {})
			};
		} finally {
			this.#busy = false;
		}
	}

	/** Preserves call order while discovering memory dependencies at runtime. */
	async runAll(calls: readonly Call[], options: RunOptions = {}): Promise<ExecutionReport> {
		if (this.#closed) throw new Error('folio is closed');
		if (this.#failure) throw this.#failure;
		if (this.#busy) throw new Error('memory already has an active run');
		for (const call of calls) {
			if (typeof this.#instance.exports[call.export] !== 'function')
				throw new TypeError(`unknown function export: ${call.export}`);
		}
		this.#busy = true;
		const started = this.#profile ? performance.now() : 0;
		const report: ExecutionReport = {
			values: [],
			workers: this.#workers.length,
			regions: calls.length,
			replayed: 0,
			fallbacks: 0,
			mode: 'serial'
		};
		const profile: ExecutionProfile | undefined = this.#profile ? { wallMs: 0, workerWallMs: [], workerCpuMs: [], validationMs: 0, commitMs: 0, replayMs: 0, readBytes: 0, writeBytes: 0 } : undefined;
		if (profile) report.profile = profile;
		const observe = (result: TransactionResult) => {
			if (!profile) return;
			profile.workerWallMs.push(result.timing!.wallMs);
			profile.workerCpuMs.push(result.timing!.cpuMs);
			profile.readBytes += result.reads.length;
			profile.writeBytes += result.writes.length;
		};
		const commit = (result: TransactionResult, bytes: Uint8Array, dirty: Set<number>) => {
			const before = profile ? performance.now() : 0;
			for (const [address, value] of result.writes) { bytes[address] = value; dirty.add(address); }
			if (profile) profile.commitMs += performance.now() - before;
		};
		try {
			const opaque = calls.some((call) => call.args.some((arg) => typeof arg !== 'number' && typeof arg !== 'bigint'));
			if (!this.#workers.length || calls.length < 2 || options.parallel === 'off' || opaque) {
				report.reason = options.parallel === 'off' ? 'requested' : opaque ? 'opaque-input' : !this.#workers.length ? 'unsupported-module' : 'single-region';
				for (const call of calls) report.values.push((await this.#native(call)).value);
				return report;
			}
			report.mode = 'speculative';
			for (let start = 0; start < calls.length; start += this.#workers.length) {
				const batch = calls.slice(start, start + this.#workers.length);
				const outcomes = await Promise.allSettled(
					batch.map((call, index) => this.#dispatch(this.#workers[index]!, call))
				);
				const failure = outcomes.find((outcome) => outcome.status === 'rejected');
				if (failure?.status === 'rejected') {
					await this.close();
					throw failure.reason;
				}
				const dirty = new Set<number>();
				const bytes = new Uint8Array(this.memory.buffer);
				for (let index = 0; index < batch.length; index++) {
					const outcome = outcomes[index]!;
					if (outcome.status !== 'fulfilled') throw new Error('unreachable outcome');
					const result = outcome.value;
					observe(result);
					const validationStart = profile ? performance.now() : 0;
					const conflict = result.reads.some((address) => dirty.has(address));
					if (profile) profile.validationMs += performance.now() - validationStart;
					if (result.exhausted || conflict) {
						if (result.exhausted) report.fallbacks++;
						else { report.replayed++; report.reason = 'dependency'; }
						// replay uses tracking so later validations include its actual writes
						const replayStart = profile ? performance.now() : 0;
						const replay = await this.#dispatch(this.#workers[0]!, batch[index]!);
						observe(replay);
						if (profile) profile.replayMs += performance.now() - replayStart;
						if (replay.exhausted) {
							report.values.push((await this.#native(batch[index]!)).value);
							for (let rest = index + 1; rest < batch.length; rest++)
								report.values.push((await this.#native(batch[rest]!)).value);
							break;
						}
						commit(replay, bytes, dirty);
						throwTrap(replay);
						report.values.push(replay.value);
					} else {
						commit(result, bytes, dirty);
						throwTrap(result);
						report.values.push(result.value);
					}
				}
			}
			return report;
		} finally {
			if (profile) profile.wallMs = performance.now() - started;
			this.#busy = false;
		}
	}

	close(): Promise<void> {
		if (this.#closing) return this.#closing;
		this.#closed = true;
		for (const pending of this.#pending.values()) pending.reject(new Error('folio is closed'));
		this.#pending.clear();
		this.#closing = Promise.all([...this.#workers.map((worker) => worker.terminate()), ...Array.from(this.#nativePending, (pending) => pending.catch(() => {}))]).then(
			() => {}
		);
		return this.#closing;
	}

	[Symbol.asyncDispose](): Promise<void> { return this.close(); }
}
