#!/usr/bin/env bash
set -euC
cd "$(dirname "$0")/.."
held=0
label=folio-scaling-20261019-d
finish() {
	code=$?
	if [ "$held" = 1 ]; then
		rmdir /tmp/paisley-timing.lock
		bash "$HOME/gmux-rig/bin/sweep.sh" end "$label"
	fi
	printf '%s\n' "$code" > results/exit-code
	touch results/finished
}
trap finish EXIT
mkdir /tmp/paisley-timing.lock
held=1
bash "$HOME/gmux-rig/bin/sweep.sh" start "$label"
nice -n 19 taskset -c 4-11 "$HOME/.nvm/versions/node/v26.10.0/bin/node" --max-old-space-size=128 scripts/scaling-probe.ts > results/scaling.jsonl
free -h
df -h /
du -sh .
