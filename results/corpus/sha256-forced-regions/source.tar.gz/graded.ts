// per-call dispatch cost from the graded-conflicts Ryzen summary (medians only; no timing run).
import { readFileSync } from 'node:fs';

const summary = JSON.parse(
	readFileSync(`${process.cwd()}/results/execution/graded-conflicts/ryzen.summary.json`, 'utf8')
);
for (const [group, arms] of Object.entries<any>(summary.groups)) {
	const row = Object.entries<any>(arms).map(
		([arm, stats]) => `${arm}:${stats.wallMs.median.toFixed(4)}ms(n=${stats.wallMs.n})`
	);
	const speed = Object.entries<any>(arms)
		.filter(([arm]) => arm.startsWith('forced-8'))
		.map(([arm, stats]) => `${arm} speedup ${stats.pairedSpeedup.median.toFixed(4)}`);
	console.log(group, '|', row.join(' '), '|', speed.join(' '));
}
