// arithmetic for the study README. Reads inspect.json and the recorded raw and summary files only.
import { readFileSync } from 'node:fs';

const REPO = process.cwd();
const inspect = JSON.parse(readFileSync(`${REPO}/build/research/sha256-forced/inspect.json`, 'utf8'));
const regions = inspect.regions as any[];

const entry = regions.reduce((s, r) => s + r.entryInvocations, 0);
const compute = regions.reduce((s, r) => s + r.entryInvocations * r.computeUnits, 0);
const accesses = regions.reduce((s, r) => s + r.entryInvocations * r.trackedAccesses, 0);
const singleton = regions.reduce((s, r) => s + r.singletonBatches, 0);
const multi = regions.reduce((s, r) => s + r.inMultiRegionBatches, 0);
console.log('entry dispatches', entry, 'singleton', singleton, 'multi', multi);
console.log('compute units', compute, 'per region', (compute / entry).toFixed(3));
console.log('tracked accesses', accesses, 'per region', (accesses / entry).toFixed(3));
console.log('mean net units per region', ((compute - 3600 * accesses) / entry).toFixed(1));

const byCaller = new Map<string, number>();
for (const r of regions)
	for (const c of r.callers) {
		const key = `${c.caller}`;
		byCaller.set(key, (byCaller.get(key) ?? 0) + r.entryInvocations / r.callers.length);
	}
console.log('entry dispatches by caller', JSON.stringify(Object.fromEntries(byCaller)));

// native median from the forced-admission raw file (sha256 native samples, one call each)
const raw = readFileSync(`${REPO}/results/corpus/forced-admission-complete/raw.jsonl`, 'utf8')
	.split('\n')
	.filter(Boolean)
	.map((line) => JSON.parse(line))
	.filter((row) => row.kind === 'sample' && row.case === 'sha256');
const median = (values: number[]) => {
	const sorted = [...values].sort((a, b) => a - b);
	const mid = sorted.length >> 1;
	return sorted.length % 2 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2;
};
const walls = (arm: string) => raw.filter((row) => row.arm === arm).map((row) => row.wallMs);
const nativeMs = median(walls('native'));
const folio8Ms = median(walls('folio-8'));
console.log('native median ms', nativeMs, 'folio-8 median ms', folio8Ms);
console.log('native ns per region', ((nativeMs * 1e6) / entry).toFixed(3));
console.log('folio-8 us per region', ((folio8Ms * 1e3) / entry).toFixed(3));
console.log('folio-8 over native (median ratio)', (folio8Ms / nativeMs).toFixed(1));

// graded-conflicts Ryzen summary, medians per call: excess over native divided by 64 calls
const graded = JSON.parse(
	readFileSync(`${REPO}/results/execution/graded-conflicts/ryzen.summary.json`, 'utf8')
).groups;
const perCall = (rounds: number) => {
	const cell = graded[`{"rounds":${rounds},"fraction":0,"calls":64}`];
	const excessMs = cell['forced-8'].wallMs.median - cell.native.wallMs.median;
	return {
		nativeUsPerCall: (cell.native.wallMs.median * 1e3) / 64,
		forced8UsPerCall: (cell['forced-8'].wallMs.median * 1e3) / 64,
		excessUsPerCall: (excessMs * 1e3) / 64,
		speedup: cell['forced-8'].pairedSpeedup.median
	};
};
console.log('graded 16 rounds', JSON.stringify(perCall(16)));
console.log('graded 1024 rounds', JSON.stringify(perCall(1024)));

const perFunction = new Map<string, { loads: number; stores: number; loops: number; calls: number }>();
for (const f of inspect.functions as any[])
	perFunction.set(f.name, { loads: f.loads, stores: f.stores, loops: f.loops, calls: f.calls });
console.log(JSON.stringify(Object.fromEntries(perFunction)));
