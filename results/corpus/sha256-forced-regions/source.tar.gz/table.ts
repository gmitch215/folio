// markdown table of the regions from inspect.json.
import { readFileSync } from 'node:fs';

const inspect = JSON.parse(
	readFileSync(new URL('./inspect.json', import.meta.url), 'utf8')
);
console.log(
	'| Region | Target | Called from | Loads / stores | Est. compute / tracked accesses | Entry dispatches | Alone / in batches | Init dispatches |'
);
console.log('| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: |');
for (const r of inspect.regions) {
	const from = r.callers.map((c: any) => `${c.caller}@${c.line}`).join(', ') || 'none';
	console.log(
		`| ${r.region} | ${r.target} (${r.kind}) | ${from} | ${r.staticLoads} / ${r.staticStores} | ${r.computeUnits} / ${r.trackedAccesses} | ${r.entryInvocations.toLocaleString('en-US')} | ${r.singletonBatches.toLocaleString('en-US')} / ${r.inMultiRegionBatches.toLocaleString('en-US')} | ${r.initializeInvocations} |`
	);
}
