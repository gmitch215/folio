// what the SHA-256 forced regions are. Functional counts and static shape only; no timing.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import binaryen from 'binaryen';
import { prepare } from './src/compiler.ts';
import { prepareTracked } from './src/compiler.ts';
import { extract } from './src/extract.ts';

const REPO = process.cwd();
const OUT = `${REPO}/build/research/sha256-forced`;
const ACCESS_COST = 3600; // src/extract.ts; not exported

const bytes = new Uint8Array(readFileSync(`${REPO}/build/research/corpus/artifacts/sha256.wasm`));

// the copy writes named WAT of the coordinator and worker; binary round trips drop names
process.env.FOLIO_1B_WAT = `${OUT}/sha256`;
const prepared = prepare(bytes, { minimumRegionWork: 0 });
const observed: { name: string; kind: string; compute: number; accesses: number; index?: number }[] =
	[];
const copied = extract(Uint8Array.from(bytes), prepareTracked, {
	minimumRegionWork: 0,
	observed: (site: any) => observed.push(site)
})!;
const control = prepared.control!;
assert.ok(Buffer.from(control.coordinator).equals(Buffer.from(copied.coordinator)));
assert.ok(Buffer.from(control.workerOriginal).equals(Buffer.from(copied.workerOriginal)));

// the original module with names, for the per-function table
const originalWat = binaryen.readBinary(bytes);
originalWat.setFeatures(binaryen.Features.All);
writeFileSync(`${OUT}/sha256.original.wat`, originalWat.emitText());

type Scan = {
	funcs: Map<string, { start: number; end: number }>;
	calls: { callee: string; func: string; loops: string[]; line: number }[];
	lines: string[];
};
// one pass over the text: module-level funcs, every call with its enclosing loop labels
function scan(text: string): Scan {
	const lines = text.split('\n');
	const funcs = new Map<string, { start: number; end: number }>();
	const calls: Scan['calls'] = [];
	const stack: { kind: 'func' | 'loop'; name: string; depth: number }[] = [];
	let depth = 0,
		current: string | undefined,
		quoted = false;
	lines.forEach((line, n) => {
		for (let i = 0; i < line.length; i++) {
			const ch = line[i];
			if (quoted) {
				if (ch === '\\') i++;
				else if (ch === '"') quoted = false;
				continue;
			}
			if (ch === '"') quoted = true;
			else if (ch === '(') {
				depth++;
				const m = /^\((\w+)(?:\s+(\$[^\s()]+))?/.exec(line.slice(i));
				if (!m) continue;
				if (m[1] === 'func' && depth === 2 && m[2]) {
					current = m[2];
					stack.push({ kind: 'func', name: m[2], depth });
					funcs.set(m[2], { start: n, end: n });
				} else if (m[1] === 'loop')
					stack.push({ kind: 'loop', name: m[2] ?? '', depth });
				else if (m[1] === 'call' && m[2] && current)
					calls.push({
						callee: m[2],
						func: current,
						loops: stack.filter((s) => s.kind === 'loop').map((s) => s.name),
						line: n + 1
					});
			} else if (ch === ')') {
				while (stack.length && stack.at(-1)!.depth === depth) {
					const top = stack.pop()!;
					if (top.kind === 'func') {
						current = undefined;
						funcs.get(top.name)!.end = n;
					}
				}
				depth--;
			}
		}
	});
	return { funcs, calls, lines };
}

const coordinatorScan = scan(readFileSync(`${OUT}/sha256.coordinator.wat`, 'utf8'));
const workerScan = scan(readFileSync(`${OUT}/sha256.worker.wat`, 'utf8'));
const originalScan = scan(readFileSync(`${OUT}/sha256.original.wat`, 'utf8'));

// region k wraps one callee; the coordinator and worker wrappers must agree
const callee = (s: Scan, func: string) => {
	const calls = s.calls.filter((c) => c.func === func);
	assert.equal(calls.length, 1, `${func} wraps one call`);
	return calls[0]!.callee;
};
const targets = control.regions.map((r) => callee(coordinatorScan, `$${r.exportName}`));
assert.deepEqual(
	targets,
	control.regions.map((r) => callee(workerScan, `$${r.exportName}`))
);

// enqueue sites: region k is enqueued from the controller that calls $__folio_enqueue_k
const sites = control.regions.map(() => [] as { caller: string; loops: string[]; line: number }[]);
for (const c of coordinatorScan.calls) {
	const m = /^\$__folio_enqueue_(\d+)$/.exec(c.callee);
	if (m) sites[Number(m[1])]!.push({ caller: c.func, loops: c.loops, line: c.line });
}

// static shape of one body: loads, stores, loops and bulk memory ops in its text
function shape(s: Scan, name: string) {
	const span = s.funcs.get(name);
	if (!span) return undefined;
	const text = s.lines.slice(span.start, span.end + 1).join('\n');
	return {
		loads: (text.match(/\.load/g) ?? []).length,
		stores: (text.match(/\.store/g) ?? []).length,
		loops: (text.match(/\(loop /g) ?? []).length,
		bulk: (text.match(/memory\.(copy|fill)/g) ?? []).length,
		calls: (text.match(/\(call /g) ?? []).length
	};
}

// memory import limits and the shared flag, for the counting harness
function uint(b: Uint8Array, c: { at: number }): number {
	let result = 0,
		shift = 0,
		byte: number;
	do {
		byte = b[c.at++]!;
		result += (byte & 127) * 2 ** shift;
		shift += 7;
	} while (byte & 128);
	return result;
}
function envMemoryImport(b: Uint8Array) {
	const c = { at: 8 };
	const text = new TextDecoder();
	while (c.at < b.length) {
		const id = b[c.at++]!;
		const size = uint(b, c);
		const end = c.at + size;
		if (id === 2) {
			const count = uint(b, c);
			for (let i = 0; i < count; i++) {
				const moduleLength = uint(b, c);
				const moduleName = text.decode(b.subarray(c.at, c.at + moduleLength));
				c.at += moduleLength;
				const fieldLength = uint(b, c);
				const field = text.decode(b.subarray(c.at, c.at + fieldLength));
				c.at += fieldLength;
				const kind = b[c.at++]!;
				if (kind === 0) uint(b, c);
				else if (kind === 1) {
					c.at++;
					const flags = b[c.at++]!;
					uint(b, c);
					if (flags & 1) uint(b, c);
				} else if (kind === 2) {
					const flagsAt = c.at;
					const flags = b[c.at++]!;
					const min = uint(b, c);
					const max = flags & 1 ? uint(b, c) : undefined;
					if (moduleName === 'env' && field === 'memory')
						return { flagsAt, flags, min, max };
				} else c.at += 2;
			}
		}
		c.at = end;
	}
	throw new Error('no env.memory import');
}
function sharedCopy(b: Uint8Array) {
	const copy = b.slice();
	const { flagsAt, flags } = envMemoryImport(copy);
	assert.ok(flags & 1, 'shared memory needs a maximum');
	copy[flagsAt] = flags | 2;
	return copy;
}

const digest = (view: Uint8Array) => createHash('sha256').update(view).digest('hex');
const limits = envMemoryImport(bytes);
assert.ok(limits.max !== undefined);
const memoryOf = (shared: boolean) =>
	new WebAssembly.Memory({ initial: limits.min, maximum: limits.max!, shared });
const math = { sin: Math.sin, cos: Math.cos, floor: Math.floor, sqrt: Math.sqrt };

// native: the original module, initialize then entry, unshared memory as in the corpus worker
const nativeMemory = memoryOf(false);
const native = new WebAssembly.Instance(new WebAssembly.Module(bytes), {
	env: { memory: nativeMemory, ...math }
});
(native.exports.initialize as CallableFunction)();
const nativeValue = (native.exports.entry as CallableFunction)();
const nativeDigest = digest(new Uint8Array(nativeMemory.buffer));

// counting: each enqueue runs the worker's copy of the region in place, in enqueue order, over one
// shared memory. Regions are pure, so this is the serial result; the counts are the dispatches.
// The queue, armed/settle and flush follow src/coordinator.ts: a region waits in the queue until a
// barrier (drain before every controller memory access while `pending` is set) or a poll flushes it.
// A batch of one runs at its owner; a batch of two or more is one dispatch round.
const sharedMemory = memoryOf(true);
const counts = control.regions.map(() => 0);
const width = Number(process.env.FOLIO_1B_WIDTH ?? 8);
const workerInstance = new WebAssembly.Instance(
	new WebAssembly.Module(sharedCopy(copied.workerOriginal)),
	{ env: { memory: sharedMemory } }
);
const pendingGlobal = new WebAssembly.Global({ value: 'i32', mutable: true }, 0);
const queue: { k: number; args: number[] }[] = [];
const batchHistogram: Record<number, number> = {};
const singleton = control.regions.map(() => 0),
	batched = control.regions.map(() => 0);
let armed = false,
	polls = 0,
	flushes = 0;
const settle = () => {
	if (!armed || queue.length) return;
	armed = false;
	pendingGlobal.value = 0;
};
const flush = () => {
	if (!queue.length) return settle();
	const batch = queue.splice(0);
	flushes++;
	batchHistogram[batch.length] = (batchHistogram[batch.length] ?? 0) + 1;
	for (const { k, args } of batch) {
		counts[k]!++;
		(batch.length === 1 ? singleton : batched)[k]!++;
		(workerInstance.exports[copied.regions[k]!.exportName] as CallableFunction)(...args);
	}
	settle();
};
const regionImports = Object.fromEntries(
	copied.regions.map((r, k) => [
		r.importName,
		(...args: number[]) => {
			if (!armed) {
				armed = true;
				pendingGlobal.value = 1;
			}
			queue.push({ k, args });
			if (queue.length >= width * 16) flush();
		}
	])
);
const coordinatorInstance = new WebAssembly.Instance(
	new WebAssembly.Module(sharedCopy(copied.coordinator)),
	{
		env: { memory: sharedMemory, ...math },
		[control.namespace]: {
			barrier: () => flush(),
			poll: () => {
				if (++polls < 1024) return;
				polls = 0;
				flush();
			},
			serial: new WebAssembly.Global({ value: 'i32', mutable: true }, 0),
			pending: pendingGlobal,
			...regionImports
		}
	}
);
(coordinatorInstance.exports.initialize as CallableFunction)();
const leftoverAfterInitialize = queue.length;
flush();
const afterInitialize = counts.reduce((a, b) => a + b, 0);
const countsAtInitialize = [...counts];
const batchesAtInitialize = { ...batchHistogram };
const folioValue = (coordinatorInstance.exports.entry as CallableFunction)();
const leftoverAfterEntry = queue.length;
flush();
const folioDigest = digest(new Uint8Array(sharedMemory.buffer));
const total = counts.reduce((a, b) => a + b, 0);
const singletonTotal = singleton.reduce((a, b) => a + b, 0),
	batchedTotal = batched.reduce((a, b) => a + b, 0);

const perRegion = control.regions.map((region, k) => {
	const target = targets[k]!;
	const inline = /^\$__folio_inline_(\d+)$/.exec(target);
	const name = target.slice(1);
	const estimate = inline
		? observed.find((o) => o.index === Number(inline[1]))
		: observed.find((o) => o.name === name);
	const compute = estimate!.compute,
		accesses = estimate!.accesses;
	const body = shape(workerScan, target)!;
	return {
		region: k,
		export: region.exportName,
		target: name,
		kind: inline ? 'outlined span' : 'whole function',
		callers: sites[k]!.map((s) => ({ caller: s.caller.slice(1), loops: s.loops, line: s.line })),
		estimateKind: estimate!.kind,
		computeUnits: compute,
		trackedAccesses: accesses,
		netUnits: compute - ACCESS_COST * accesses,
		staticLoads: body.loads,
		staticStores: body.stores,
		bodyLoops: body.loops,
		bodyBulk: body.bulk,
		initializeInvocations: countsAtInitialize[k],
		entryInvocations: counts[k]! - countsAtInitialize[k]!,
		singletonBatches: singleton[k],
		inMultiRegionBatches: batched[k]
	};
});

const functions = [...originalScan.funcs.keys()].map((name) => {
	const s = shape(originalScan, name)!;
	return { name: name.slice(1), ...s };
});

const result = {
	prepare: {
		reasons: prepared.reasons,
		controlReasons: prepared.controlReasons ?? [],
		loops: Object.keys(prepared.loops),
		entries: control.entries,
		diagnostics: control.diagnostics,
		regions: control.regions.length
	},
	dynamic: {
		afterInitialize,
		entryDispatches: total - afterInitialize,
		totalDispatches: total,
		folioValue,
		nativeValue,
		memoryMatches: folioDigest === nativeDigest,
		nativeDigest,
		folioDigest,
		leftoverAfterInitialize,
		leftoverAfterEntry,
		width,
		flushes,
		batchHistogram,
		batchesAtInitialize,
		singletonRegions: singletonTotal,
		regionsInMultiRegionBatches: batchedTotal
	},
	functions,
	regions: perRegion
};
writeFileSync(
	`${OUT}/inspect${width === 8 ? '' : `-w${width}`}.json`,
	JSON.stringify(result, null, '\t') + '\n'
);
console.log(JSON.stringify(result.prepare, null, 1));
console.log(JSON.stringify(result.dynamic, null, 1));
console.log(JSON.stringify(result.functions));
for (const r of result.regions)
	console.log(
		[
			r.region,
			r.target,
			r.kind,
			r.callers.map((c) => `${c.caller}@${c.line}[${c.loops.length}]`).join(' '),
			r.computeUnits,
			r.trackedAccesses,
			r.netUnits,
			r.staticLoads,
			r.staticStores,
			r.bodyLoops,
			r.entryInvocations,
			r.singletonBatches,
			r.inMultiRegionBatches
		].join('\t')
	);
