import { appendFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { measure } from '../probe/consumer.ts';
import { corpusConsumer } from './cases/upstream.ts';
import { corpusManifest } from './corpus.ts';
import { researchEnvironment } from './environment.ts';

if (import.meta.main) {
	const [directory, pairsArg = '9'] = process.argv.slice(2), pairs = Number(pairsArg);
	if (!directory || !Number.isSafeInteger(pairs) || pairs < 1) throw new Error('usage: corpus-serial.ts OUTPUT_DIRECTORY [PAIRS]');
	mkdirSync(directory, { recursive: true }); const raw = join(directory, 'raw.jsonl'); writeFileSync(raw, '', { flag: 'wx' });
	const sink = (row: Record<string, unknown>) => appendFileSync(raw, JSON.stringify(row) + '\n');
	sink(researchEnvironment({ pairs, widths: [1, 2, 4, 8], scope: 'one upstream entry; default admission; verification outside timing' }));
	for (const kernel of corpusManifest.cases) {
		await measure(corpusConsumer(kernel.id), { pairs, warmup: 2, widths: [1, 2, 4, 8], sink: row => sink({ ...row, case: kernel.id }) });
		console.log(kernel.id);
	}
}
