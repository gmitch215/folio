import { createHash } from 'node:crypto';
import { parentPort, workerData } from 'node:worker_threads';
import { serveTasks, type TaskInput, type TaskLink } from '../../src/tasks.ts';

/** A private initialized context; the reset is part of every independent operation. */
export function kernelContext(module: WebAssembly.Module, resetMode: 'whole' | 'pages' = 'whole') {
	const memory = new WebAssembly.Memory({ initial: 128, maximum: 1024 });
	const instance = new WebAssembly.Instance(module, { env: { memory, sin: Math.sin, cos: Math.cos, floor: Math.floor, sqrt: Math.sqrt } });
	(instance.exports.initialize as CallableFunction)();
	const initialized = new Uint8Array(memory.buffer).slice();
	const dirtyPages: number[] = [];
	if (resetMode === 'pages') {
		// Corpus-only specialization: fixed entry, fixed input, deterministic private state.
		// Learn the exact changed pages, then restore the complete initial state before measurement.
		(instance.exports.entry as CallableFunction)();
		const after = new Uint8Array(memory.buffer);
		for (let offset = 0; offset < after.length; offset += 65536)
			if (!Buffer.from(after.subarray(offset, offset + 65536)).equals(Buffer.from(initialized.subarray(offset, offset + 65536)))) dirtyPages.push(offset);
		after.set(initialized);
	}
	let value: unknown;
	return (repeats: number, verify = false) => {
		let resetMs = 0, computeMs = 0;
		for (let index = 0; index < repeats; index++) {
			let start = performance.now();
			const target = new Uint8Array(memory.buffer);
			if (resetMode === 'whole') target.set(initialized);
			else for (const offset of dirtyPages) target.set(initialized.subarray(offset, offset + 65536), offset);
			resetMs += performance.now() - start;
			start = performance.now();
			value = (instance.exports.entry as CallableFunction)();
			computeMs += performance.now() - start;
		}
		const start = performance.now();
		const sha256 = verify ? createHash('sha256').update(new Uint8Array(memory.buffer)).digest('hex') : '';
		return { value: String(value), sha256, resetMs, computeMs, digestMs: performance.now() - start,
			restoredBytes: repeats * (resetMode === 'whole' ? initialized.length : dirtyPages.length * 65536), resetMode };
	};
}

if (workerData?.researchKernel) {
	const data = workerData as { module: WebAssembly.Module; link?: TaskLink; researchKernel: true; resetMode?: 'whole' | 'pages' };
	const run = kernelContext(data.module, data.resetMode);
	const execute = (input: TaskInput) => {
		const { repeats, jobs, verify } = JSON.parse(String(input)) as { repeats: number; jobs: number; verify?: boolean };
		return JSON.stringify(Array.from({ length: jobs }, () => run(repeats, verify)));
	};
	if (data.link) serveTasks(data.link, (_name, input) => execute(input));
	else parentPort!.on('message', ({ id, input }) => {
		try { parentPort!.postMessage({ id, output: execute(input) }); }
		catch (error) { parentPort!.postMessage({ id, error: String(error) }); }
	});
	parentPort!.postMessage({ ready: true });
}
