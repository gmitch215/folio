// negative control: the first design checked reads against earlier writes only. with in-place writes a
// WAR or WAW hazard then goes unseen. one worker pulling the last region first makes the schedule
// deterministic; the rule must fail here and the full rule must not
import { readFileSync } from 'node:fs';
import { defaultRegions, generate, makeLayout, memoryDigest, place, sharedMemory } from './lib.ts';
import type { Layout, Region } from './lib.ts';
import { Mech } from './mech.ts';

const plain = new WebAssembly.Module(readFileSync('build/hash-shared.wasm'));
const tracked = new WebAssembly.Module(readFileSync('build/tracked.wasm'));
const sizes = Array.from({ length: 32 }, (_, i) => 4096 + ((i * 7919) % 8) * 8192);
const inputs = sizes.map((size, i) => generate(i, size));
const lp = makeLayout(sizes, { tracked: false });
const lt = makeLayout(sizes, { tracked: true });
const cases: { name: string; hook?: (m: WebAssembly.Memory, l: Layout) => void; regions?: (l: Layout) => Region[] }[] = [
	{
		name: 'war',
		hook: (m, l) => {
			const w = new Uint32Array(m.buffer, l.table, 2 * l.n);
			w[10] = l.out + 32 * 20;
			w[11] = 32;
		}
	},
	{ name: 'waw', regions: (l) => Array.from({ length: l.n }, (_, i) => ({ entry: l.table + 8 * i, out: l.out + 16 * i })) }
];
const rows: any[] = [];
for (const c of cases) {
	const regionsOf = c.regions ?? defaultRegions;
	const ref = sharedMemory(lp.pages);
	const refEx = new WebAssembly.Instance(plain, { env: { memory: ref } }).exports as any;
	place(ref, lp, inputs);
	c.hook?.(ref, lp);
	for (const r of regionsOf(lp)) refEx.hash_one(r.entry, r.out);
	const want = memoryDigest(ref, lp);
	for (const rawOnly of [true, false]) {
		const memory = sharedMemory(lt.pages);
		const mech = await new Mech(lt, memory, plain, tracked, 1).open();
		mech.setRegions(regionsOf(lt));
		mech.rawOnly = rawOnly;
		place(memory, lt, inputs);
		c.hook?.(memory, lt);
		const report = await mech.run('reverse');
		await mech.close();
		rows.push({ case: c.name, rule: rawOnly ? 'raw only' : 'raw, war and waw', replayed: report.replayed, pairs: report.pairs, memoryEqual: memoryDigest(memory, lt) === want });
	}
}
console.log(JSON.stringify(rows, null, 1));
const good = rows.every((r) => (r.rule === 'raw only' ? !r.memoryEqual : r.memoryEqual));
console.log(good ? 'negative control behaves: the raw-only rule diverges, the full rule equals serial' : 'UNEXPECTED');
process.exit(good ? 0 : 1);
