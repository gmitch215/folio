#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir /tmp/folio-timing.lock
trap 'rmdir /tmp/folio-timing.lock' EXIT
out=${3:-build/prototype-runs}
mkdir -p "$out"
node_bin=${FOLIO_RIG_NODE:?set FOLIO_RIG_NODE}
for wasm in hash-shared tracked marks plain-sp; do
	test -f "build/$wasm.wasm" || { echo "build/$wasm.wasm missing; run prepare.sh first" >&2; exit 1; }
done
sessions=${1:-3}
rounds=${2:-9}
{
	free -m
	uptime
	cat /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
	taskset -pc $$
} > "$out/before.log"
run() {
	nice -n 19 taskset -c 4-11 timeout 3600 "$node_bin" --max-old-space-size=2048 bench.ts "$@"
}
for session in $(seq 1 "$sessions"); do
	run "$out/a-$session.jsonl" "$rounds" a > "$out/a-$session.log" 2>&1
	run "$out/b-$session.jsonl" "$rounds" b > "$out/b-$session.log" 2>&1
	run "$out/c-$session.jsonl" "$rounds" c > "$out/c-$session.log" 2>&1
	uptime >> "$out/after.log"
done
printf '%s\n' complete > "$out/finished"
