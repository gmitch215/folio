import { parentPort, workerData } from 'node:worker_threads';
import { SLOT, type Layout } from './lib.ts';

const { module, memory, layout, mode, id, keep } = workerData as {
	module: WebAssembly.Module;
	memory: WebAssembly.Memory;
	layout: Layout;
	mode: 'plain' | 'tracked';
	id: number;
	keep: boolean;
};
const L = layout;
const ex = new WebAssembly.Instance(module, { env: { memory } }).exports as any;
const i32 = new Int32Array(memory.buffer);
const u32 = new Uint32Array(memory.buffer);
const u8 = new Uint8Array(memory.buffer);
const now = () => performance.now();

// scan one region bitmap into runs of granules and zero it as it goes
function scan(base: number, size: number) {
	const words = new Uint32Array(memory.buffer, base, size / 4);
	const runs: number[] = [];
	let start = -1;
	for (let k = 0; k < words.length; k++) {
		const w = words[k]!;
		if (w === 0) {
			if (start >= 0) {
				runs.push(start, k * 32 - start);
				start = -1;
			}
			continue;
		}
		words[k] = 0;
		if (w === 0xffffffff) {
			if (start < 0) start = k * 32;
			continue;
		}
		for (let b = 0; b < 32; b++) {
			if ((w >>> b) & 1) {
				if (start < 0) start = k * 32 + b;
			} else if (start >= 0) {
				runs.push(start, k * 32 + b - start);
				start = -1;
			}
		}
	}
	if (start >= 0) runs.push(start, words.length * 32 - start);
	return Int32Array.from(runs);
}

interface Done {
	r: number;
	status: number;
	entries: number;
	wg: Int32Array;
	rruns: Int32Array;
	rbits?: Uint8Array;
	wbits?: Uint8Array;
}

function runTracked(r: number, first: number): Done {
	const s = r - first;
	const rbase = L.rmaps + s * L.rsize;
	const wbase = L.wmaps + s * L.wsize;
	const lbase = L.logs + s * L.logSize;
	ex.sp.value = L.slots + (s + 1) * SLOT;
	ex.rb.value = rbase;
	ex.wb.value = wbase;
	ex.lp.value = lbase;
	ex.ll.value = lbase + L.logCap * L.entry;
	ex.sa.value = L.stamp;
	const entry = i32[L.workBase / 4 + 2 * r]!;
	const out = i32[L.workBase / 4 + 2 * r + 1]!;
	const t1 = now();
	let status = 0;
	try {
		ex.hash_one(entry, out);
	} catch {
		status = 1;
	}
	const t2 = now();
	stats.run += t2 - t1;
	const entries = (ex.lp.value - lbase) / L.entry;
	const wg = new Int32Array(entries);
	for (let e = 0; e < entries; e++) wg[e] = u32[(lbase + e * L.entry) / 4]! >>> L.wg;
	wg.sort();
	const done: Done = { r, status, entries, wg, rruns: new Int32Array(0) };
	if (keep) {
		done.rbits = u8.slice(rbase, rbase + L.rsize);
		done.wbits = u8.slice(wbase, wbase + L.wsize);
	}
	done.rruns = scan(rbase, L.rsize);
	if (status === 1) u8.fill(0, wbase, wbase + L.wsize);
	else for (let e = 0; e < entries; e++) u8[wbase + (u32[(lbase + e * L.entry) / 4]! >>> (L.wg + 3))] = 0;
	stats.scan += now() - t2;
	return done;
}

const stats = { run: 0, scan: 0 };
const ctrl = L.ctrl / 4;

parentPort!.on('message', (msg: { first: number; count: number }) => {
	stats.run = 0;
	stats.scan = 0;
	const t0 = now();
	const done: Done[] = [];
	for (;;) {
		const k = Atomics.add(i32, ctrl, 1);
		if (k >= msg.count) break;
		const r = i32[L.orderBase / 4 + k]!;
		if (mode === 'tracked') done.push(runTracked(r, msg.first));
		else {
			ex.sp.value = L.slots + (id + 1) * SLOT;
			const t1 = now();
			ex.hash_one(i32[L.workBase / 4 + 2 * r]!, i32[L.workBase / 4 + 2 * r + 1]!);
			stats.run += now() - t1;
			done.push({ r, status: 0, entries: 0, wg: new Int32Array(0), rruns: new Int32Array(0) });
		}
	}
	parentPort!.postMessage({ done, busyMs: now() - t0, runMs: stats.run, scanMs: stats.scan });
});
parentPort!.postMessage({ ready: true });
