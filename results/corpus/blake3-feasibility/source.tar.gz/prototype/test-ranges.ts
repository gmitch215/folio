// memory.copy and memory.fill ranges, accesses that cross a granule boundary, and the undo record,
// on a small module the BLAKE3 build cannot exercise (it has no memory.fill)
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import binaryen from 'binaryen';

const m = binaryen.parseText(`(module
 (import "env" "memory" (memory $m 1 1 shared))
 (global $__stack_pointer (mut i32) (i32.const 0))
 (func $ranges (export "ranges") (param $a i32) (param $b i32) (param $n i32)
  (memory.copy (local.get $a) (local.get $b) (local.get $n))
  (memory.fill (i32.add (local.get $a) (i32.const 4096)) (i32.const 7) (local.get $n)))
 (func $cross (export "cross") (param $a i32) (param $b i32) (result i64)
  (i64.store (local.get $a) (i64.const -1))
  (i64.load (local.get $b)))
 (func $zero (export "zero") (param $a i32)
  (memory.fill (local.get $a) (i32.const 1) (i32.const 0))))`);
m.setFeatures(binaryen.Features.All);
binaryen.setDebugInfo(true);
writeFileSync('build/ranges-in.wasm', m.emitBinary());
execFileSync('node', ['instrument.ts', 'build/ranges-in.wasm', 'build/ranges-out.wasm'], { stdio: 'pipe' });
const { readFileSync } = await import('node:fs');
const memory = new WebAssembly.Memory({ initial: 1, maximum: 1, shared: true });
const ex = new WebAssembly.Instance(new WebAssembly.Module(readFileSync('build/ranges-out.wasm')), {
	env: { memory }
}).exports as any;
const u8 = new Uint8Array(memory.buffer);
const u32 = new Uint32Array(memory.buffer);
const R = 8192,
	W = 12288,
	LOG = 16384;
ex.rb.value = R;
ex.wb.value = W;
ex.lp.value = LOG;
ex.ll.value = LOG + 40 * 64;
ex.sa.value = 60000;
const bit = (base: number, g: number) => (u8[base + (g >> 3)]! >> (g & 7)) & 1;
for (let i = 0; i < 4096; i++) u8[20000 + i] = i & 255;
// copy 100 bytes from 20010 (granules 312..314 of 64 B) to 30003 (granules 937..939 of 32 B), fill the same length 4096 later
ex.ranges(30003, 20010, 100);
for (let g = 20010 >> 6; g <= (20010 + 99) >> 6; g++) assert.equal(bit(R, g), 1, `read granule ${g}`);
assert.equal(bit(R, (20010 >> 6) - 1), 0);
assert.equal(bit(R, ((20010 + 99) >> 6) + 1), 0);
const touched: number[] = [];
for (let g = 30003 >> 5; g <= (30003 + 99) >> 5; g++) touched.push(g);
for (let g = (30003 + 4096) >> 5; g <= (30003 + 4096 + 99) >> 5; g++) touched.push(g);
for (const g of touched) assert.equal(bit(W, g), 1, `write granule ${g}`);
const entries = (ex.lp.value - LOG) / 40;
assert.equal(entries, touched.length);
const addrs = Array.from({ length: entries }, (_, e) => u32[(LOG + e * 40) / 4]! >>> 5).sort((a, b) => a - b);
assert.deepEqual(addrs, [...touched].sort((a, b) => a - b));
// undo data holds the prior bytes: all zero here, and stamps count up from 0
const stamps = Array.from({ length: entries }, (_, e) => u32[(LOG + e * 40) / 4 + 1]!);
assert.deepEqual([...stamps].sort((a, b) => a - b), stamps.map((_, i) => i));
for (let e = 0; e < entries; e++) for (let k = 0; k < 32; k++) assert.equal(u8[LOG + e * 40 + 8 + k], 0);
// a zero length fill marks nothing
const before = ex.lp.value;
ex.zero(40000);
assert.equal(ex.lp.value, before);
u8.fill(0, R, R + 4096);
u8.fill(0, W, W + 4096);
ex.lp.value = LOG;
// store at 50012 (28 mod 32) spans two 32 B granules; load at 50044 (60 mod 64) spans two 64 B granules
ex.cross(50012, 50044);
assert.equal(bit(W, 50012 >> 5), 1);
assert.equal(bit(W, (50012 + 7) >> 5), 1);
assert.notEqual(50012 >> 5, (50012 + 7) >> 5);
assert.equal(bit(R, 50044 >> 6), 1);
assert.equal(bit(R, (50044 + 7) >> 6), 1);
assert.notEqual(50044 >> 6, (50044 + 7) >> 6);
console.log(JSON.stringify({ ok: true, undoEntriesRanges: entries }));
