import { createHash } from 'node:crypto';

export const BASE = 1 << 20;
export const DATA = BASE + 65536;
export const SLOT = 32768;
export const STACK_LOW = 0;
export const STACK_HIGH = 65536;
const PAGE = 65536;
const align = (v: number, a: number) => Math.ceil(v / a) * a;

export interface Layout {
	n: number;
	table: number;
	out: number;
	offsets: number[];
	sizes: number[];
	hostEnd: number;
	tracked: boolean;
	batch: number;
	rg: number;
	wg: number;
	entry: number;
	logCap: number;
	ctrl: number;
	orderBase: number;
	workBase: number;
	stamp: number;
	slots: number;
	logs: number;
	logSize: number;
	rmaps: number;
	rsize: number;
	wmaps: number;
	wsize: number;
	end: number;
	pages: number;
}

export interface LayoutOptions {
	tracked: boolean;
	batch?: number;
	wg?: number;
	rg?: number;
	logCap?: number;
}

// host data first (as scripts/research/blake3-bench.ts), then the arena: control words, stack slots,
// undo logs and the per-region bitmaps. bitmaps cover every address below `end`, arena included.
export function makeLayout(sizes: number[], options: LayoutOptions): Layout {
	const n = sizes.length;
	const batch = options.batch ?? 32;
	const rg = options.rg ?? 6;
	const wg = options.wg ?? 5;
	const entry = 8 + (1 << wg);
	const logCap = options.logCap ?? 2048;
	const table = BASE;
	const out = BASE + 8 * n;
	let at = DATA;
	const offsets = sizes.map((size) => {
		const offset = at;
		at += size + 64;
		return offset;
	});
	const hostEnd = align(at, 64);
	const ctrl = hostEnd;
	const stamp = ctrl + 64;
	const orderBase = ctrl + 128;
	const workBase = ctrl + 128 + 4 * 4096;
	const slots = ctrl + PAGE;
	const slotCount = Math.max(batch, 16);
	const logs = slots + slotCount * SLOT;
	const logSize = options.tracked ? align(logCap * entry, 64) : 0;
	const rmaps = logs + (options.tracked ? batch * logSize : 0);
	let end = align(rmaps, PAGE);
	let rsize = 0,
		wsize = 0;
	let wmaps = rmaps;
	if (options.tracked) {
		for (;;) {
			rsize = align(Math.ceil(end / 2 ** (rg + 3)), 64);
			wsize = align(Math.ceil(end / 2 ** (wg + 3)), 64);
			wmaps = rmaps + batch * rsize;
			const needed = align(wmaps + batch * wsize, PAGE);
			if (needed <= end) break;
			end = needed;
		}
	}
	end = align(Math.max(end, wmaps + batch * wsize), PAGE);
	return {
		n,
		table,
		out,
		offsets,
		sizes,
		hostEnd,
		tracked: options.tracked,
		batch,
		rg,
		wg,
		entry,
		logCap,
		ctrl,
		orderBase,
		workBase,
		stamp,
		slots,
		logs,
		logSize,
		rmaps,
		rsize,
		wmaps,
		wsize,
		end,
		pages: end / PAGE
	};
}

export function generate(index: number, size: number) {
	const data = new Uint8Array(size);
	let state = (0x9e3779b9 ^ Math.imul(index + 1, 2654435761)) | 0;
	for (let i = 0; i < size; i++) {
		state ^= state << 13;
		state ^= state >>> 17;
		state ^= state << 5;
		data[i] = state & 255;
	}
	return data;
}

export const sharedMemory = (pages: number) =>
	new WebAssembly.Memory({ initial: pages, maximum: pages, shared: true });

export interface Region {
	entry: number;
	out: number;
}

// regions default to hash_one(table + 8 i, out + 32 i), the loop body of hash_all
export const defaultRegions = (l: Layout): Region[] =>
	Array.from({ length: l.n }, (_, i) => ({ entry: l.table + 8 * i, out: l.out + 32 * i }));

export function place(memory: WebAssembly.Memory, l: Layout, inputs: Uint8Array[]) {
	const view = new Uint8Array(memory.buffer);
	const words = new Uint32Array(memory.buffer, l.table, 2 * l.n);
	inputs.forEach((data, i) => {
		view.set(data, l.offsets[i]!);
		words[2 * i] = l.offsets[i]!;
		words[2 * i + 1] = data.length;
	});
	view.fill(0, l.out, l.out + 32 * l.n + 4096);
}

export const outDigest = (memory: WebAssembly.Memory, l: Layout) =>
	createHash('sha256')
		.update(new Uint8Array(memory.buffer, l.out, 32 * l.n))
		.digest('hex');

// everything the program owns except the stack: [STACK_HIGH, hostEnd). the stack residue below
// STACK_HIGH and the arena at [hostEnd, end) are masked and named as masked in every report
export function memoryDigest(memory: WebAssembly.Memory, l: Layout) {
	const hash = createHash('sha256');
	const view = new Uint8Array(memory.buffer, STACK_HIGH, l.hostEnd - STACK_HIGH);
	const step = 1 << 24;
	for (let at = 0; at < view.length; at += step) hash.update(view.subarray(at, at + step));
	return hash.digest('hex');
}

export const MASKED = {
	stack: [STACK_LOW, STACK_HIGH],
	arena: 'from hostEnd to the end of memory: control words, stack slots, undo logs, bitmaps'
};
