// writes sizes100.ts from analysis/inputs.ts (the 100-input set of the blake3-consumer study); run once
import { writeFileSync } from 'node:fs';
import { sizes } from '../analysis/inputs.ts';
const list = sizes();
writeFileSync(new URL('./sizes100.ts', import.meta.url), `export const sizes100 = [\n\t${list.join(',\n\t')}\n];\n`);
console.log(list.length, list.reduce((a, b) => a + b, 0));
