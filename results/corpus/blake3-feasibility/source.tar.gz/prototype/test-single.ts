// single-thread cost of the inline tracking: native, marks only, marks plus undo, 64 B write granule
import { readFileSync } from 'node:fs';
import { loadavg } from 'node:os';
import { createHash } from 'node:crypto';
import { SLOT, generate, makeLayout, place, sharedMemory } from './lib.ts';

const lengths = (process.argv[2] ?? '65536,1048576,4194304').split(',').map(Number);
const reps = Number(process.argv[3] ?? 40);
const variants = [
	{ name: 'native', file: 'build/hash-shared.wasm', tracked: false, wg: 5 },
	{ name: 'marks-only', file: 'build/marks.wasm', tracked: true, wg: 5 },
	{ name: 'marks+undo (wg 5)', file: 'build/tracked.wasm', tracked: true, wg: 5 },
	{ name: 'marks+undo (wg 6)', file: 'build/tracked-wg6.wasm', tracked: true, wg: 6 },
	{ name: 'ablation: no crossing marks (unsound)', file: 'build/nocross.wasm', tracked: true, wg: 5 }
];
const rows: any[] = [];
for (const len of lengths) {
	const input = generate(0, len);
	let base = 0;
	let reference = '';
	for (const v of variants) {
		const L = makeLayout([len], { tracked: v.tracked, batch: 1, wg: v.wg });
		const memory = sharedMemory(L.pages);
		place(memory, L, [input]);
		const ex = new WebAssembly.Instance(new WebAssembly.Module(readFileSync(v.file)), {
			env: { memory }
		}).exports as any;
		const u8 = new Uint8Array(memory.buffer);
		if (v.tracked) {
			ex.sp.value = L.slots + SLOT;
			ex.rb.value = L.rmaps;
			ex.wb.value = L.wmaps;
			ex.ll.value = L.logs + L.logCap * L.entry;
			ex.sa.value = L.stamp;
		}
		const times: number[] = [];
		for (let r = -5; r < reps; r++) {
			if (v.tracked) {
				u8.fill(0, L.wmaps, L.wmaps + L.wsize);
				ex.lp.value = L.logs;
			}
			const t = performance.now();
			ex.hash_one(L.table, L.out);
			if (r >= 0) times.push(performance.now() - t);
		}
		times.sort((a, b) => a - b);
		const digest = createHash('sha256').update(u8.subarray(L.out, L.out + 32)).digest('hex');
		if (!reference) reference = digest;
		const row: any = {
			bytes: len,
			variant: v.name,
			minMs: +times[0]!.toFixed(3),
			medianMs: +times[times.length >> 1]!.toFixed(3),
			digestEqual: digest === reference
		};
		if (v.name === 'native') base = row.medianMs;
		row.overheadMedian = +(row.medianMs / base).toFixed(2);
		if (v.tracked && v.name !== 'marks-only') row.undoEntries = (ex.lp.value - L.logs) / L.entry;
		rows.push(row);
	}
}
console.log(JSON.stringify({ loadavg: loadavg(), reps, rows }, null, 1));
