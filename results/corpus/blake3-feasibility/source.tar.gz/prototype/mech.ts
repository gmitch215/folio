import { Worker } from 'node:worker_threads';
import { type Layout, type Region, defaultRegions } from './lib.ts';

export interface Done {
	r: number;
	status: number;
	entries: number;
	wg: Int32Array;
	rruns: Int32Array;
	rbits?: Uint8Array;
	wbits?: Uint8Array;
}

export interface Report {
	regions: number;
	batches: number;
	replayed: number;
	rolledBack: number;
	failedBatches: number;
	traps: number;
	pairs: { raw: number; war: number; waw: number };
	undoEntries: number;
	dispatchMs: number;
	validateMs: number;
	rollbackMs: number;
	replayMs: number;
	workerRunMs: number;
	workerScanMs: number;
	workerBusyMs: number;
}

// a write granule (32 B units, sorted) against read runs (64 B granule units, sorted)
function writesHitReads(w: Int32Array, runs: Int32Array, shift: number) {
	let p = 0;
	for (let i = 0; i < w.length; i++) {
		const g = w[i]! >> shift;
		while (p < runs.length && runs[p]! + runs[p + 1]! <= g) p += 2;
		if (p >= runs.length) return false;
		if (runs[p]! <= g) return true;
	}
	return false;
}

function writesHitWrites(a: Int32Array, b: Int32Array) {
	let i = 0,
		j = 0;
	while (i < a.length && j < b.length) {
		if (a[i]! === b[j]!) return true;
		if (a[i]! < b[j]!) i++;
		else j++;
	}
	return false;
}

// in-place writes mean a read can see a later region and a later write can land under an earlier
// one, so every ordered pair is checked three ways. the first region that must not be kept:
// RAW reader k, WAR reader j, WAW the earlier writer j. that region and all later ones roll back.
export function verdict(done: Done[], layout: Layout, rawOnly = false) {
	const shift = layout.rg - layout.wg;
	const pairs = { raw: 0, war: 0, waw: 0 };
	let first = done.length;
	done.forEach((d, k) => {
		if (d.status === 1) first = Math.min(first, k);
	});
	for (let j = 0; j < done.length; j++) {
		for (let k = j + 1; k < done.length; k++) {
			if (writesHitReads(done[j]!.wg, done[k]!.rruns, shift)) {
				pairs.raw++;
				first = Math.min(first, k);
			}
			if (rawOnly) continue;
			if (writesHitReads(done[k]!.wg, done[j]!.rruns, shift)) {
				pairs.war++;
				first = Math.min(first, j);
			}
			if (writesHitWrites(done[j]!.wg, done[k]!.wg)) {
				pairs.waw++;
				first = Math.min(first, j);
			}
		}
	}
	return { first: first === done.length ? -1 : first, pairs };
}

export class Mech {
	readonly workers: Worker[] = [];
	private readonly owner: any;
	private readonly i32: Int32Array;
	private readonly u32: Uint32Array;
	private readonly u8: Uint8Array;
	regions: Region[];
	// negative control only: the first design's validation rule, reads against earlier writes
	rawOnly = false;
	onBatch?: (done: Done[], first: number, v: { first: number; pairs: Report['pairs'] }) => void;

	readonly layout: Layout;
	readonly memory: WebAssembly.Memory;
	readonly width: number;
	private readonly module: WebAssembly.Module;
	private readonly keep: boolean;

	constructor(
		layout: Layout,
		memory: WebAssembly.Memory,
		plain: WebAssembly.Module,
		module: WebAssembly.Module,
		width: number,
		keep = false
	) {
		this.layout = layout;
		this.memory = memory;
		this.module = module;
		this.width = width;
		this.keep = keep;
		this.owner = new WebAssembly.Instance(plain, { env: { memory } }).exports;
		this.i32 = new Int32Array(memory.buffer);
		this.u32 = new Uint32Array(memory.buffer);
		this.u8 = new Uint8Array(memory.buffer);
		this.regions = defaultRegions(layout);
	}

	async open() {
		await Promise.all(
			Array.from({ length: this.width }, async (_, id) => {
				const worker = new Worker(new URL('./mech-worker.ts', import.meta.url), {
					workerData: {
						module: this.module,
						memory: this.memory,
						layout: this.layout,
						mode: this.layout.tracked ? 'tracked' : 'plain',
						id,
						keep: this.keep
					}
				});
				this.workers.push(worker);
				await new Promise<void>((resolve, reject) => {
					worker.once('message', () => resolve());
					worker.once('error', reject);
				});
				worker.on('error', (error) => {
					console.error(error);
					process.exit(1);
				});
			})
		);
		return this;
	}

	async close() {
		await Promise.all(this.workers.map((worker) => worker.terminate()));
	}

	setRegions(regions: Region[]) {
		this.regions = regions;
	}

	private async dispatch(first: number, count: number, order: number[]) {
		const L = this.layout;
		this.i32[L.ctrl / 4] = 0;
		this.i32[L.stamp / 4] = 0;
		order.forEach((r, k) => (this.i32[L.orderBase / 4 + k] = r));
		const replies = await Promise.all(
			this.workers.map(
				(worker) =>
					new Promise<any>((resolve) => {
						worker.once('message', resolve);
						worker.postMessage({ first, count });
					})
			)
		);
		return replies;
	}

	// dispatch: 'order' pulls regions in serial order; 'lpt' pulls the largest input first; 'reverse'
	// pulls the last region first, which a single worker turns into a deterministic reversed schedule
	async run(dispatch: 'order' | 'lpt' | 'reverse' = 'order'): Promise<Report> {
		const L = this.layout;
		const report: Report = {
			regions: L.n,
			batches: 0,
			replayed: 0,
			rolledBack: 0,
			failedBatches: 0,
			traps: 0,
			pairs: { raw: 0, war: 0, waw: 0 },
			undoEntries: 0,
			dispatchMs: 0,
			validateMs: 0,
			rollbackMs: 0,
			replayMs: 0,
			workerRunMs: 0,
			workerScanMs: 0,
			workerBusyMs: 0
		};
		this.regions.forEach((region, r) => {
			this.i32[L.workBase / 4 + 2 * r] = region.entry;
			this.i32[L.workBase / 4 + 2 * r + 1] = region.out;
		});
		const size = L.tracked ? L.batch : L.n;
		for (let first = 0; first < L.n; first += size) {
			const count = Math.min(size, L.n - first);
			const order = Array.from({ length: count }, (_, k) => first + k);
			if (dispatch === 'lpt') order.sort((a, b) => L.sizes[b]! - L.sizes[a]!);
			if (dispatch === 'reverse') order.reverse();
			report.batches++;
			const t0 = performance.now();
			const replies = await this.dispatch(first, count, order);
			const t1 = performance.now();
			report.dispatchMs += t1 - t0;
			for (const reply of replies) {
				report.workerRunMs += reply.runMs;
				report.workerScanMs += reply.scanMs;
				report.workerBusyMs += reply.busyMs;
			}
			if (!L.tracked) continue;
			const done: Done[] = replies.flatMap((reply) => reply.done as Done[]);
			done.sort((a, b) => a.r - b.r);
			for (const d of done) {
				report.undoEntries += d.entries;
				if (d.status === 1) report.traps++;
			}
			const v = verdict(done, L, this.rawOnly);
			this.onBatch?.(done, first, v);
			const t2 = performance.now();
			report.validateMs += t2 - t1;
			report.pairs.raw += v.pairs.raw;
			report.pairs.war += v.pairs.war;
			report.pairs.waw += v.pairs.waw;
			if (v.first < 0) continue;
			report.failedBatches++;
			this.rollback(first, done, v.first);
			const t3 = performance.now();
			report.rollbackMs += t3 - t2;
			for (let k = v.first; k < count; k++) {
				const region = this.regions[first + k]!;
				this.owner.hash_one(region.entry, region.out);
				report.replayed++;
				report.rolledBack++;
			}
			report.replayMs += performance.now() - t3;
		}
		return report;
	}

	// newest first by stamp across every region being rolled back
	private rollback(first: number, done: Done[], from: number) {
		const L = this.layout;
		const entries: { stamp: number; addr: number; data: number }[] = [];
		for (let k = from; k < done.length; k++) {
			const d = done[k]!;
			const base = L.logs + (d.r - first) * L.logSize;
			for (let e = 0; e < d.entries; e++) {
				const at = base + e * L.entry;
				entries.push({ addr: this.u32[at / 4]!, stamp: this.u32[at / 4 + 1]!, data: at + 8 });
			}
		}
		entries.sort((a, b) => b.stamp - a.stamp);
		const granule = 1 << L.wg;
		for (const e of entries) this.u8.copyWithin(e.addr, e.data, e.data + granule);
	}

	serialOwner(region: Region) {
		this.owner.hash_one(region.entry, region.out);
	}
}
