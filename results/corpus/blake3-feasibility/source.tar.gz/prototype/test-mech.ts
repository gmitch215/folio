// equality and conflict tests for the mechanism: real workers, real undo, real rollback
// every case runs the mechanism twice (place again between) and compares all memory with a serial
// native run; the stack residue below 64 KiB and the arena are masked
import { readFileSync } from 'node:fs';
import { loadavg } from 'node:os';
import {
	type Layout,
	type LayoutOptions,
	type Region,
	defaultRegions,
	generate,
	makeLayout,
	memoryDigest,
	outDigest,
	place,
	sharedMemory,
	MASKED
} from './lib.ts';
import { Mech, type Done } from './mech.ts';

const module = (file: string) => new WebAssembly.Module(readFileSync(file));
const plain = module('build/hash-shared.wasm');
const plainSp = module('build/plain-sp.wasm');

interface Case {
	name: string;
	sizes: number[];
	width: number;
	options?: Partial<LayoutOptions>;
	tracked?: string;
	hook?: (memory: WebAssembly.Memory, l: Layout) => void;
	regions?: (l: Layout) => Region[];
	expect: 'zero' | 'nonzero';
	note: string;
}

const constant = (n: number, size: number) => Array.from({ length: n }, () => size);
const words = (memory: WebAssembly.Memory, l: Layout) => new Uint32Array(memory.buffer, l.table, 2 * l.n);
const sizesMixed = (n: number) => Array.from({ length: n }, (_, i) => 4096 + ((i * 7919) % 8) * 8192);

const cases: Case[] = [
	{
		name: 'independent',
		sizes: sizesMixed(32),
		width: 4,
		expect: 'zero',
		note: 'no region touches another; replays must be zero'
	},
	{
		name: 'raw-chain',
		sizes: sizesMixed(32),
		width: 4,
		hook: (memory, l) => {
			const w = words(memory, l);
			for (let i = 3; i < l.n; i += 4) {
				w[2 * i] = l.out + 32 * (i - 1);
				w[2 * i + 1] = 32;
			}
		},
		expect: 'nonzero',
		note: 'every fourth input is the digest the previous iteration writes'
	},
	{
		name: 'raw-chain-late',
		sizes: sizesMixed(72),
		width: 8,
		hook: (memory, l) => {
			const w = words(memory, l);
			for (let i = 40; i < l.n; i += 5) {
				w[2 * i] = l.out + 32 * (i - 1);
				w[2 * i + 1] = 32;
			}
		},
		expect: 'nonzero',
		note: 'two batches; the first has no conflict and keeps all its regions'
	},
	{
		name: 'war',
		sizes: sizesMixed(32),
		width: 4,
		hook: (memory, l) => {
			const w = words(memory, l);
			w[2 * 5] = l.out + 32 * 20;
			w[2 * 5 + 1] = 32;
		},
		expect: 'nonzero',
		note: 'region 5 reads the slot region 20 writes; serial reads the old value'
	},
	{
		name: 'waw',
		sizes: sizesMixed(32),
		width: 4,
		regions: (l) =>
			Array.from({ length: l.n }, (_, i) => ({ entry: l.table + 8 * i, out: l.out + 16 * i })),
		expect: 'nonzero',
		note: 'output slots overlap by 16 bytes; the later iteration must win'
	},
	{
		name: 'false-sharing-wg6',
		sizes: sizesMixed(32),
		width: 4,
		options: { wg: 6 },
		tracked: 'build/tracked-wg6.wasm',
		expect: 'nonzero',
		note: '64 B write granules put two 32 B outputs in one granule, a false WAW'
	},
	{
		name: 'undo-overflow',
		sizes: sizesMixed(32),
		width: 4,
		options: { logCap: 8 },
		expect: 'nonzero',
		note: 'the undo log holds 8 entries, so every region traps; each rolls back and reruns'
	}
];

// dense reference verdict straight from the bitmaps (bitwise and of the marks)
function dense(done: Done[], l: Layout) {
	const bit = (b: Uint8Array, g: number) => (b[g >> 3]! >> (g & 7)) & 1;
	const wset = (b: Uint8Array) => {
		const out: number[] = [];
		for (let i = 0; i < b.length; i++) if (b[i]) for (let k = 0; k < 8; k++) if ((b[i]! >> k) & 1) out.push(i * 8 + k);
		return out;
	};
	const ws = done.map((d) => wset(d.wbits!));
	const sameW = done.every((d, i) => d.status === 1 || (ws[i]!.length === d.wg.length && ws[i]!.every((g, k) => g === d.wg[k])));
	let first = done.length;
	done.forEach((d, k) => {
		if (d.status === 1) first = Math.min(first, k);
	});
	const shift = l.rg - l.wg;
	for (let j = 0; j < done.length; j++)
		for (let k = j + 1; k < done.length; k++) {
			if (ws[j]!.some((g) => bit(done[k]!.rbits!, g >> shift))) first = Math.min(first, k);
			if (ws[k]!.some((g) => bit(done[j]!.rbits!, g >> shift))) first = Math.min(first, j);
			const set = new Set(ws[k]);
			if (ws[j]!.some((g) => set.has(g))) first = Math.min(first, j);
		}
	return { first: first === done.length ? -1 : first, sameW };
}

const rows: any[] = [];
let failed = 0;
for (const c of cases) {
	const inputs = c.sizes.map((size, i) => generate(i, size));
	const lp = makeLayout(c.sizes, { tracked: false });
	const lt = makeLayout(c.sizes, { tracked: true, ...c.options });
	const regionsOf = c.regions ?? defaultRegions;

	const ref = sharedMemory(lp.pages);
	const refEx = new WebAssembly.Instance(plain, { env: { memory: ref } }).exports as any;
	place(ref, lp, inputs);
	c.hook?.(ref, lp);
	for (const r of regionsOf(lp)) refEx.hash_one(r.entry, r.out);

	const memory = sharedMemory(lt.pages);
	const mech = await new Mech(
		lt,
		memory,
		plain,
		module(c.tracked ?? 'build/tracked.wasm'),
		c.width,
		true
	).open();
	mech.setRegions(regionsOf(lt));
	let denseAgrees = true;
	let denseSameW = true;
	mech.onBatch = (done, _first, v) => {
		const d = dense(done, lt);
		denseAgrees &&= d.first === v.first;
		denseSameW &&= d.sameW;
	};
	const runs: any[] = [];
	for (let k = 0; k < 2; k++) {
		place(memory, lt, inputs);
		c.hook?.(memory, lt);
		const report = await mech.run();
		runs.push({
			regions: report.regions,
			batches: report.batches,
			replayed: report.replayed,
			rolledBack: report.rolledBack,
			failedBatches: report.failedBatches,
			traps: report.traps,
			pairs: report.pairs,
			undoEntries: report.undoEntries
		});
		const equal = memoryDigest(memory, lt) === memoryDigest(ref, lp);
		const outEqual = outDigest(memory, lt) === outDigest(ref, lp);
		const verdictOk = c.expect === 'zero' ? report.replayed === 0 : report.replayed > 0;
		const ok = equal && outEqual && verdictOk && denseAgrees && denseSameW;
		if (!ok) failed++;
		rows.push({ case: c.name, run: k, width: c.width, ...runs[k], memoryEqual: equal, outEqual, denseAgrees, denseSameW, expect: c.expect, ok });
	}
	await mech.close();
	void plainSp;
}
console.log(JSON.stringify({ masked: MASKED, loadavg: loadavg(), failed, rows }, null, 1));
process.exit(failed ? 1 : 0);
