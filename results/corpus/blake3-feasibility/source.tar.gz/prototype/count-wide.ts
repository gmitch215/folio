import { readFileSync } from 'node:fs';
import binaryen from 'binaryen';
const m = binaryen.readBinary(new Uint8Array(readFileSync('build/hash-shared.wasm')));
m.setFeatures(binaryen.Features.All);
const by: Record<string, number> = {};
const kids = (v: any): number[] => {
	const out: number[] = [];
	for (const k of ['children', 'operands']) out.push(...(v[k] ?? []));
	for (const k of ['body', 'condition', 'ifTrue', 'ifFalse', 'ptr', 'value', 'left', 'right', 'dest', 'source', 'size', 'target'])
		if (typeof v[k] === 'number' && v[k] && !(k === 'value' && v.id === binaryen.ConstId)) out.push(v[k]);
	return out;
};
for (let i = 0; i < m.getNumFunctions(); i++) {
	const fi = binaryen.getFunctionInfo(m.getFunctionByIndex(i));
	if (!fi.body) continue;
	const visit = (e: number) => {
		const v: any = binaryen.getExpressionInfo(e);
		kids(v).forEach(visit);
		if (v.id === binaryen.LoadId || v.id === binaryen.StoreId) {
			const key = `${v.id === binaryen.LoadId ? 'load' : 'store'}${v.bytes * 8}`;
			by[key] = (by[key] ?? 0) + 1;
		}
	};
	visit(fi.body);
}
console.log(JSON.stringify(by));
