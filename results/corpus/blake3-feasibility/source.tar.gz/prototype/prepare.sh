#!/usr/bin/env bash
# builds the three modules bench.ts loads into build/; run where clang and node_modules exist
# needs build/research/blake3 from scripts/research/blake3-build.ts (pinned archive, digest checked)
set -euo pipefail
cd "$(dirname "$0")"
./build.sh build
node instrument.ts build/hash-shared.wasm build/tracked.wasm
node instrument.ts build/hash-shared.wasm build/marks.wasm undo=0
node export-sp.ts build/hash-shared.wasm build/plain-sp.wasm
