#!/usr/bin/env bash
# local Mac smoke: 3 sessions of every workload, 9 rounds, widths 1 2 4 8; diagnostic only
set -euo pipefail
cd "$(dirname "$0")"
out=${1:-runs/mac}
mkdir -p "$out"
{ uptime; sysctl -n machdep.cpu.brand_string; } > "$out/before.log"
for session in 1 2 3; do
	for wl in large small mixed; do
		node --max-old-space-size=2048 bench.ts "$out/$wl-$session.jsonl" 9 "$wl" > "$out/$wl-$session.log" 2>&1
		uptime >> "$out/after.log"
	done
done
printf '%s\n' complete > "$out/finished"
