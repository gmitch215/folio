// paired timing of serial native, untracked workers (ceiling) and tracked workers with ordered
// validation (the mechanism). usage: bench.ts OUTPUT.jsonl ROUNDS WORKLOAD [WIDTHS] [ARMS]
// WORKLOAD a = 32 x 4 MiB, b = 128 x 256 KiB, c = the 100-input set; ARMS from
// ceiling, tracked, marks (tracked without the undo capture), ceiling-lpt, tracked-lpt
// (lpt pulls the largest input first)
import { createHash } from 'node:crypto';
import { appendFileSync, readFileSync, writeFileSync } from 'node:fs';
import { cpus, loadavg, platform, release } from 'node:os';
import {
	MASKED,
	generate,
	makeLayout,
	memoryDigest,
	outDigest,
	place,
	sharedMemory,
	type Layout
} from './lib.ts';
import { Mech } from './mech.ts';
import { sizes100 } from './sizes100.ts';

const [output, roundsArg = '9', workload = 'large', widthsArg = '1,2,4,8', armsArg] = process.argv.slice(2);
if (!output) throw new Error('usage: bench.ts OUTPUT.jsonl [ROUNDS] [large|small|mixed] [WIDTHS] [ARMS]');
const rounds = Number(roundsArg);
const warmups = 2;
const widths = widthsArg.split(',').map(Number);
const arms = (armsArg ?? (workload === 'mixed' ? 'ceiling,tracked,marks,ceiling-lpt,tracked-lpt' : 'ceiling,tracked,marks')).split(',');
writeFileSync(output, '', { flag: 'wx' });
const emit = (row: Record<string, unknown>) => appendFileSync(output, JSON.stringify(row) + '\n');

const sizes =
	workload === 'large'
		? Array.from({ length: 32 }, () => 4 * 1048576)
		: workload === 'small'
			? Array.from({ length: 128 }, () => 262144)
			: sizes100;
// inputs are pseudo-random and held in host buffers, as if read from files
const inputs = sizes.map((size, i) => generate(i, size));
const file = (name: string) => new Uint8Array(readFileSync(name));
const sha = (bytes: Uint8Array) => createHash('sha256').update(bytes).digest('hex');
const wasm = {
	plain: file('build/hash-shared.wasm'),
	plainSp: file('build/plain-sp.wasm'),
	tracked: file('build/tracked.wasm'),
	marks: file('build/marks.wasm')
};
const plain = new WebAssembly.Module(wasm.plain);
const plainSp = new WebAssembly.Module(wasm.plainSp);
const tracked = new WebAssembly.Module(wasm.tracked);
const marks = new WebAssembly.Module(wasm.marks);

const lp = makeLayout(sizes, { tracked: false });
const lt = makeLayout(sizes, { tracked: true });
const nativeMemory = sharedMemory(lp.pages);
const native = new WebAssembly.Instance(plain, { env: { memory: nativeMemory } }).exports
	.hash_all as CallableFunction;
const nativeRun = () => {
	place(nativeMemory, lp, inputs);
	native(lp.table, lp.n, lp.out);
};
nativeRun();
const expected = outDigest(nativeMemory, lp);
emit({
	kind: 'environment',
	schema: 'folio.prototype.v1',
	observedAt: new Date().toISOString(),
	node: process.version,
	v8: process.versions.v8,
	os: platform(),
	release: release(),
	cpu: cpus()[0]?.model,
	threads: cpus().length,
	loadavgStart: loadavg(),
	workload,
	rounds,
	warmups,
	widths,
	arms,
	files: sizes.length,
	totalBytes: sizes.reduce((a, b) => a + b, 0),
	batch: lt.batch,
	granules: { read: 1 << lt.rg, write: 1 << lt.wg },
	hostEnd: lp.hostEnd,
	masked: MASKED,
	wasmSha256: Object.fromEntries(Object.entries(wasm).map(([k, v]) => [k, sha(v)])),
	outputSha256: expected
});

const memories = new Map<string, WebAssembly.Memory>();
const memoryFor = (name: string, l: Layout) => {
	let m = memories.get(name);
	if (!m) memories.set(name, (m = sharedMemory(l.pages)));
	return m;
};

for (const width of widths) {
	for (const arm of arms) {
		const trackedArm = arm.startsWith('tracked') || arm === 'marks';
		const dispatch = arm.endsWith('lpt') ? 'lpt' : 'order';
		const l = trackedArm ? lt : lp;
		const memory = memoryFor(arm === 'marks' ? 'marks' : trackedArm ? 'tracked' : 'ceiling', l);
		const mech = await new Mech(l, memory, plain, arm === 'marks' ? marks : trackedArm ? tracked : plainSp, width).open();
		let last: any;
		let allOk = true;
		for (let round = -warmups; round < rounds; round++) {
			const order = round % 2 ? ['arm', 'native'] : ['native', 'arm'];
			for (const which of order) {
				const cpu = process.cpuUsage();
				const start = performance.now();
				let report: any;
				if (which === 'native') nativeRun();
				else {
					place(memory, l, inputs);
					report = await mech.run(dispatch);
				}
				const wallMs = performance.now() - start;
				const used = process.cpuUsage(cpu);
				const ok = outDigest(which === 'native' ? nativeMemory : memory, l) === expected;
				allOk &&= ok;
				if (which !== 'native') last = report;
				// the marks module sets write bits without logging them, so it never shares a memory
				if (trackedArm && arm !== 'marks' && which !== 'native' && report.undoEntries === 0)
					throw new Error('tracked run logged no undo entries: stale write bitmap');
				if (round >= 0)
					emit({
						kind: 'sample',
						workload,
						width,
						arm,
						round,
						which: which === 'native' ? 'native' : arm,
						wallMs,
						cpuMs: (used.user + used.system) / 1000,
						load: loadavg(),
						outputOk: ok,
						...(which === 'native' ? {} : { report })
					});
			}
		}
		const equal = memoryDigest(memory, l) === memoryDigest(nativeMemory, lp);
		emit({
			kind: 'equality',
			workload,
			width,
			arm,
			memoryEqual: equal,
			everyDigestEqual: allOk,
			memoryDigest: memoryDigest(nativeMemory, lp),
			masked: MASKED,
			lastReport: last
		});
		if (!equal || !allOk) console.error(`MISMATCH ${workload} w${width} ${arm}`);
		await mech.close();
		await new Promise((resolve) => setTimeout(resolve, 300));
	}
}
emit({ kind: 'closed', complete: true });
console.log('done', output);
