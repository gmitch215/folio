// the module the prototype builds equals the official BLAKE3 vectors (input byte i is i % 251), serial and tracked
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { sharedMemory } from './lib.ts';

const root = execFileSync('git', ['rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim();
const vectors = JSON.parse(
	readFileSync(join(root, 'build/research/blake3/BLAKE3-1.8.7/test_vectors/test_vectors.json'), 'utf8')
) as { cases: { input_len: number; hash: string }[] };
let checked = 0;
for (const file of ['build/hash-shared.wasm', 'build/tracked.wasm']) {
	const module = new WebAssembly.Module(readFileSync(file));
	for (const { input_len, hash } of vectors.cases) {
		const pages = Math.ceil(((1 << 20) + 65536 + input_len + 2 * 1048576) / 65536);
		const memory = sharedMemory(pages);
		const ex = new WebAssembly.Instance(module, { env: { memory } }).exports as any;
		const at = 1 << 20;
		const view = new Uint8Array(memory.buffer);
		for (let i = 0; i < input_len; i++) view[at + 4096 + i] = i % 251;
		new Uint32Array(memory.buffer, at, 2).set([at + 4096, input_len]);
		if (ex.lp) {
			const bits = Math.ceil((at + 65536 + input_len + 4096) / 64) * 64;
			ex.sp.value = at + 65536 + input_len + 2048 + 32768;
			ex.rb.value = bits;
			ex.wb.value = bits + 262144;
			ex.lp.value = bits + 524288;
			ex.ll.value = ex.lp.value + 40 * 2048;
			ex.sa.value = bits + 700000;
		}
		ex.hash_one(at, at + 16);
		const digest = Buffer.from(memory.buffer, at + 16, 32).toString('hex');
		if (digest !== hash.slice(0, 64)) throw new Error(`${file} vector ${input_len} differs`);
		checked++;
	}
}
console.log(JSON.stringify({ vectorsChecked: checked }));
