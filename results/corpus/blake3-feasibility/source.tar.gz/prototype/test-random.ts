// random conflict families against the serial run: reads of other iterations' outputs, overlapping
// output slots, mixed sizes, widths 2 and 8. every seed must equal serial; replays are reported
import { readFileSync } from 'node:fs';
import { defaultRegions, generate, makeLayout, memoryDigest, place, sharedMemory } from './lib.ts';
import { Mech } from './mech.ts';

const plain = new WebAssembly.Module(readFileSync('build/hash-shared.wasm'));
const tracked = new WebAssembly.Module(readFileSync('build/tracked.wasm'));
const seeds = Number(process.argv[2] ?? 24);
const rng = (s: number) => () => {
	s = (s + 0x6d2b79f5) | 0;
	let t = Math.imul(s ^ (s >>> 15), 1 | s);
	t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
	return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
let bad = 0;
const rows: any[] = [];
for (let seed = 1; seed <= seeds; seed++) {
	const next = rng(seed);
	const n = 8 * (5 + Math.floor(next() * 8));
	const sizes = Array.from({ length: n }, () => 1024 + Math.floor(next() * 6) * 8192);
	const inputs = sizes.map((size, i) => generate(i, size));
	const stride = [32, 32, 16, 24][Math.floor(next() * 4)]!;
	const readProb = next() * 0.4;
	const plan = Array.from({ length: n }, () => (next() < readProb ? Math.floor(next() * n) : -1));
	const width = seed % 2 ? 2 : 8;
	const lp = makeLayout(sizes, { tracked: false });
	const lt = makeLayout(sizes, { tracked: true });
	const hook = (memory: WebAssembly.Memory, l: typeof lp) => {
		const w = new Uint32Array(memory.buffer, l.table, 2 * l.n);
		plan.forEach((target, i) => {
			if (target < 0) return;
			w[2 * i] = l.out + stride * target;
			w[2 * i + 1] = 16 + (i % 3) * 16;
		});
	};
	const regions = (l: typeof lp) =>
		Array.from({ length: n }, (_, i) => ({ entry: l.table + 8 * i, out: l.out + stride * i }));
	const ref = sharedMemory(lp.pages);
	const refEx = new WebAssembly.Instance(plain, { env: { memory: ref } }).exports as any;
	place(ref, lp, inputs);
	hook(ref, lp);
	for (const r of regions(lp)) refEx.hash_one(r.entry, r.out);
	const memory = sharedMemory(lt.pages);
	const mech = await new Mech(lt, memory, plain, tracked, width).open();
	mech.setRegions(regions(lt));
	place(memory, lt, inputs);
	hook(memory, lt);
	const report = await mech.run();
	const equal = memoryDigest(memory, lt) === memoryDigest(ref, lp);
	await mech.close();
	if (!equal) bad++;
	rows.push({ seed, n, width, stride, readProb: +readProb.toFixed(2), replayed: report.replayed, pairs: report.pairs, equal });
}
console.log(JSON.stringify({ seeds, mismatches: bad, rows }));
process.exit(bad ? 1 : 0);
