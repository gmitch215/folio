// inline read and write granule marks plus a copy-on-first-write undo record, no host call
// usage: instrument.ts IN OUT [rg=6] [wg=5] [undo=1] [cross=1]
// cross=0 drops the second-granule mark of an access that crosses a boundary; ablation only, unsound
// state lives in exported mutable globals set per region: sp rb wb lp ll sa
import { readFileSync, writeFileSync } from 'node:fs';
import binaryen from 'binaryen';

const raw = binaryen as any;
const [input, output, ...opts] = process.argv.slice(2);
const option = (name: string, fallback: number) => {
	const hit = opts.find((o) => o.startsWith(name + '='));
	return hit ? Number(hit.slice(name.length + 1)) : fallback;
};
const RG = option('rg', 6);
const WG = option('wg', 5);
const UNDO = option('undo', 1) === 1;
const CROSS = option('cross', 1) === 1;
export const ENTRY = 8 + (1 << WG);

const m = binaryen.readBinary(new Uint8Array(readFileSync(input!)));
m.setFeatures(binaryen.Features.All);
const i32 = binaryen.i32,
	i64 = binaryen.i64,
	none = binaryen.none;
const c = (v: number) => m.i32.const(v);
const g = (name: string) => m.global.get(name, i32);
const l = (i: number) => m.local.get(i, i32);
const two = binaryen.createType([i32, i32]);

for (const name of ['rb', 'wb', 'lp', 'll', 'sa']) {
	m.addGlobal(name, i32, true, c(0));
	m.addGlobalExport(name, name);
}
m.addGlobalExport('__stack_pointer', 'sp');

// helpers; added before the walk so calls can name them, skipped by the walk
const bitOf = (a: () => number, gran: number) =>
	m.i32.shl(c(1), m.i32.and(m.i32.shr_u(a(), c(gran)), c(7)));
const byteOf = (base: string, a: () => number, gran: number) =>
	m.i32.add(g(base), m.i32.shr_u(a(), c(gran + 3)));

m.addFunction(
	'__r_mark',
	i32,
	none,
	[],
	m.i32.store8(
		0,
		1,
		byteOf('rb', () => l(0), RG),
		m.i32.or(m.i32.load8_u(0, 1, byteOf('rb', () => l(0), RG)), bitOf(() => l(0), RG))
	)
);

const copy64 = (k: number) => m.i64.store(8 + 8 * k, 8, l(1), m.i64.load(8 * k, 8, l(0)));
if (UNDO) {
	// $0 granule address; entry: addr, stamp, prior bytes. capture, then stamp, then the caller's write
	const body: number[] = [
		m.if(m.i32.ge_u(g('lp'), g('ll')), m.unreachable()),
		m.local.set(1, g('lp')),
		m.i32.store(0, 4, l(1), l(0))
	];
	for (let k = 0; k < (1 << WG) / 8; k++) body.push(copy64(k));
	body.push(
		m.i32.store(4, 4, l(1), m.i32.atomic.rmw.add(0, g('sa'), c(1))),
		m.global.set('lp', m.i32.add(l(1), c(ENTRY)))
	);
	m.addFunction('__undo', i32, none, [i32], m.block(null, body, none));
} else {
	m.addFunction('__undo', i32, none, [], m.nop());
}

// set the write bit and capture the granule; callers have seen the bit clear
m.addFunction(
	'__w_set',
	i32,
	none,
	[],
	m.block(
		null,
		[
			m.i32.store8(
				0,
				1,
				byteOf('wb', () => l(0), WG),
				m.i32.or(m.i32.load8_u(0, 1, byteOf('wb', () => l(0), WG)), bitOf(() => l(0), WG))
			),
			m.call('__undo', [m.i32.and(l(0), c(-(1 << WG)))], none)
		],
		none
	)
);
m.addFunction(
	'__w_mark',
	i32,
	none,
	[],
	m.if(
		m.i32.eqz(
			m.i32.and(m.i32.load8_u(0, 1, byteOf('wb', () => l(0), WG)), bitOf(() => l(0), WG))
		),
		m.call('__w_set', [l(0)], none)
	)
);
// ranges: every granule from a to a+n-1
const range = (name: string, gran: number, mark: string) =>
	m.addFunction(
		name,
		two,
		none,
		[i32, i32],
		m.if(
			l(1),
			m.block(
				null,
				[
					m.local.set(2, m.i32.shr_u(l(0), c(gran))),
					m.local.set(3, m.i32.shr_u(m.i32.add(l(0), m.i32.sub(l(1), c(1))), c(gran))),
					m.loop(
						'again',
						m.block(
							null,
							[
								m.call(mark, [m.i32.shl(l(2), c(gran))], none),
								m.local.set(2, m.i32.add(l(2), c(1))),
								m.br('again', m.i32.le_u(l(2), l(3)))
							],
							none
						)
					)
				],
				none
			)
		)
	);
range('__r_range', RG, '__r_mark');
range('__w_range', WG, '__w_mark');
const helpers = new Set([
	'__r_mark',
	'__undo',
	'__w_set',
	'__w_mark',
	'__r_range',
	'__w_range'
]);

const kids = (v: any): number[] => {
	const out: number[] = [];
	for (const k of ['children', 'operands']) out.push(...(v[k] ?? []));
	for (const k of [
		'body',
		'condition',
		'ifTrue',
		'ifFalse',
		'ptr',
		'value',
		'left',
		'right',
		'dest',
		'source',
		'size',
		'target'
	])
		if (typeof v[k] === 'number' && v[k] && !(k === 'value' && v.id === binaryen.ConstId))
			out.push(v[k]);
	return out;
};

const stats = { loads: 0, stores: 0, copies: 0, fills: 0, functions: 0 };
const skip = new Set(['__wasm_init_memory']);
const count = m.getNumFunctions();
for (let i = 0; i < count; i++) {
	const f = m.getFunctionByIndex(i);
	const fi = binaryen.getFunctionInfo(f);
	if (!fi.body || helpers.has(fi.name) || skip.has(fi.name)) continue;
	const first = binaryen.expandType(fi.params).length + fi.vars.length;
	// t pointer, u effective address, v bitmap byte, td ts tn range operands
	const [t, u, v, td, ts, tn] = [0, 1, 2, 3, 4, 5].map((k) => first + k);
	let used = false;
	const visit = (e: number) => {
		const info: any = binaryen.getExpressionInfo(e);
		for (const k of kids(info)) visit(k);
		const id = info.id;
		if (id === binaryen.LoadId || id === binaryen.StoreId) {
			if (info.isAtomic) return;
			used = true;
			const isLoad = id === binaryen.LoadId;
			const w: number = info.bytes;
			const ea = () => (info.offset ? m.i32.add(l(t), c(info.offset)) : l(t));
			const steps: number[] = [m.local.set(t, info.ptr)];
			if (isLoad) {
				steps.push(
					m.local.set(u, ea()),
					m.i32.store8(
						0,
						1,
						byteOf('rb', () => l(u), RG),
						m.i32.or(m.i32.load8_u(0, 1, byteOf('rb', () => l(u), RG)), bitOf(() => l(u), RG))
					)
				);
				if (w > 1 && CROSS)
					steps.push(
						m.if(
							m.i32.gt_u(m.i32.and(l(u), c((1 << RG) - 1)), c((1 << RG) - w)),
							m.call('__r_mark', [m.i32.add(l(u), c(w - 1))], none)
						)
					);
				stats.loads++;
			} else {
				steps.push(
					m.local.set(u, ea()),
					m.if(
						m.i32.eqz(
							m.i32.and(m.i32.load8_u(0, 1, byteOf('wb', () => l(u), WG)), bitOf(() => l(u), WG))
						),
						m.call('__w_set', [l(u)], none)
					)
				);
				if (w > 1 && CROSS)
					steps.push(
						m.if(
							m.i32.gt_u(m.i32.and(l(u), c((1 << WG) - 1)), c((1 << WG) - w)),
							m.call('__w_mark', [m.i32.add(l(u), c(w - 1))], none)
						)
					);
				stats.stores++;
			}
			steps.push(l(t));
			const ptr = m.block(null, steps, i32);
			if (isLoad) raw._BinaryenLoadSetPtr(e, ptr);
			else raw._BinaryenStoreSetPtr(e, ptr);
		} else if (id === binaryen.MemoryCopyId) {
			used = true;
			stats.copies++;
			const d = info.dest,
				s = info.source,
				n = info.size;
			raw._BinaryenMemoryCopySetDest(e, m.block(null, [m.local.set(td, d), l(td)], i32));
			raw._BinaryenMemoryCopySetSource(e, m.block(null, [m.local.set(ts, s), l(ts)], i32));
			raw._BinaryenMemoryCopySetSize(
				e,
				m.block(
					null,
					[
						m.local.set(tn, n),
						m.call('__r_range', [l(ts), l(tn)], none),
						m.call('__w_range', [l(td), l(tn)], none),
						l(tn)
					],
					i32
				)
			);
		} else if (id === binaryen.MemoryFillId) {
			used = true;
			stats.fills++;
			const d = info.dest,
				n = info.size;
			raw._BinaryenMemoryFillSetDest(e, m.block(null, [m.local.set(td, d), l(td)], i32));
			raw._BinaryenMemoryFillSetSize(
				e,
				m.block(
					null,
					[m.local.set(tn, n), m.call('__w_range', [l(td), l(tn)], none), l(tn)],
					i32
				)
			);
		}
	};
	visit(fi.body);
	if (used) {
		stats.functions++;
		for (let k = 0; k < 6; k++) {
			const idx = raw._BinaryenFunctionAddVar(f, i32);
			if (idx !== first + k) throw new Error(`temp index ${idx} != ${first + k}`);
		}
	}
}
if (!m.validate()) throw new Error('instrumented module is invalid');
writeFileSync(output!, m.emitBinary());
console.log(JSON.stringify({ output, rg: RG, wg: WG, undo: UNDO, cross: CROSS, entryBytes: ENTRY, ...stats }));
