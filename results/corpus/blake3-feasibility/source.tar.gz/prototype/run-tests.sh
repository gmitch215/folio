#!/usr/bin/env bash
# the equality, conflict, negative-control, range and single-thread checks; writes build/test-*
set -euo pipefail
cd "$(dirname "$0")"
node test-ranges.ts > build/test-ranges.json
node test-mech.ts > build/test-mech.json
node test-random.ts 40 > build/test-random.json
node test-negative.ts > build/test-negative.txt
node test-vectors.ts > build/test-vectors.json
node test-single.ts 65536,1048576,4194304 40 > build/test-single.json
echo all checks passed
