// where the time goes for one workload and width: medians over all sessions and rounds
import { readFileSync } from 'node:fs';
const [workload, width, ...files] = process.argv.slice(2);
const med = (v: number[]) => { const s = [...v].sort((a, b) => a - b); return s[s.length >> 1]!; };
const rows = files.flatMap((f) => readFileSync(f, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)))
	.filter((r) => r.kind === 'sample' && r.workload === workload && r.width === Number(width));
const out: Record<string, any> = {};
const native = rows.filter((r) => r.which === 'native');
out.native = { wallMs: +med(native.map((r) => r.wallMs)).toFixed(1) };
for (const arm of [...new Set(rows.filter((r) => r.which !== 'native').map((r) => r.which))]) {
	const a = rows.filter((r) => r.which === arm);
	const m = (f: (r: any) => number) => +med(a.map(f)).toFixed(2);
	const wall = m((r) => r.wallMs);
	out[arm as string] = {
		wallMs: wall,
		dispatchMs: m((r) => r.report.dispatchMs),
		placeAndOtherMs: m((r) => r.wallMs - r.report.dispatchMs - r.report.validateMs - r.report.rollbackMs - r.report.replayMs),
		validateMs: m((r) => r.report.validateMs),
		workerWasmMsSummed: m((r) => r.report.workerRunMs),
		workerScanMsSummed: m((r) => r.report.workerScanMs),
		workerBusyMsSummed: m((r) => r.report.workerBusyMs),
		undoEntries: m((r) => r.report.undoEntries),
		samples: a.length
	};
}
console.log(JSON.stringify(out, null, 1));
