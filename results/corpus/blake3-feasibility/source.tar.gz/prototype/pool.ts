// pools summarize.ts output across sessions: median of session medians, range, markdown table
import { readFileSync } from 'node:fs';
const cells = process.argv.slice(2).flatMap((f) => JSON.parse(readFileSync(f, 'utf8')).cells as any[]);
const overhead = process.argv.slice(2).flatMap((f) => JSON.parse(readFileSync(f, 'utf8')).overhead as any[]);
const med = (v: number[]) => { const s = [...v].sort((a, b) => a - b); const m = s.length >> 1; return s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2; };
const r = (v: number, d = 2) => +v.toFixed(d);
const keys = [...new Set(cells.map((c) => `${c.workload}|${c.width}|${c.arm}`))];
console.log('| workload | width | arm | speedup median (sessions) | native ms | arm ms | cpu ratio | replays | dispatch | validate | scan of worker busy | memory equal |');
console.log('| --- | ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |');
for (const key of keys.sort()) {
	const [workload, width, arm] = key.split('|');
	const g = cells.filter((c) => `${c.workload}|${c.width}|${c.arm}` === key);
	const sp = g.map((c) => c.speedupMedian);
	const pct = (f: string) => (g[0][f] === undefined ? '' : `${r(med(g.map((c) => c[f])) * 100, 1)}%`);
	console.log(`| ${workload} | ${width} | ${arm} | ${r(med(sp))}x (${sp.join(', ')}) | ${r(med(g.map((c) => c.nativeWallMedianMs)), 1)} | ${r(med(g.map((c) => c.armWallMedianMs)), 1)} | ${r(med(g.map((c) => c.cpuRatioMedian)))} | ${g[0].replayedMedian ?? ''} | ${pct('dispatchShare')} | ${pct('validateShare')} | ${pct('workerScanShareOfBusy')} | ${g.every((c) => c.memoryEqual && c.outputsOk)} |`);
}
console.log('\n| workload | width | arm | tracked over ceiling per session | wall ratio |');
console.log('| --- | ---: | --- | --- | --- |');
const ok = [...new Set(overhead.map((o) => `${o.workload}|${o.width}|${o.arm}`))].sort();
for (const key of ok) {
	const [workload, width, arm] = key.split('|');
	const g = overhead.filter((o) => `${o.workload}|${o.width}|${o.arm}` === key);
	console.log(`| ${workload} | ${width} | ${arm} | ${g.map((o) => o.trackedOverCeiling).join(', ')} (median ${r(med(g.map((o) => o.trackedOverCeiling)))}) | ${r(med(g.map((o) => o.wallRatio)))} |`);
}
