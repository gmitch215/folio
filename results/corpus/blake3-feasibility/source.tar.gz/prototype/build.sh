#!/bin/sh
# usage: build.sh [OUTDIR]; builds the shared-memory consumer with hash_one exported
# needs build/research/blake3 from scripts/research/blake3-build.ts (pinned, digest checked)
set -e
here=$(cd "$(dirname "$0")" && pwd)
root=${FOLIO_ROOT:-$(git -C "$here" rev-parse --show-toplevel)}
c=$root/build/research/blake3/BLAKE3-1.8.7/c
cases=$root/scripts/research/cases
out=${1:-$here/build}
mkdir -p "$out"
clang=${LLVM:+$LLVM/}clang
[ -x /opt/homebrew/opt/llvm/bin/clang ] && [ -z "$LLVM" ] && clang=/opt/homebrew/opt/llvm/bin/clang
PATH=$(echo "$PATH" | tr ':' '\n' | grep -v 'node_modules/\.bin' | paste -sd: -) \
$clang --target=wasm32 -O2 -g0 -ffreestanding -fno-builtin -nostdlib \
	-mbulk-memory -matomics -DNDEBUG -DBLAKE3_NO_SSE2 -DBLAKE3_NO_SSE41 -DBLAKE3_NO_AVX2 -DBLAKE3_NO_AVX512 \
	-I "$cases/include" -I "$c" \
	"$cases/support-min.c" "$here/consumer.c" "$c/blake3.c" "$c/blake3_dispatch.c" "$c/blake3_portable.c" \
	-Wl,--no-entry,--import-memory,--export-memory,--shared-memory,--allow-undefined \
	-Wl,--export=hash_all,--export=hash_one \
	-Wl,--initial-memory=1048576 -Wl,--max-memory=4294967296 \
	-o "$out/hash-shared.wasm"
