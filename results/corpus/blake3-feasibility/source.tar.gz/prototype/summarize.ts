// usage: summarize.ts OUT.json IN.jsonl [IN.jsonl ...]
// paired median speedup per (workload, width, arm), ceiling vs tracked overhead, cost shares
import { readFileSync, writeFileSync } from 'node:fs';

const [output, ...inputs] = process.argv.slice(2);
if (!output || !inputs.length) throw new Error('usage: summarize.ts OUT.json IN.jsonl ...');
const median = (v: number[]) => {
	const s = [...v].sort((a, b) => a - b);
	const m = s.length >> 1;
	return s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2;
};
const round = (v: number, d = 2) => +v.toFixed(d);

type Row = Record<string, any>;
const groups = new Map<string, { native: Row[]; arm: Row[]; equality?: Row }>();
const sessions: Record<string, any>[] = [];
inputs.forEach((file, session) => {
	for (const line of readFileSync(file, 'utf8').split('\n')) {
		if (!line) continue;
		const row = JSON.parse(line) as Row;
		if (row.kind === 'environment') sessions.push({ session, node: row.node, cpu: row.cpu, loadavgStart: row.loadavgStart });
		const key = `${row.workload}|${row.width}|${row.arm}|${session}`;
		if (row.kind === 'sample') {
			const g = groups.get(key) ?? { native: [], arm: [] };
			(row.which === 'native' ? g.native : g.arm).push(row);
			groups.set(key, g);
		}
		if (row.kind === 'equality') {
			const g = groups.get(key) ?? { native: [], arm: [] };
			g.equality = row;
			groups.set(key, g);
		}
	}
});

const cells: Row[] = [];
for (const [key, g] of groups) {
	const [workload, width, arm, session] = key.split('|');
	const byRound = new Map<number, Row>(g.native.map((r) => [r.round, r]));
	const pairs = g.arm.map((a) => ({ a, n: byRound.get(a.round)! })).filter((p) => p.n);
	const speed = pairs.map((p) => p.n.wallMs / p.a.wallMs);
	const cpuRatio = pairs.map((p) => p.a.cpuMs / p.n.cpuMs);
	const reports = pairs.map((p) => p.a.report).filter(Boolean);
	const sum = (f: (r: Row) => number) => median(reports.map(f));
	const wall = median(pairs.map((p) => p.a.wallMs));
	cells.push({
		workload,
		width: Number(width),
		arm,
		session: Number(session),
		rounds: pairs.length,
		speedupMedian: round(median(speed)),
		speedupMin: round(Math.min(...speed)),
		speedupMax: round(Math.max(...speed)),
		nativeWallMedianMs: round(median(pairs.map((p) => p.n.wallMs)), 1),
		armWallMedianMs: round(wall, 1),
		cpuRatioMedian: round(median(cpuRatio)),
		maxLoad1: round(Math.max(...pairs.flatMap((p) => [p.a.load[0], p.n.load[0]]))),
		outputsOk: pairs.every((p) => p.a.outputOk && p.n.outputOk),
		memoryEqual: g.equality?.memoryEqual,
		replayedMedian: reports.length ? sum((r) => r.replayed) : undefined,
		regions: reports[0]?.regions,
		batches: reports[0]?.batches,
		dispatchShare: reports.length ? round(sum((r) => r.dispatchMs) / wall, 3) : undefined,
		validateShare: reports.length ? round(sum((r) => r.validateMs) / wall, 4) : undefined,
		rollbackShare: reports.length ? round(sum((r) => r.rollbackMs) / wall, 4) : undefined,
		replayShare: reports.length ? round(sum((r) => r.replayMs) / wall, 4) : undefined,
		workerScanShareOfBusy: reports.length && reports[0].workerBusyMs
			? round(median(reports.map((r) => r.workerScanMs / r.workerBusyMs)), 4)
			: undefined,
		undoEntriesMedian: reports.length ? sum((r) => r.undoEntries) : undefined
	});
}
cells.sort((a, b) => a.workload.localeCompare(b.workload) || a.width - b.width || a.arm.localeCompare(b.arm) || a.session - b.session);

// tracked over ceiling, per session: ratio of paired median speedups
const overhead: Row[] = [];
for (const cell of cells.filter((c) => c.arm.startsWith('tracked'))) {
	const ceiling = cells.find(
		(c) => c.workload === cell.workload && c.width === cell.width && c.session === cell.session && c.arm === cell.arm.replace('tracked', 'ceiling')
	);
	const marks = cells.find(
		(c) => c.workload === cell.workload && c.width === cell.width && c.session === cell.session && c.arm === 'marks' && cell.arm === 'tracked'
	);
	if (ceiling)
		overhead.push({
			undoShareOfWall: marks ? round((cell.armWallMedianMs - marks.armWallMedianMs) / cell.armWallMedianMs, 3) : undefined,
			workload: cell.workload,
			width: cell.width,
			arm: cell.arm,
			session: cell.session,
			trackedOverCeiling: round(ceiling.speedupMedian / cell.speedupMedian),
			wallRatio: round(cell.armWallMedianMs / ceiling.armWallMedianMs)
		});
}
writeFileSync(output, JSON.stringify({ sessions, cells, overhead }, null, 1) + '\n');
const pad = (v: unknown, n: number) => String(v ?? '').padEnd(n);
console.log(pad('wl', 3), pad('w', 3), pad('arm', 13), pad('s', 2), pad('speedup (min-max)', 20), pad('native ms', 10), pad('arm ms', 9), pad('cpu', 5), pad('replay', 7), pad('disp', 6), pad('valid', 6), pad('roll+rep', 8), pad('scan/busy', 9), 'eq')
for (const c of cells)
	console.log(
		pad(c.workload, 3), pad(c.width, 3), pad(c.arm, 13), pad(c.session, 2),
		pad(`${c.speedupMedian} (${c.speedupMin}-${c.speedupMax})`, 20), pad(c.nativeWallMedianMs, 10), pad(c.armWallMedianMs, 9),
		pad(c.cpuRatioMedian, 5), pad(c.replayedMedian, 7), pad(c.dispatchShare, 6), pad(c.validateShare, 6),
		pad(c.rollbackShare !== undefined ? round(c.rollbackShare + c.replayShare, 3) : '', 8), pad(c.workerScanShareOfBusy, 9), `${c.memoryEqual}/${c.outputsOk}`
	);
console.log('tracked over ceiling');
for (const o of overhead) console.log(pad(o.workload, 3), pad(o.width, 3), pad(o.arm, 13), pad(o.session, 2), 'speedup ratio', o.trackedOverCeiling, 'wall ratio', o.wallRatio, 'undo share of wall', o.undoShareOfWall ?? '');
