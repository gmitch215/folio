// the uninstrumented module with its stack pointer exported as sp, for untracked workers
import { readFileSync, writeFileSync } from 'node:fs';
import binaryen from 'binaryen';
const m = binaryen.readBinary(new Uint8Array(readFileSync(process.argv[2]!)));
m.setFeatures(binaryen.Features.All);
m.addGlobalExport('__stack_pointer', 'sp');
writeFileSync(process.argv[3]!, m.emitBinary());
