// forced or default Folio run of hash_all on an input subset; prints report and conflict trace
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { prepare } from './fsrc/compiler.ts';
import { Folio } from './fsrc/node.ts';
import { digests, layout, populate, sizes } from './host.ts';

const wasm = process.env.WASM ?? 'build/blake3-hash-all.wasm';
const minimumRegionWork = process.env.MIN === undefined ? undefined : Number(process.env.MIN);
const shared = process.env.SHARED === '1';
const sizeMax = Number(process.env.SIZEMAX ?? 1e12);
const workers = Number(process.env.WORKERS ?? 2);
const traceFile = process.env.TRACE;
const bytes = new Uint8Array(readFileSync(wasm));
const lengths = sizes().filter((n) => n <= sizeMax);
const l = layout(lengths);
const mask = process.env.MASK === "1";
const sha = (b: Uint8Array) => {
	if (!mask) return createHash("sha256").update(b).digest("hex");
	const c = Uint8Array.from(b);
	c.fill(0, 0, 65536);
	c.fill(0, 512 << 10, 1 << 20);
	return createHash("sha256").update(c).digest("hex");
};
const plan = prepare(bytes, minimumRegionWork === undefined ? {} : { minimumRegionWork });
console.log('inputs', lengths.length, 'bytes', lengths.reduce((a, b) => a + b, 0), 'plan', Boolean(plan.control));
const nativeMemory = new WebAssembly.Memory({ initial: l.pages, maximum: l.pages, shared });
const instance = new WebAssembly.Instance(new WebAssembly.Module(bytes), { env: { memory: nativeMemory } });
populate(nativeMemory, l);
const t0 = performance.now();
(instance.exports.hash_all as CallableFunction)(l.table, lengths.length, l.out);
const nativeMs = performance.now() - t0;
const nativeSha = sha(new Uint8Array(nativeMemory.buffer));
const memory = new WebAssembly.Memory({ initial: l.pages, maximum: l.pages, shared });
const pool = await Folio.open(plan, { imports: { env: { memory } }, workers });
populate(pool.memory, l);
const trace: any[] = [];
(globalThis as any).__folioTrace = trace;
const t1 = performance.now();
const report = await pool.run('hash_all', [l.table, lengths.length, l.out]);
const folioMs = performance.now() - t1;
const same = sha(new Uint8Array(pool.memory.buffer)) === nativeSha;
console.log(JSON.stringify({ mode: report.mode, reason: report.reason, regions: report.regions, replayed: report.replayed, fallbacks: report.fallbacks, memoryEqual: same, nativeMs, folioMs, loadavg: (await import('node:os')).loadavg() }));
if (traceFile) {
	writeFileSync(traceFile, JSON.stringify({ names: plan.control?.regions.map((r) => [r.exportName, r.name]), trace }, (_, v) => (typeof v === "bigint" ? String(v) : v), 1));
}
await pool.close?.();
