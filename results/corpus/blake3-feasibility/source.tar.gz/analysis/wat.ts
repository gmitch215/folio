import { readFileSync, writeFileSync } from 'node:fs';
import binaryen from 'binaryen';
const m = binaryen.readBinary(new Uint8Array(readFileSync(process.argv[2]!)));
m.setFeatures(binaryen.Features.All);
writeFileSync(process.argv[3]!, m.emitText());
