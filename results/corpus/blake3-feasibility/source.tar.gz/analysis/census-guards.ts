// per-condition census of what src/guards.ts and loopPlan accept, on the BLAKE3 functions
import { readFileSync } from 'node:fs';
import binaryen from 'binaryen';
const m = binaryen.readBinary(new Uint8Array(readFileSync(process.argv[2] ?? 'build/blake3-hash-all.wasm')));
m.setFeatures(binaryen.Features.All);
const info = (e: number): any => {
	const id = binaryen.getExpressionId(e);
	if (id === binaryen.NopId || id === binaryen.UnreachableId) return { id, type: binaryen.getExpressionType(e) };
	return binaryen.getExpressionInfo(e);
};
const kids = (v: any): number[] => {
	const out: number[] = [];
	for (const k of ['children', 'operands']) out.push(...(v[k] ?? []));
	for (const k of ['body', 'condition', 'ifTrue', 'ifFalse', 'ptr', 'value', 'left', 'right', 'dest', 'source', 'size', 'target'])
		if (typeof v[k] === 'number' && v[k] && !(k === 'value' && v.id === binaryen.ConstId)) out.push(v[k]);
	return out;
};
const names = ['hash_all', 'blake3_hasher_init', 'blake3_hasher_update', 'blake3_hasher_finalize_seek', 'blake3_compress_subtree_wide', 'blake3_hash_many_portable', 'blake3_compress_in_place_portable', 'blake3_compress_xof_portable', 'memcpy', 'memset'];
for (const name of names) {
	const fi = binaryen.getFunctionInfo(m.getFunction(name));
	const params = binaryen.expandType(fi.params);
	const c: Record<string, number> = {};
	const bump = (k: string) => (c[k] = (c[k] ?? 0) + 1);
	const nonI32 = [...params, ...fi.vars].filter((t) => t !== binaryen.i32).length;
	const walk = (e: number) => {
		const v = info(e);
		switch (v.id) {
			case binaryen.LoadId:
			case binaryen.StoreId: {
				const kind = v.id === binaryen.LoadId ? 'load' : 'store';
				bump(kind);
				const bytes = v.bytes;
				if (![1, 2, 4].includes(bytes)) bump(`${kind} width ${bytes} (guards accept 1,2,4)`);
				const p = info(v.ptr);
				let shape = 'computed';
				if (p.id === binaryen.LocalGetId) shape = p.index < params.length ? 'param' : 'local';
				else if (p.id === binaryen.ConstId) shape = 'const';
				bump(`${kind} ptr=${shape}`);
				break;
			}
			case binaryen.LoopId: {
				const b = info(v.body);
				const tail = b.id === binaryen.BlockId ? info(b.children.at(-1)) : b;
				const cd = tail.id === binaryen.BreakId && tail.condition && info(tail.condition).id === binaryen.LocalSetId && info(tail.condition).isTee;
				bump(cd ? 'loop countdown-shaped' : 'loop other');
				break;
			}
			case binaryen.CallId: bump('call'); break;
			case binaryen.CallIndirectId: bump('call_indirect'); break;
			case binaryen.GlobalGetId: case binaryen.GlobalSetId: bump('global access'); break;
			case binaryen.SwitchId: bump('br_table'); break;
			case binaryen.IfId: bump('if'); break;
			case binaryen.SelectId: bump('select'); break;
			case binaryen.MemoryCopyId: case binaryen.MemoryFillId: bump('memory.copy/fill'); break;
		}
		for (const k of kids(v)) walk(k);
	};
	walk(fi.body);
	console.log(`${name}: params=${params.length} nonI32 locals/params=${nonI32}`, JSON.stringify(c));
}
