// diagnostic: lower the whole program for tracking (reasons ignored) and run one input tracked
import { readFileSync } from 'node:fs';
import { prepare } from './fsrc/compiler.ts';
import { transaction } from './fsrc/transaction.ts';
import { fill } from './inputs.ts';

process.env.FOLIO_IGNORE_REASONS = '1';
const bytes = new Uint8Array(readFileSync('build/blake3-hash-all.wasm'));
const p = prepare(bytes, { parallel: 'auto', minimumRegionWork: 0 });
if (!p.transactional) throw new Error('no transactional ' + JSON.stringify(p.reasons));
const len = Number(process.argv[2] ?? 1 << 20);
const TABLE = 1 << 20, OUT = TABLE + 8, IN = TABLE + 65536;
const pages = Math.ceil((IN + len + 64) / 65536) + 1;
const mk = () => {
	const memory = new WebAssembly.Memory({ initial: pages, maximum: pages });
	fill(new Uint8Array(memory.buffer, IN, len), len, 7);
	const w = new Uint32Array(memory.buffer, TABLE, 2);
	w[0] = IN; w[1] = len;
	return memory;
};
// native
const m0 = mk();
const ni = new WebAssembly.Instance(new WebAssembly.Module(bytes), { env: { memory: m0 } });
let t = performance.now();
const reps = 20;
for (let i = 0; i < reps; i++) (ni.exports.hash_all as CallableFunction)(TABLE, 1, OUT);
const nativeMs = (performance.now() - t) / reps;
const digest = Buffer.from(m0.buffer, OUT, 32).toString('hex');
// tracked
const m1 = mk();
let active: ReturnType<typeof transaction>;
const counts = { load: 0, store: 0, load64: 0, store64: 0, copy: 0, fill: 0, exhausted: 0 };
let fuelCalls = 0;
const mod = new WebAssembly.Module(p.transactional);
const inst = new WebAssembly.Instance(mod, {
	env: { memory: m1 },
	folio: {
		load: (...a: any[]) => (counts.load++, (active.load as any)(...a)),
		store: (...a: any[]) => (counts.store++, (active.store as any)(...a)),
		load64: (...a: any[]) => (counts.load64++, (active.load64 as any)(...a)),
		store64: (...a: any[]) => (counts.store64++, (active.store64 as any)(...a)),
		copy: (...a: any[]) => (counts.copy++, (active.copy as any)(...a)),
		fill: (...a: any[]) => (counts.fill++, (active.fill as any)(...a)),
		exhausted: () => { counts.exhausted++; throw new Error('fuel'); }
	}
});
const trackedRuns: number[] = [];
let res: ReturnType<typeof active.result> | undefined;
for (let r = 0; r < 5; r++) {
	active = transaction(m1, 2 ** 31);
	for (const k of Object.keys(counts)) (counts as any)[k] = 0;
	(inst.exports.__folio_set_fuel as CallableFunction)(2 ** 31 - 1);
	const t0 = performance.now();
	(inst.exports.hash_all as CallableFunction)(TABLE, 1, OUT);
	trackedRuns.push(performance.now() - t0);
	res = active.result();
}
const trackedMs = Math.min(...trackedRuns);
const bytesView = new Uint8Array(m1.buffer);
for (const [a, v] of res!.writes) bytesView[a] = v;
console.log(JSON.stringify({
	len, blocks: Math.ceil(len / 64), nativeMs, trackedMs, ratio: trackedMs / nativeMs,
	counts, accessesTotal: counts.load + counts.store + counts.load64 + counts.store64,
	trackedRuns, distinctReadBytes: res!.reads.length, distinctWriteBytes: res!.writes.length,
	digestEqual: Buffer.from(m1.buffer, OUT, 32).toString('hex') === digest,
	usPerAccess: (trackedMs * 1000) / (counts.load + counts.store + counts.load64 + counts.store64),
	loadavg: (await import('node:os')).loadavg()
}));
