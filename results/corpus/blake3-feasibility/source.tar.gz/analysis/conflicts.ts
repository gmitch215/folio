import { readFileSync } from 'node:fs';
const t = JSON.parse(readFileSync(process.argv[2]!, 'utf8'));
const names = new Map<string, string>(t.names);
const cls = (a: number) => (a < 65536 ? `stack(${a})` : a < 65536 + 64 ? 'rodata' : a >= 1 << 20 && a < (1 << 20) + 65536 ? 'table/out' : 'inputs');
const by = new Map<string, number>();
const ex: any[] = [];
for (const c of t.trace) {
	const r = names.get(c.reader.call.export), w = names.get(c.writer.call.export);
	const key = `${r} <- ${w} @ ${cls(c.firstConflict).replace(/\(.*/, '')}`;
	by.set(key, (by.get(key) ?? 0) + 1);
	if (ex.length < 12) ex.push({ reader: r, readerArgs: c.reader.call.args, writer: w, writerArgs: c.writer.call.args, firstConflict: c.firstConflict, class: cls(c.firstConflict), min: c.conflictMin, max: c.conflictMax, conflicts: c.conflicts });
}
console.log('replays', t.trace.length);
console.log([...by].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${v}\t${k}`).join('\n'));
console.log(JSON.stringify(ex, null, 0).replace(/\},\{/g, '},\n{'));
const all = t.trace.map((c: any) => [c.conflictMin, c.conflictMax]);
console.log('stack range hit', Math.min(...all.map((x: number[]) => x[0]!)), Math.max(...all.map((x: number[]) => x[1]!)));
