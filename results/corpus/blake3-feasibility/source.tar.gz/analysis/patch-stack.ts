// diagnostic copy only: rotate each hash_all iteration onto its own stack slot
import { readFileSync, writeFileSync } from 'node:fs';
import binaryen from 'binaryen';
const raw = binaryen as any;
const [input, output, slotsArg = '16', slotArg = '32768'] = process.argv.slice(2);
const slots = Number(slotsArg), slot = Number(slotArg);
const m = binaryen.readBinary(new Uint8Array(readFileSync(input!)));
m.setFeatures(binaryen.Features.All);
const f = m.getFunction('hash_all');
const i32 = binaryen.i32;
const l = (i: number) => m.local.get(i, i32);
const c = (v: number) => m.i32.const(v);
const old = binaryen.getFunctionInfo(f);
const saved = raw._BinaryenFunctionAddVar(f, i32); // 5
const top = m.i32.sub(
	m.i32.sub(c(1048576), m.i32.mul(m.i32.and(l(4), c(slots - 1)), c(slot))),
	c(1920)
);
const h = () => m.i32.add(l(3), c(8));
const body = m.block(null, [
	m.local.set(saved, m.global.get('__stack_pointer', i32)),
	m.block('exit', [
		m.br('exit', m.i32.eqz(l(1))),
		m.local.set(4, l(1)),
		m.loop('it', m.block(null, [
			m.global.set('__stack_pointer', m.local.tee(3, top, i32)),
			m.call('blake3_hasher_init', [h()], binaryen.none),
			m.call('blake3_hasher_update', [h(), m.i32.load(0, 4, l(0)), m.i32.load(4, 4, l(0))], binaryen.none),
			m.call('blake3_hasher_finalize', [h(), l(2), c(32)], binaryen.none),
			m.local.set(0, m.i32.add(l(0), c(8))),
			m.local.set(2, m.i32.add(l(2), c(32))),
			m.br('it', m.local.tee(4, m.i32.add(l(4), c(-1)), i32))
		]))
	]),
	m.global.set('__stack_pointer', l(saved)),
	l(1)
], i32);
raw._BinaryenFunctionSetBody(f, body);
if (!m.validate()) throw new Error('invalid');
writeFileSync(output!, m.emitBinary());
console.log('wrote', output, 'slots', slots, 'slot', slot, 'old vars', old.vars.length);
