// estimates every function as if it were pure, recursion broken at the back edge
import { readFileSync } from 'node:fs';
import binaryen from 'binaryen';
import { estimateTerms, settleWork, netWork, type Term, type Work } from './fsrc/extract.ts';

const file = process.argv[2] ?? 'build/blake3-hash-all.wasm';
const trips = Number(process.argv[3] ?? 1000);
const m = binaryen.readBinary(new Uint8Array(readFileSync(file)));
m.setFeatures(binaryen.Features.All);
const fns = new Map<string, any>();
for (let i = 0; i < m.getNumFunctions(); i++) {
	const f = binaryen.getFunctionInfo(m.getFunctionByIndex(i));
	if (f.body) fns.set(f.name, f);
}
const terms = new Map<string, Term[]>();
const active = new Set<string>();
// scan written locals
function written(e: number, out: Set<number>) {
	const v: any = binaryen.getExpressionInfo(e);
	if (v.id === binaryen.LocalSetId) out.add(v.index);
	for (const k of ['children', 'operands']) for (const c of v[k] ?? []) written(c, out);
	for (const k of ['body', 'condition', 'ifTrue', 'ifFalse', 'ptr', 'value', 'left', 'right', 'dest', 'source', 'size', 'target'])
		if (typeof v[k] === 'number' && v[k] && !(k === 'value' && v.id === binaryen.ConstId)) written(v[k], out);
}
const workOf = (name: string): Work | undefined => {
	if (!fns.has(name) || active.has(name)) return undefined;
	return settleWork(termsOf(name), trips);
};
function termsOf(name: string): Term[] {
	let t = terms.get(name);
	if (t) return t;
	active.add(name);
	const f = fns.get(name);
	const w = new Set<number>();
	written(f.body, w);
	const count = binaryen.expandType(f.params).length;
	t = estimateTerms(f.body, workOf, trips, {
		input: (i) => i < count && !w.has(i),
		counter: (i) => w.has(i)
	});
	active.delete(name);
	terms.set(name, t);
	return t;
}
for (const name of fns.keys()) {
	const t = termsOf(name);
	const w = settleWork(t, trips);
	console.log(`${name.padEnd(36)} compute=${w.compute} accesses=${w.accesses} net=${netWork(w)} terms=${JSON.stringify(t.map((x) => ({ p: x.params, c: x.compute, a: x.accesses })))}`);
}
