// diagnostic only: inline 64-byte-granule read and write bitmaps on every load and store, no host calls
import { readFileSync, writeFileSync } from 'node:fs';
import binaryen from 'binaryen';
const raw = binaryen as any;
const [input, output, rBaseArg, wBaseArg] = process.argv.slice(2);
const R = Number(rBaseArg), W = Number(wBaseArg);
const m = binaryen.readBinary(new Uint8Array(readFileSync(input!)));
m.setFeatures(binaryen.Features.All);
const i32 = binaryen.i32;
const kids = (v: any): number[] => {
	const out: number[] = [];
	for (const k of ['children', 'operands']) out.push(...(v[k] ?? []));
	for (const k of ['body', 'condition', 'ifTrue', 'ifFalse', 'ptr', 'value', 'left', 'right', 'dest', 'source', 'size', 'target'])
		if (typeof v[k] === 'number' && v[k] && !(k === 'value' && v.id === binaryen.ConstId)) out.push(v[k]);
	return out;
};
let marks = 0;
for (let i = 0; i < m.getNumFunctions(); i++) {
	const f = m.getFunctionByIndex(i);
	const fi = binaryen.getFunctionInfo(f);
	if (!fi.body) continue;
	const tmp = binaryen.expandType(fi.params).length + fi.vars.length;
	let used = false;
	const visit = (e: number) => {
		const v: any = binaryen.getExpressionInfo(e);
		for (const k of kids(v)) visit(k);
		if (v.id !== binaryen.LoadId && v.id !== binaryen.StoreId) return;
		used = true;
		marks++;
		const base = v.id === binaryen.LoadId ? R : W;
		const granule = m.i32.shr_u(m.i32.add(m.local.get(tmp, i32), m.i32.const(v.offset)), m.i32.const(6));
		// bitmap byte = base + (granule >> 3); bit = granule & 7
		const addr = () => m.i32.add(m.i32.const(base), m.i32.shr_u(granule2(), m.i32.const(3)));
		const granule2 = () => m.i32.shr_u(m.i32.add(m.local.get(tmp, i32), m.i32.const(v.offset)), m.i32.const(6));
		void granule;
		const mark = m.i32.store8(0, 1, addr(), m.i32.or(m.i32.load8_u(0, 1, addr()), m.i32.shl(m.i32.const(1), m.i32.and(granule2(), m.i32.const(7)))));
		const ptr = m.block(null, [m.local.set(tmp, v.ptr), mark, m.local.get(tmp, i32)], i32);
		if (v.id === binaryen.LoadId) raw._BinaryenLoadSetPtr(e, ptr);
		else raw._BinaryenStoreSetPtr(e, ptr);
	};
	visit(fi.body);
	if (used) {
		const idx = raw._BinaryenFunctionAddVar(f, i32);
		if (idx !== tmp) throw new Error(`tmp index ${idx} != ${tmp}`);
	}
}
if (!m.validate()) throw new Error('invalid');
writeFileSync(output!, m.emitBinary());
console.log('instrumented accesses', marks);
