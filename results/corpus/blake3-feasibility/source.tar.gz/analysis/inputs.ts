import { readFileSync } from 'node:fs';

const vectors = JSON.parse(
	readFileSync(new URL('./src/BLAKE3-1.8.7/test_vectors/test_vectors.json', import.meta.url), 'utf8')
) as { cases: { input_len: number; hash: string }[] };
export const vectorHash = new Map(vectors.cases.map((c) => [c.input_len, c.hash.slice(0, 64)]));

function rng(state: number) {
	return () => {
		state = (state + 0x6d2b79f5) | 0;
		let t = Math.imul(state ^ (state >>> 15), 1 | state);
		t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
		return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
	};
}

export function sizes(): number[] {
	const set = new Set<number>(vectorHash.keys());
	for (const n of [1023, 1024, 1025, 2047, 2048, 2049, 4095, 4096, 4097, 0]) set.add(n);
	for (let k = 0; k <= 16; k++) set.add(1024 << k);
	for (const k of [1, 3, 5, 7, 9, 11]) set.add((1024 << k) * 3);
	set.add(64 * 1024 * 1024 - 1);
	const next = rng(20261029);
	while (set.size < 100) set.add(Math.floor(2 ** (next() * 22)));
	return [...set].sort((a, b) => a - b);
}

// vector sizes use the official pattern; the rest are pseudo-random bytes
export function fill(view: Uint8Array, length: number, index: number) {
	if (vectorHash.has(length)) {
		for (let i = 0; i < length; i++) view[i] = i % 251;
		return;
	}
	let s = (0x9e3779b9 ^ (index * 2654435761)) | 0;
	for (let i = 0; i < length; i++) {
		s ^= s << 13; s ^= s >>> 17; s ^= s << 5;
		view[i] = s & 255;
	}
}
