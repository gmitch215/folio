import { parentPort, workerData } from 'node:worker_threads';
const { module, memory, stackTop } = workerData;
const inst = new WebAssembly.Instance(module, { env: { memory } });
const ex = inst.exports as any;
ex.__sp.value = stackTop;
parentPort!.on('message', ({ items, table, out }: { items: number[]; table: number; out: number }) => {
	const t = performance.now();
	for (const k of items) ex.hash_all(table + 8 * k, 1, out + 32 * k);
	parentPort!.postMessage({ ms: performance.now() - t });
});
parentPort!.postMessage({ ready: true });
