import { fill, sizes } from './inputs.ts';

export const BASE = 1 << 20;

export interface Layout {
	lengths: number[];
	offsets: number[];
	table: number;
	out: number;
	pages: number;
}

export function layout(lengths: number[]): Layout {
	const n = lengths.length;
	const table = BASE;
	const out = table + 8 * n;
	let at = BASE + 65536;
	const offsets = lengths.map((length) => {
		const offset = at;
		at += (length + 63) & ~63;
		return offset;
	});
	return { lengths, offsets, table, out, pages: Math.ceil(at / 65536) + 1 };
}

export function populate(memory: WebAssembly.Memory, l: Layout) {
	const view = new Uint8Array(memory.buffer);
	const words = new Uint32Array(memory.buffer, l.table, 2 * l.lengths.length);
	l.lengths.forEach((length, i) => {
		words[2 * i] = l.offsets[i]!;
		words[2 * i + 1] = length;
		fill(view.subarray(l.offsets[i]!, l.offsets[i]! + length), length, i);
	});
}

export function digests(memory: WebAssembly.Memory, l: Layout) {
	const view = Buffer.from(memory.buffer, l.out, 32 * l.lengths.length);
	return l.lengths.map((_, i) => view.subarray(32 * i, 32 * i + 32).toString('hex'));
}

export { sizes };
