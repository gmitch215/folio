#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "blake3.h"

int main(int argc, char **argv) {
	FILE *f = fopen(argv[1], "rb");
	uint32_t n;
	if (!f || fread(&n, 4, 1, f) != 1) return 1;
	uint32_t *lens = malloc(4 * (size_t)n);
	if (fread(lens, 4, n, f) != n) return 1;
	for (uint32_t i = 0; i < n; i++) {
		uint8_t *buf = malloc(lens[i] ? lens[i] : 1);
		if (lens[i] && fread(buf, 1, lens[i], f) != lens[i]) return 1;
		blake3_hasher h;
		blake3_hasher_init(&h);
		blake3_hasher_update(&h, buf, lens[i]);
		uint8_t out[32];
		blake3_hasher_finalize(&h, out, 32);
		for (int k = 0; k < 32; k++) printf("%02x", out[k]);
		printf("\n");
		free(buf);
	}
	return 0;
}
