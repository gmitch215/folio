#!/bin/sh
# usage: build.sh <outdir> <name> <extra clang flags; use -matomics with -Wl,--shared-memory>
set -e
here=$(cd "$(dirname "$0")" && pwd)
c=$here/src/BLAKE3-1.8.7/c
out=$1; name=$2; shift 2
mkdir -p "$out"
PATH=$(echo "$PATH" | tr ':' '\n' | grep -v 'node_modules/\.bin' | paste -sd: -) \
/opt/homebrew/opt/llvm/bin/clang --target=wasm32 -O2 -g0 -ffreestanding -fno-builtin -nostdlib \
	-mbulk-memory -DNDEBUG -DBLAKE3_NO_SSE2 -DBLAKE3_NO_SSE41 -DBLAKE3_NO_AVX2 -DBLAKE3_NO_AVX512 \
	"$@" -I "$here/include" -I "$c" \
	"$here/support.c" "$here/${CONSUMER:-consumer.c}" "$c/blake3.c" "$c/blake3_dispatch.c" "$c/blake3_portable.c" \
	-Wl,--no-entry,--import-memory,--export-memory,--allow-undefined,--export=hash_all \
	-Wl,--initial-memory=1048576 -Wl,--max-memory=4294967296 \
	-o "$out/$name.wasm"
