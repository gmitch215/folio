import { readFileSync } from 'node:fs';
import { prepare } from './fsrc/compiler.ts';
import { netWork } from './fsrc/extract.ts';

const file = process.argv[2] ?? 'build/blake3-hash-all.wasm';
const min = process.argv[3] === undefined ? 0 : Number(process.argv[3]);
const bytes = new Uint8Array(readFileSync(file));
const rows: any[] = [];
const p = prepare(bytes, {
	minimumRegionWork: min,
	observed: (s) => rows.push({ ...s, net: netWork(s) })
});
console.log(JSON.stringify({ plan: Boolean(p.control), controlReasons: p.controlReasons, diag: p.control?.diagnostics, regions: p.control?.regions.length }));
for (const r of rows) console.log(`${r.kind.padEnd(8)} ${r.name.padEnd(40)} compute=${r.compute} accesses=${r.accesses} net=${r.net}`);
