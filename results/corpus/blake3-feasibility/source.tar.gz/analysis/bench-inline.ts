import { readFileSync } from 'node:fs';
import { loadavg } from 'node:os';
import { fill } from './inputs.ts';
const len = Number(process.argv[2] ?? 1 << 20);
const TABLE = 1 << 20, OUT = TABLE + 8, IN = TABLE + 65536;
const pages = Math.ceil((IN + len + 64) / 65536) + 1;
const top = pages * 65536;
const R = top - 16384, W = R + 8192;
const files = { native: 'build/blake3-hash-all.wasm', inline: 'build/inline.wasm' };
const out: any = { len, blocks: Math.ceil(len / 64), R, W };
const digests: Record<string, string> = {};
for (const [name, file] of Object.entries(files)) {
	const memory = new WebAssembly.Memory({ initial: pages, maximum: pages });
	fill(new Uint8Array(memory.buffer, IN, len), len, 7);
	const w = new Uint32Array(memory.buffer, TABLE, 2);
	w[0] = IN; w[1] = len;
	const inst = new WebAssembly.Instance(new WebAssembly.Module(readFileSync(file)), { env: { memory } });
	const times: number[] = [];
	for (let r = 0; r < 40; r++) {
		const t = performance.now();
		(inst.exports.hash_all as CallableFunction)(TABLE, 1, OUT);
		times.push(performance.now() - t);
	}
	times.sort((a, b) => a - b);
	out[name] = { minMs: +times[0]!.toFixed(3), medianMs: +times[20]!.toFixed(3) };
	digests[name] = Buffer.from(memory.buffer, OUT, 32).toString('hex');
	if (name === 'inline') {
		const bits = (base: number) => new Uint8Array(memory.buffer, base, 8192).reduce((a, b) => a + b.toString(2).replaceAll('0', '').length, 0);
		out.inline.readGranulesMarked = bits(R); out.inline.writeGranulesMarked = bits(W);
	}
}
out.digestsEqual = digests.native === digests.inline;
out.overheadMedian = +(out.inline.medianMs / out.native.medianMs).toFixed(2);
out.overheadMin = +(out.inline.minMs / out.native.minMs).toFixed(2);
out.loadavg = loadavg();
console.log(JSON.stringify(out));
