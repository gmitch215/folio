import { readFileSync } from 'node:fs';
const t = JSON.parse(readFileSync(process.argv[2]!, 'utf8'));
const names = new Map<string, string>(t.names);
const g = new Map<string, { n: number; lo: number; hi: number }>();
for (const c of t.trace) {
	const k = `${names.get(c.reader.call.export)} reads what ${names.get(c.writer.call.export)} wrote`;
	const e = g.get(k) ?? { n: 0, lo: 1e12, hi: 0 };
	e.n++; e.lo = Math.min(e.lo, c.conflictMin); e.hi = Math.max(e.hi, c.conflictMax); g.set(k, e);
}
for (const [k, e] of g) console.log(e.n, k, `addr ${e.lo}..${e.hi}`);
// conflict classes: how many replayed reader/writer pairs are in the same iteration (same hasher frame) -> all stack
let nonStack = 0;
for (const c of t.trace) if (c.conflictMax >= 65536) nonStack++;
console.log('replays with any non-stack conflicting address:', nonStack);
