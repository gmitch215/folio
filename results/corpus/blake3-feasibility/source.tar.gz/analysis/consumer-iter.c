#include <stdint.h>
#include "blake3.h"

/* diagnostic copy: the loop body is its own function so a region can be one iteration */
__attribute__((noinline)) static void hash_one(const uint32_t *entry, uint8_t *out) {
	blake3_hasher hasher;
	blake3_hasher_init(&hasher);
	blake3_hasher_update(&hasher, (const void *)(uintptr_t)entry[0], entry[1]);
	blake3_hasher_finalize(&hasher, out, BLAKE3_OUT_LEN);
}

uint32_t hash_all(const uint32_t *table, uint32_t n, uint8_t *out) {
	for (uint32_t i = 0; i < n; i++) hash_one(table + 2 * i, out + 32 * i);
	return n;
}
