// diagnostic ceiling: unmodified module, untracked workers, private stack each, disjoint outputs
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { cpus, loadavg } from 'node:os';
import { Worker } from 'node:worker_threads';
import { layout, populate, sizes } from './host.ts';

const wasm = process.env.WASM ?? 'build/shared-sp.wasm';
const bytes = new Uint8Array(readFileSync(wasm));
const module = new WebAssembly.Module(bytes);
const lengths = sizes().filter((n) => n <= Number(process.env.SIZEMAX ?? 1e12));
const l = layout(lengths);
const mk = () => {
	const memory = new WebAssembly.Memory({ initial: l.pages, maximum: l.pages, shared: true });
	populate(memory, l);
	return memory;
};
const digestOf = (memory: WebAssembly.Memory) =>
	createHash('sha256').update(new Uint8Array(memory.buffer, l.out, 32 * lengths.length)).digest('hex');
// serial reference on the main thread
const ref = mk();
const refInst = new WebAssembly.Instance(module, { env: { memory: ref } }) as any;
refInst.exports.__sp.value = 65536;
const serial: number[] = [];
for (let r = 0; r < 5; r++) {
	const t = performance.now();
	refInst.exports.hash_all(l.table, lengths.length, l.out);
	serial.push(performance.now() - t);
}
const refDigest = digestOf(ref);
const total = lengths.reduce((a, b) => a + b, 0);
const strategies: Record<string, (w: number) => number[][]> = {
	// contiguous equal-count split, the shape the counted-loop splitter would produce
	'even-count': (w) => {
		const out: number[][] = Array.from({ length: w }, () => []);
		lengths.forEach((_, k) => out[Math.min(w - 1, Math.floor((k * w) / lengths.length))]!.push(k));
		return out;
	},
	// longest first onto the least loaded worker: the best a per-input grain can do
	lpt: (w) => {
		const out: number[][] = Array.from({ length: w }, () => []);
		const load = new Array(w).fill(0);
		[...lengths.keys()].sort((a, b) => lengths[b]! - lengths[a]!).forEach((k) => {
			const i = load.indexOf(Math.min(...load));
			out[i]!.push(k);
			load[i] += lengths[k]! + 4096;
		});
		return out;
	}
};
const results: any[] = [];
for (const w of (process.env.WIDTHS ?? '1,2,4,8').split(',').map(Number)) {
	for (const [name, split] of Object.entries(strategies)) {
		const memory = mk();
		const workers = await Promise.all(
			Array.from({ length: w }, (_, i) =>
				new Promise<Worker>((resolve) => {
					const worker = new Worker(new URL('./ceiling-worker.ts', import.meta.url), {
						workerData: { module, memory, stackTop: (1 << 20) - i * 65536 }
					});
					worker.once('message', () => resolve(worker));
				})
			)
		);
		const walls: number[] = [];
		let maxWorker = 0;
		let equal = true;
		for (let r = 0; r < 5; r++) {
			new Uint8Array(memory.buffer, l.out, 32 * lengths.length).fill(0);
			const parts = split(w);
			const t = performance.now();
			const done = await Promise.all(
				workers.map((worker, i) => new Promise<{ ms: number }>((resolve) => {
					worker.once('message', resolve);
					worker.postMessage({ items: parts[i], table: l.table, out: l.out });
				}))
			);
			walls.push(performance.now() - t);
			maxWorker = Math.max(maxWorker, ...done.map((d) => d.ms));
			equal &&= digestOf(memory) === refDigest;
		}
		await Promise.all(workers.map((x) => x.terminate()));
		results.push({ workers: w, split: name, wallMsMedian: [...walls].sort((a, b) => a - b)[2], walls: walls.map((x) => +x.toFixed(1)), digestsEqual: equal });
	}
}
console.log(JSON.stringify({
	inputs: lengths.length, totalBytes: total, largestBytes: Math.max(...lengths), hardwareThreads: cpus().length,
	loadavgStart: loadavg(), serialMainThreadMs: serial.map((x) => +x.toFixed(1)), results
}, null, 1));
