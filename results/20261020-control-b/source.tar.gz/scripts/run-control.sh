#!/usr/bin/env bash
set -euo pipefail
label=folio-control-20261020-b
locked=0
finish() {
	status=$?
	if [ "$locked" = 1 ]; then
		bash "$HOME/rig/bin/sweep.sh" end "$label"
		rmdir /tmp/folio-timing.lock
	fi
	printf '%s\n' "$status" > results/exit-code
}
trap finish EXIT
mkdir /tmp/folio-timing.lock
locked=1
bash "$HOME/rig/bin/sweep.sh" start "$label"
nice -n 19 taskset -c 4-11 "$HOME/.nvm/versions/node/v26.10.0/bin/node" \
	--max-old-space-size=128 scripts/control-probe.mjs > results/control.jsonl
