import assert from 'node:assert/strict';
import { test } from 'node:test';
import binaryen from 'binaryen';
import { Coordinator } from '../src/coordinator.ts';
import { Folio } from '../src/node.ts';

test('snapshot growth failure executes the original batch without publishing speculative writes', async () => {
	const memory = new WebAssembly.Memory({ initial: 2, maximum: 2 });
	const mirror = new WebAssembly.Memory({ initial: 1, maximum: 1, shared: true });
	const effects: number[] = [];
	const scheduler = new Coordinator({ memory, workerMemory: mirror, width: 2, profile: false,
		dispatch: async () => { throw new Error('unavailable mirror must not dispatch'); },
		native: call => {
			const at = Number(call.args[0]);
			effects.push(at);
			new Uint32Array(memory.buffer)[at] = at + 7;
		} });
	scheduler.enqueue({ export: 'put', args: [0] });
	scheduler.enqueue({ export: 'put', args: [16384] });
	await scheduler.flush();
	assert.deepEqual(effects, [0, 16384]);
	assert.equal(scheduler.report.workers, 0);
	assert.equal(scheduler.report.fallbacks, 1);
	assert.equal(new Uint32Array(memory.buffer)[16384], 16391);
});

test('unavailable shared snapshot allocation retains a usable native instance', async () => {
	const module = binaryen.parseText(`(module (memory (export "memory") 1 2)
		(func $put (param i32) (i32.store (local.get 0) (i32.const 11)))
		(func (export "main") (result i32)
			(call $put (i32.const 0)) (call $put (i32.const 4)) (i32.load (i32.const 4))))`);
	const bytes = module.emitBinary();
	module.dispose();
	const original = WebAssembly.Memory;
	const replacement = new Proxy(original, { construct(target, args) {
		if (args[0]?.shared) throw new RangeError('forced shared allocation refusal');
		return Reflect.construct(target, args);
	} });
	let pool: Folio | undefined;
	try {
		WebAssembly.Memory = replacement;
		pool = await Folio.open(bytes, { workers: 2 });
	} finally { WebAssembly.Memory = original; }
	try {
		assert.ok(pool);
		assert.ok(pool.diagnostics.some(reason => reason.includes('allocation unavailable')));
		assert.deepEqual((await pool.run('main')).values, [11]);
		assert.equal(pool.memory.buffer instanceof SharedArrayBuffer, false);
		assert.equal(pool.threadIds.length, 0);
	} finally { await pool?.close(); }
});
